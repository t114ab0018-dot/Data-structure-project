// Mock Data for Next-Gen Rental Platform MVP

export interface Property {
  id: number;
  title: string;
  address: string;
  district: string;
  price: number;
  size: number;
  rooms: number;
  bathrooms: number;
  floor: string;
  type: string;
  lat: number;
  lng: number;
  images: string[];
  features: string[];
  landlord: {
    name: string;
    verified: boolean;
    rating: number;
    responseRate: number;
  };
  subsidy: boolean;
  subsidyAmount: number;
  lifeScores: {
    transport: number;
    shopping: number;
    dining: number;
    medical: number;
    education: number;
  };
  commute: {
    mrt: string;
    distance: number;
    walkTime: number;
  };
  reviews: Array<{
    id: number;
    author: string;
    rating: number;
    date: string;
    content: string;
    helpful: number;
  }>;
  aiMatch: number;
  matchReasons: string[];
}

// Property Listings with Comprehensive Details
export const properties: Property[] = [
  {
    id: 1,
    title: "溫馨採光兩房近捷運",
    address: "台北市大安區復興南路一段",
    district: "大安區",
    price: 28000,
    size: 25,
    rooms: 2,
    bathrooms: 1,
    floor: "5/7",
    type: "公寓",
    lat: 25.0424,
    lng: 121.5436,
    images: [
      "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&h=600&fit=crop"
    ],
    features: ["電梯", "陽台", "近捷運", "採光佳", "租補合格"],
    landlord: {
      name: "王先生",
      verified: true,
      rating: 4.8,
      responseRate: 95
    },
    subsidy: true,
    subsidyAmount: 3000,
    lifeScores: {
      transport: 92,
      shopping: 88,
      dining: 95,
      medical: 85,
      education: 90
    },
    commute: {
      mrt: "大安站",
      distance: 350,
      walkTime: 5
    },
    reviews: [
      {
        id: 1,
        author: "匿名租客 A",
        rating: 5,
        date: "2026-05-15",
        content: "房東很好溝通，房子維護得很好，採光真的很棒！",
        helpful: 12
      },
      {
        id: 2,
        author: "匿名租客 B",
        rating: 4,
        date: "2026-04-20",
        content: "地點方便，生活機能優秀，就是偶爾會聽到樓上聲音。",
        helpful: 8
      }
    ],
    aiMatch: 87,
    matchReasons: ["通勤時間符合", "生活機能優秀", "價格在預算內"]
  },
  {
    id: 2,
    title: "質感單人套房含車位",
    address: "台北市信義區松仁路",
    district: "信義區",
    price: 22000,
    size: 15,
    rooms: 1,
    bathrooms: 1,
    floor: "12/15",
    type: "電梯大樓",
    lat: 25.0375,
    lng: 121.5645,
    images: [
      "https://images.unsplash.com/photo-1536376072261-38c75010e6c9?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop"
    ],
    features: ["電梯", "停車位", "管理室", "健身房", "租補合格"],
    landlord: {
      name: "林小姐",
      verified: true,
      rating: 4.9,
      responseRate: 98
    },
    subsidy: true,
    subsidyAmount: 3000,
    lifeScores: {
      transport: 85,
      shopping: 98,
      dining: 92,
      medical: 88,
      education: 82
    },
    commute: {
      mrt: "象山站",
      distance: 280,
      walkTime: 4
    },
    reviews: [
      {
        id: 1,
        author: "匿名租客 C",
        rating: 5,
        date: "2026-05-28",
        content: "超級推薦！房東人超好，大樓管理很完善。",
        helpful: 15
      }
    ],
    aiMatch: 92,
    matchReasons: ["高度符合偏好", "管理完善", "停車便利"]
  },
  {
    id: 3,
    title: "舒適三房適合家庭",
    address: "新北市板橋區文化路二段",
    district: "板橋區",
    price: 32000,
    size: 35,
    rooms: 3,
    bathrooms: 2,
    floor: "3/5",
    type: "公寓",
    lat: 25.0118,
    lng: 121.4629,
    images: [
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop"
    ],
    features: ["近公園", "學區", "寬敞", "採光佳"],
    landlord: {
      name: "陳太太",
      verified: true,
      rating: 4.7,
      responseRate: 90
    },
    subsidy: false,
    subsidyAmount: 0,
    lifeScores: {
      transport: 78,
      shopping: 85,
      dining: 80,
      medical: 90,
      education: 95
    },
    commute: {
      mrt: "府中站",
      distance: 450,
      walkTime: 6
    },
    reviews: [
      {
        id: 1,
        author: "匿名租客 D",
        rating: 5,
        date: "2026-05-10",
        content: "很適合家庭居住，附近學校和公園都很近。",
        helpful: 10
      }
    ],
    aiMatch: 78,
    matchReasons: ["適合家庭", "學區優質", "空間寬敞"]
  },
  {
    id: 4,
    title: "時尚工業風閣樓",
    address: "台北市中山區中山北路二段",
    district: "中山區",
    price: 26000,
    size: 20,
    rooms: 1,
    bathrooms: 1,
    floor: "6/6",
    type: "樓中樓",
    lat: 25.0579,
    lng: 121.5215,
    images: [
      "https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1502672023488-70e25813eb80?w=800&h=600&fit=crop"
    ],
    features: ["樓中樓", "工業風", "獨立衛浴", "挑高", "租補合格"],
    landlord: {
      name: "張先生",
      verified: true,
      rating: 4.6,
      responseRate: 88
    },
    subsidy: true,
    subsidyAmount: 3000,
    lifeScores: {
      transport: 90,
      shopping: 92,
      dining: 96,
      medical: 82,
      education: 80
    },
    commute: {
      mrt: "中山站",
      distance: 320,
      walkTime: 5
    },
    reviews: [
      {
        id: 1,
        author: "匿名租客 E",
        rating: 4,
        date: "2026-04-25",
        content: "設計感十足，很有個性的房子，就是夏天會比較熱。",
        helpful: 6
      }
    ],
    aiMatch: 85,
    matchReasons: ["設計風格獨特", "地點便利", "生活機能佳"]
  },
  {
    id: 5,
    title: "明亮雅房含家具",
    address: "台北市萬華區西園路一段",
    district: "萬華區",
    price: 12000,
    size: 8,
    rooms: 1,
    bathrooms: 1,
    floor: "4/5",
    type: "雅房",
    lat: 25.0324,
    lng: 121.4989,
    images: [
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?w=800&h=600&fit=crop"
    ],
    features: ["包水電", "家具", "近夜市", "租補合格"],
    landlord: {
      name: "李太太",
      verified: false,
      rating: 4.3,
      responseRate: 75
    },
    subsidy: true,
    subsidyAmount: 2400,
    lifeScores: {
      transport: 82,
      shopping: 88,
      dining: 90,
      medical: 78,
      education: 70
    },
    commute: {
      mrt: "龍山寺站",
      distance: 550,
      walkTime: 8
    },
    reviews: [
      {
        id: 1,
        author: "匿名租客 F",
        rating: 4,
        date: "2026-03-12",
        content: "價格實惠，房東親切，適合預算有限的學生。",
        helpful: 9
      }
    ],
    aiMatch: 72,
    matchReasons: ["價格實惠", "包水電省事", "生活機能可"]
  }
];

// MRT Stations for Map Visualization
export const mrtStations = [
  { id: 1, name: "台北車站", lat: 25.0478, lng: 121.5170, line: "板南線" },
  { id: 2, name: "大安站", lat: 25.0333, lng: 121.5434, line: "板南線" },
  { id: 3, name: "象山站", lat: 25.0330, lng: 121.5695, line: "板南線" },
  { id: 4, name: "府中站", lat: 25.0084, lng: 121.4595, line: "板南線" },
  { id: 5, name: "中山站", lat: 25.0527, lng: 121.5202, line: "淡水信義線" },
  { id: 6, name: "龍山寺站", lat: 25.0355, lng: 121.4999, line: "板南線" }
];

// Tenant Profiles for Landlord Dashboard
export const tenantProfiles = [
  {
    id: 1,
    name: "李*安",
    age: 28,
    occupation: "軟體工程師",
    company: "某科技公司",
    income: "月薪 65,000",
    creditScore: 850,
    verified: true,
    profileComplete: 95,
    tags: ["穩定工作", "無不良紀錄", "準時繳款", "愛整潔"],
    rentHistory: "3年租屋經驗，無違約紀錄",
    applicationDate: "2026-05-28",
    status: "審核中",
    documents: {
      id: true,
      income: true,
      employment: true,
      credit: true
    },
    aiScore: 92,
    propertyInterested: "溫馨採光兩房近捷運"
  },
  {
    id: 2,
    name: "王*婷",
    age: 25,
    occupation: "平面設計師",
    company: "自由接案",
    income: "月收入約 45,000",
    creditScore: 780,
    verified: true,
    profileComplete: 88,
    tags: ["創意工作者", "準時繳款", "安靜", "養貓"],
    rentHistory: "2年租屋經驗",
    applicationDate: "2026-05-25",
    status: "已簽約",
    documents: {
      id: true,
      income: true,
      employment: false,
      credit: true
    },
    aiScore: 85,
    propertyInterested: "時尚工業風閣樓"
  },
  {
    id: 3,
    name: "張*豪",
    age: 32,
    occupation: "業務主管",
    company: "某金融機構",
    income: "月薪 85,000",
    creditScore: 920,
    verified: true,
    profileComplete: 100,
    tags: ["高收入", "穩定工作", "無不良紀錄", "長期租約"],
    rentHistory: "5年租屋經驗，皆準時繳款",
    applicationDate: "2026-05-20",
    status: "已入住",
    documents: {
      id: true,
      income: true,
      employment: true,
      credit: true
    },
    aiScore: 98,
    propertyInterested: "質感單人套房含車位"
  }
];

// Contract Management for Landlord
export const contracts = [
  {
    id: 1,
    tenantName: "張*豪",
    propertyAddress: "台北市信義區松仁路",
    startDate: "2026-06-01",
    endDate: "2027-05-31",
    monthlyRent: 22000,
    deposit: 44000,
    status: "執行中",
    progress: 100,
    signedDate: "2026-05-22",
    nextPaymentDate: "2026-07-01"
  },
  {
    id: 2,
    tenantName: "王*婷",
    propertyAddress: "台北市中山區中山北路二段",
    startDate: "2026-06-15",
    endDate: "2027-06-14",
    monthlyRent: 26000,
    deposit: 52000,
    status: "待簽約",
    progress: 75,
    signedDate: null,
    nextPaymentDate: null
  }
];

// Rent Collection Status
export const rentPayments = [
  {
    id: 1,
    tenantName: "張*豪",
    propertyAddress: "台北市信義區松仁路",
    amount: 22000,
    dueDate: "2026-06-01",
    paidDate: "2026-05-30",
    status: "已繳納",
    method: "銀行轉帳"
  },
  {
    id: 2,
    tenantName: "王*婷",
    propertyAddress: "台北市中山區中山北路二段",
    amount: 26000,
    dueDate: "2026-06-15",
    paidDate: null,
    status: "待繳納",
    method: null
  }
];

// Maintenance Requests
export const maintenanceRequests = [
  {
    id: 1,
    tenantName: "張*豪",
    propertyAddress: "台北市信義區松仁路",
    issue: "浴室水龍頭滴水",
    category: "水電",
    urgency: "中",
    reportDate: "2026-05-28",
    status: "處理中",
    estimatedCost: 800,
    assignedTo: "王師傅水電行",
    scheduledDate: "2026-06-02",
    description: "浴室洗手台水龍頭關閉後仍有滴水現象，約每分鐘 3-4 滴。"
  },
  {
    id: 2,
    tenantName: "王*婷",
    propertyAddress: "台北市中山區中山北路二段",
    issue: "冷氣不冷",
    category: "家電",
    urgency: "高",
    reportDate: "2026-05-29",
    status: "已派工",
    estimatedCost: 1500,
    assignedTo: "永誠冷氣維修",
    scheduledDate: "2026-06-01",
    description: "客廳冷氣開啟後只送風不冷，懷疑冷媒不足或壓縮機問題。"
  },
  {
    id: 3,
    tenantName: "李*安",
    propertyAddress: "台北市大安區復興南路一段",
    issue: "門鎖卡住",
    category: "五金",
    urgency: "低",
    reportDate: "2026-05-26",
    status: "已完成",
    estimatedCost: 500,
    assignedTo: "自行處理",
    scheduledDate: "2026-05-27",
    completedDate: "2026-05-27",
    description: "大門鎖偶爾會卡住，需用力轉動才能開啟。已上潤滑油處理完成。"
  }
];

// Tax Calculator Presets (Public Rental Housing Tax Benefits)
export const taxBenefits = {
  incomeDeduction: 0.6,
  landTaxReduction: 0.78,
  houseTaxReduction: 0.67,
  description: "公益出租人可享有：1) 租金所得60%免稅 2) 地價稅按自用住宅稅率 3) 房屋稅按自用住宅稅率"
};

// Featured Landlord Stories (Trust Building)
export const landlordStories = [
  {
    id: 1,
    title: "成為公益出租人，我的租金收入反而增加了",
    landlord: "王先生",
    district: "大安區",
    excerpt: "透過租補制度和稅務優惠，實際收入比原本還多...",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600&h=400&fit=crop"
  },
  {
    id: 2,
    title: "數位管理讓我輕鬆管理三間出租房",
    landlord: "林小姐",
    district: "信義區",
    excerpt: "電子簽約、線上繳款、修繕追蹤，一個平台全搞定...",
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop"
  }
];
