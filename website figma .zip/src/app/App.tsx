import { useState } from 'react';
import { Home, Map, Building2, Menu, X, BadgeCheck, TrendingUp, Shield, Award } from 'lucide-react';
import { properties, tenantProfiles, contracts, rentPayments, maintenanceRequests, taxBenefits, landlordStories, mrtStations } from '../mockData';
import LandingPage from './components/LandingPage';
import RenterMapView from './components/RenterMapView';
import LandlordDashboard from './components/LandlordDashboard';

type View = 'landing' | 'renter' | 'landlord';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('landing');
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="size-full bg-[var(--morandi-warm-white)] overflow-hidden flex flex-col">
      {/* Header Navigation */}
      <header className="bg-white/80 backdrop-blur-md border-b border-[var(--morandi-stone)] sticky top-0 z-50 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentView('landing')}>
              <div className="w-10 h-10 bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] rounded-xl flex items-center justify-center shadow-sm">
                <Home className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-[var(--morandi-charcoal)]">安居平台</h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              <button
                onClick={() => setCurrentView('landing')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 ${
                  currentView === 'landing'
                    ? 'bg-[var(--morandi-sage)] text-white shadow-md'
                    : 'text-[var(--morandi-charcoal)] hover:bg-[var(--morandi-muted)]'
                }`}
              >
                <Home className="w-4 h-4" />
                <span>首頁</span>
              </button>
              <button
                onClick={() => setCurrentView('renter')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 ${
                  currentView === 'renter'
                    ? 'bg-[var(--morandi-sage)] text-white shadow-md'
                    : 'text-[var(--morandi-charcoal)] hover:bg-[var(--morandi-muted)]'
                }`}
              >
                <Map className="w-4 h-4" />
                <span>找房地圖</span>
              </button>
              <button
                onClick={() => setCurrentView('landlord')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 ${
                  currentView === 'landlord'
                    ? 'bg-[var(--morandi-sage)] text-white shadow-md'
                    : 'text-[var(--morandi-charcoal)] hover:bg-[var(--morandi-muted)]'
                }`}
              >
                <Building2 className="w-4 h-4" />
                <span>房東後台</span>
              </button>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-[var(--morandi-muted)] transition-colors"
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {menuOpen && (
            <div className="md:hidden py-4 border-t border-[var(--morandi-stone)] space-y-2 animate-in slide-in-from-top duration-300">
              <button
                onClick={() => {
                  setCurrentView('landing');
                  setMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2 px-4 py-3 rounded-lg transition-all ${
                  currentView === 'landing'
                    ? 'bg-[var(--morandi-sage)] text-white'
                    : 'text-[var(--morandi-charcoal)] hover:bg-[var(--morandi-muted)]'
                }`}
              >
                <Home className="w-5 h-5" />
                <span>首頁</span>
              </button>
              <button
                onClick={() => {
                  setCurrentView('renter');
                  setMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2 px-4 py-3 rounded-lg transition-all ${
                  currentView === 'renter'
                    ? 'bg-[var(--morandi-sage)] text-white'
                    : 'text-[var(--morandi-charcoal)] hover:bg-[var(--morandi-muted)]'
                }`}
              >
                <Map className="w-5 h-5" />
                <span>找房地圖</span>
              </button>
              <button
                onClick={() => {
                  setCurrentView('landlord');
                  setMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2 px-4 py-3 rounded-lg transition-all ${
                  currentView === 'landlord'
                    ? 'bg-[var(--morandi-sage)] text-white'
                    : 'text-[var(--morandi-charcoal)] hover:bg-[var(--morandi-muted)]'
                }`}
              >
                <Building2 className="w-5 h-5" />
                <span>房東後台</span>
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {currentView === 'landing' && <LandingPage onNavigate={setCurrentView} />}
        {currentView === 'renter' && <RenterMapView properties={properties} mrtStations={mrtStations} />}
        {currentView === 'landlord' && (
          <LandlordDashboard
            tenantProfiles={tenantProfiles}
            contracts={contracts}
            rentPayments={rentPayments}
            maintenanceRequests={maintenanceRequests}
            taxBenefits={taxBenefits}
          />
        )}
      </main>
    </div>
  );
}