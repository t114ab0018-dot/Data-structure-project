import { useState } from 'react';
import { Users, FileText, DollarSign, Wrench, Calculator, BadgeCheck, TrendingUp, AlertCircle, CheckCircle2, Clock, FileCheck, Shield, Award } from 'lucide-react';
import { Progress } from '../components/ui/progress';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';

interface LandlordDashboardProps {
  tenantProfiles: any[];
  contracts: any[];
  rentPayments: any[];
  maintenanceRequests: any[];
  taxBenefits: any;
}

export default function LandlordDashboard({
  tenantProfiles,
  contracts,
  rentPayments,
  maintenanceRequests,
  taxBenefits,
}: LandlordDashboardProps) {
  const [activeTab, setActiveTab] = useState('tenants');
  const [monthlyRent, setMonthlyRent] = useState(25000);
  const [landTax, setLandTax] = useState(8000);
  const [houseTax, setHouseTax] = useState(12000);

  const taxableincome = monthlyRent * 12 * taxBenefits.incomeDeduction;
  const savedIncomeTax = monthlyRent * 12 * (1 - taxBenefits.incomeDeduction) * 0.2;
  const savedLandTax = landTax * (1 - taxBenefits.landTaxReduction);
  const savedHouseTax = houseTax * (1 - taxBenefits.houseTaxReduction);
  const totalAnnualSavings = savedIncomeTax + savedLandTax + savedHouseTax;

  return (
    <div className="min-h-full bg-gradient-to-br from-[var(--morandi-warm-white)] via-white to-[var(--morandi-grey-taupe)] p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[var(--morandi-charcoal)] mb-2">房東管理後台</h1>
          <p className="text-[var(--morandi-muted-foreground)]">輕鬆管理您的出租物件與租客資訊</p>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white p-6 rounded-2xl shadow-md border border-[var(--morandi-stone)] hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-sage-light)] rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <TrendingUp className="w-5 h-5 text-[var(--morandi-sage)]" />
            </div>
            <div className="text-2xl font-bold text-[var(--morandi-charcoal)] mb-1">{tenantProfiles.length}</div>
            <div className="text-sm text-[var(--morandi-muted-foreground)]">租客申請</div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-md border border-[var(--morandi-stone)] hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--morandi-slate)] to-[var(--morandi-slate-light)] rounded-xl flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="text-2xl font-bold text-[var(--morandi-charcoal)] mb-1">{contracts.length}</div>
            <div className="text-sm text-[var(--morandi-muted-foreground)]">租約管理</div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-md border border-[var(--morandi-stone)] hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--morandi-mauve)] to-[var(--morandi-mauve-light)] rounded-xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="text-2xl font-bold text-[var(--morandi-charcoal)] mb-1">
              ${rentPayments.filter((p) => p.status === '已繳納').reduce((sum, p) => sum + p.amount, 0).toLocaleString()}
            </div>
            <div className="text-sm text-[var(--morandi-muted-foreground)]">本月收入</div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-md border border-[var(--morandi-stone)] hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--morandi-clay)] to-[var(--morandi-stone)] rounded-xl flex items-center justify-center">
                <Wrench className="w-6 h-6 text-white" />
              </div>
              <AlertCircle className="w-5 h-5 text-[var(--morandi-mauve)]" />
            </div>
            <div className="text-2xl font-bold text-[var(--morandi-charcoal)] mb-1">
              {maintenanceRequests.filter((r) => r.status !== '已完成').length}
            </div>
            <div className="text-sm text-[var(--morandi-muted-foreground)]">待處理維修</div>
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-white rounded-xl p-1 shadow-md border border-[var(--morandi-stone)]">
            <TabsTrigger value="tenants" className="rounded-lg data-[state=active]:bg-[var(--morandi-sage)] data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" />
              租客履歷
            </TabsTrigger>
            <TabsTrigger value="contracts" className="rounded-lg data-[state=active]:bg-[var(--morandi-sage)] data-[state=active]:text-white">
              <FileText className="w-4 h-4 mr-2" />
              合約管理
            </TabsTrigger>
            <TabsTrigger value="payments" className="rounded-lg data-[state=active]:bg-[var(--morandi-sage)] data-[state=active]:text-white">
              <DollarSign className="w-4 h-4 mr-2" />
              租金催收
            </TabsTrigger>
            <TabsTrigger value="maintenance" className="rounded-lg data-[state=active]:bg-[var(--morandi-sage)] data-[state=active]:text-white">
              <Wrench className="w-4 h-4 mr-2" />
              修繕請求
            </TabsTrigger>
            <TabsTrigger value="tax" className="rounded-lg data-[state=active]:bg-[var(--morandi-sage)] data-[state=active]:text-white">
              <Calculator className="w-4 h-4 mr-2" />
              節稅試算
            </TabsTrigger>
          </TabsList>

          {/* Tenant Profiles Tab */}
          <TabsContent value="tenants" className="space-y-4">
            {tenantProfiles.map((tenant) => (
              <div
                key={tenant.id}
                className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 border border-[var(--morandi-stone)]"
              >
                <div className="flex flex-col lg:flex-row gap-6">
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-16 h-16 bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] rounded-2xl flex items-center justify-center text-white text-2xl font-bold shadow-md">
                          {tenant.name[0]}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="text-xl font-semibold text-[var(--morandi-charcoal)]">{tenant.name}</h3>
                            {tenant.verified && (
                              <BadgeCheck className="w-5 h-5 text-[var(--morandi-sage)]" />
                            )}
                          </div>
                          <div className="text-sm text-[var(--morandi-muted-foreground)]">
                            {tenant.age} 歲 · {tenant.occupation}
                          </div>
                        </div>
                      </div>

                      <div className={`px-4 py-2 rounded-xl font-medium text-sm ${
                        tenant.status === '已入住'
                          ? 'bg-[var(--morandi-sage)]/10 text-[var(--morandi-sage)] border border-[var(--morandi-sage)]/20'
                          : tenant.status === '已簽約'
                          ? 'bg-[var(--morandi-slate)]/10 text-[var(--morandi-slate)] border border-[var(--morandi-slate)]/20'
                          : 'bg-[var(--morandi-mauve)]/10 text-[var(--morandi-mauve)] border border-[var(--morandi-mauve)]/20'
                      }`}>
                        {tenant.status}
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-[var(--morandi-muted-foreground)]">公司</span>
                          <span className="font-medium text-[var(--morandi-charcoal)]">{tenant.company}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-[var(--morandi-muted-foreground)]">收入</span>
                          <span className="font-medium text-[var(--morandi-sage)]">{tenant.income}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-[var(--morandi-muted-foreground)]">信用分數</span>
                          <span className="font-semibold text-[var(--morandi-slate)]">{tenant.creditScore}</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-[var(--morandi-muted-foreground)]">申請日期</span>
                          <span className="font-medium text-[var(--morandi-charcoal)]">{tenant.applicationDate}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-[var(--morandi-muted-foreground)]">AI 評分</span>
                          <span className="font-semibold text-[var(--morandi-mauve)]">{tenant.aiScore}/100</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-[var(--morandi-muted-foreground)]">資料完整度</span>
                          <span className="font-medium text-[var(--morandi-charcoal)]">{tenant.profileComplete}%</span>
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="text-sm text-[var(--morandi-muted-foreground)] mb-2">租屋經驗</div>
                      <div className="text-sm text-[var(--morandi-charcoal)]">{tenant.rentHistory}</div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {tenant.tags.map((tag: string) => (
                        <span
                          key={tag}
                          className="px-3 py-1 bg-[var(--morandi-muted)] text-[var(--morandi-charcoal)] rounded-full text-xs font-medium"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    <div className="grid grid-cols-4 gap-3">
                      {[
                        { key: 'id', label: '身分證', value: tenant.documents.id },
                        { key: 'income', label: '收入證明', value: tenant.documents.income },
                        { key: 'employment', label: '在職證明', value: tenant.documents.employment },
                        { key: 'credit', label: '信用報告', value: tenant.documents.credit },
                      ].map(({ key, label, value }) => (
                        <div
                          key={key}
                          className={`p-3 rounded-xl border-2 text-center ${
                            value
                              ? 'bg-[var(--morandi-sage)]/10 border-[var(--morandi-sage)]/30'
                              : 'bg-[var(--morandi-muted)] border-[var(--morandi-stone)]'
                          }`}
                        >
                          {value ? (
                            <CheckCircle2 className="w-5 h-5 text-[var(--morandi-sage)] mx-auto mb-1" />
                          ) : (
                            <Clock className="w-5 h-5 text-[var(--morandi-muted-foreground)] mx-auto mb-1" />
                          )}
                          <div className="text-xs text-[var(--morandi-charcoal)]">{label}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="lg:w-64 flex flex-col gap-3">
                    <div className="bg-gradient-to-br from-[var(--morandi-sage)]/10 to-[var(--morandi-slate)]/10 p-4 rounded-xl border border-[var(--morandi-sage)]/20">
                      <div className="text-center mb-3">
                        <div className="text-4xl font-bold text-[var(--morandi-sage)] mb-1">{tenant.aiScore}</div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)]">AI 契合度評分</div>
                      </div>
                      <Progress value={tenant.aiScore} className="h-2" />
                    </div>

                    <div className="bg-[var(--morandi-muted)] p-4 rounded-xl">
                      <div className="text-sm font-medium text-[var(--morandi-charcoal)] mb-2">感興趣物件</div>
                      <div className="text-sm text-[var(--morandi-muted-foreground)]">{tenant.propertyInterested}</div>
                    </div>

                    {tenant.status === '審核中' && (
                      <div className="space-y-2">
                        <button className="w-full py-3 bg-[var(--morandi-sage)] text-white rounded-xl hover:bg-[var(--morandi-sage-light)] transition-colors font-medium shadow-md">
                          核准申請
                        </button>
                        <button className="w-full py-3 bg-white text-[var(--morandi-charcoal)] border border-[var(--morandi-stone)] rounded-xl hover:bg-[var(--morandi-muted)] transition-colors font-medium">
                          婉拒申請
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </TabsContent>

          {/* Contracts Tab */}
          <TabsContent value="contracts" className="space-y-4">
            {contracts.map((contract) => (
              <div
                key={contract.id}
                className="bg-white rounded-2xl p-6 shadow-md hover:shadow-lg transition-shadow border border-[var(--morandi-stone)]"
              >
                <div className="flex flex-col lg:flex-row gap-6">
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-[var(--morandi-charcoal)] mb-1">
                          {contract.tenantName}
                        </h3>
                        <div className="text-sm text-[var(--morandi-muted-foreground)]">{contract.propertyAddress}</div>
                      </div>
                      <div className={`px-4 py-2 rounded-xl font-medium text-sm ${
                        contract.status === '執行中'
                          ? 'bg-[var(--morandi-sage)]/10 text-[var(--morandi-sage)] border border-[var(--morandi-sage)]/20'
                          : 'bg-[var(--morandi-mauve)]/10 text-[var(--morandi-mauve)] border border-[var(--morandi-mauve)]/20'
                      }`}>
                        {contract.status}
                      </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4 mb-4">
                      <div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)] mb-1">租約期間</div>
                        <div className="font-medium text-[var(--morandi-charcoal)]">
                          {contract.startDate} ~ {contract.endDate}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)] mb-1">月租金</div>
                        <div className="text-xl font-bold text-[var(--morandi-sage)]">
                          ${contract.monthlyRent.toLocaleString()}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)] mb-1">押金</div>
                        <div className="font-medium text-[var(--morandi-charcoal)]">
                          ${contract.deposit.toLocaleString()}
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-[var(--morandi-muted-foreground)]">簽約進度</span>
                        <span className="font-semibold text-[var(--morandi-sage)]">{contract.progress}%</span>
                      </div>
                      <Progress value={contract.progress} className="h-2" />
                    </div>

                    {contract.signedDate && (
                      <div className="text-sm text-[var(--morandi-muted-foreground)]">
                        簽約日期：{contract.signedDate}
                      </div>
                    )}

                    {contract.nextPaymentDate && (
                      <div className="text-sm text-[var(--morandi-muted-foreground)]">
                        下次繳款日：{contract.nextPaymentDate}
                      </div>
                    )}
                  </div>

                  <div className="lg:w-48 flex flex-col gap-2">
                    <button className="py-3 bg-white text-[var(--morandi-charcoal)] border border-[var(--morandi-stone)] rounded-xl hover:bg-[var(--morandi-muted)] transition-colors font-medium flex items-center justify-center gap-2">
                      <FileCheck className="w-4 h-4" />
                      查看合約
                    </button>
                    {contract.status === '待簽約' && (
                      <button className="py-3 bg-[var(--morandi-sage)] text-white rounded-xl hover:bg-[var(--morandi-sage-light)] transition-colors font-medium">
                        完成簽約
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </TabsContent>

          {/* Rent Payments Tab */}
          <TabsContent value="payments" className="space-y-4">
            {rentPayments.map((payment) => (
              <div
                key={payment.id}
                className="bg-white rounded-2xl p-6 shadow-md hover:shadow-lg transition-shadow border border-[var(--morandi-stone)]"
              >
                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-[var(--morandi-charcoal)] mb-2">
                      {payment.tenantName}
                    </h3>
                    <div className="text-sm text-[var(--morandi-muted-foreground)] mb-3">
                      {payment.propertyAddress}
                    </div>

                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)] mb-1">應繳金額</div>
                        <div className="text-2xl font-bold text-[var(--morandi-charcoal)]">
                          ${payment.amount.toLocaleString()}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)] mb-1">應繳日期</div>
                        <div className="font-medium text-[var(--morandi-charcoal)]">{payment.dueDate}</div>
                      </div>
                      <div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)] mb-1">
                          {payment.status === '已繳納' ? '繳納日期' : '繳納方式'}
                        </div>
                        <div className="font-medium text-[var(--morandi-charcoal)]">
                          {payment.status === '已繳納' ? payment.paidDate : payment.method || '待確認'}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-3">
                    <div className={`px-6 py-2 rounded-xl font-medium ${
                      payment.status === '已繳納'
                        ? 'bg-[var(--morandi-sage)]/10 text-[var(--morandi-sage)] border border-[var(--morandi-sage)]/20'
                        : 'bg-[var(--morandi-mauve)]/10 text-[var(--morandi-mauve)] border border-[var(--morandi-mauve)]/20'
                    }`}>
                      {payment.status}
                    </div>
                    {payment.status === '待繳納' && (
                      <button className="px-6 py-2 bg-white text-[var(--morandi-charcoal)] border border-[var(--morandi-stone)] rounded-xl hover:bg-[var(--morandi-muted)] transition-colors text-sm font-medium">
                        發送提醒
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </TabsContent>

          {/* Maintenance Tab */}
          <TabsContent value="maintenance" className="space-y-4">
            {maintenanceRequests.map((request) => (
              <div
                key={request.id}
                className="bg-white rounded-2xl p-6 shadow-md hover:shadow-lg transition-shadow border border-[var(--morandi-stone)]"
              >
                <div className="flex flex-col lg:flex-row gap-6">
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-[var(--morandi-charcoal)] mb-1">
                          {request.issue}
                        </h3>
                        <div className="text-sm text-[var(--morandi-muted-foreground)]">
                          {request.tenantName} · {request.propertyAddress}
                        </div>
                      </div>
                      <div className={`px-4 py-1.5 rounded-xl font-medium text-sm ${
                        request.urgency === '高'
                          ? 'bg-red-50 text-red-600 border border-red-200'
                          : request.urgency === '中'
                          ? 'bg-[var(--morandi-mauve)]/10 text-[var(--morandi-mauve)] border border-[var(--morandi-mauve)]/20'
                          : 'bg-[var(--morandi-slate)]/10 text-[var(--morandi-slate)] border border-[var(--morandi-slate)]/20'
                      }`}>
                        {request.urgency}急
                      </div>
                    </div>

                    <div className="bg-[var(--morandi-muted)] p-4 rounded-xl mb-4">
                      <div className="text-sm text-[var(--morandi-charcoal)]">{request.description}</div>
                    </div>

                    <div className="grid md:grid-cols-4 gap-4">
                      <div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)] mb-1">類別</div>
                        <div className="font-medium text-[var(--morandi-charcoal)]">{request.category}</div>
                      </div>
                      <div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)] mb-1">回報日期</div>
                        <div className="font-medium text-[var(--morandi-charcoal)]">{request.reportDate}</div>
                      </div>
                      <div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)] mb-1">預估費用</div>
                        <div className="font-semibold text-[var(--morandi-sage)]">
                          ${request.estimatedCost.toLocaleString()}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-[var(--morandi-muted-foreground)] mb-1">處理師傅</div>
                        <div className="font-medium text-[var(--morandi-charcoal)]">{request.assignedTo}</div>
                      </div>
                    </div>
                  </div>

                  <div className="lg:w-48 flex flex-col gap-2">
                    <div className={`px-4 py-2 rounded-xl font-medium text-sm text-center ${
                      request.status === '已完成'
                        ? 'bg-[var(--morandi-sage)]/10 text-[var(--morandi-sage)] border border-[var(--morandi-sage)]/20'
                        : request.status === '已派工'
                        ? 'bg-[var(--morandi-slate)]/10 text-[var(--morandi-slate)] border border-[var(--morandi-slate)]/20'
                        : 'bg-[var(--morandi-mauve)]/10 text-[var(--morandi-mauve)] border border-[var(--morandi-mauve)]/20'
                    }`}>
                      {request.status}
                    </div>

                    {request.scheduledDate && (
                      <div className="text-sm text-center">
                        <div className="text-[var(--morandi-muted-foreground)]">預計處理</div>
                        <div className="font-medium text-[var(--morandi-charcoal)]">{request.scheduledDate}</div>
                      </div>
                    )}

                    {request.completedDate && (
                      <div className="text-sm text-center">
                        <div className="text-[var(--morandi-muted-foreground)]">完成日期</div>
                        <div className="font-medium text-[var(--morandi-sage)]">{request.completedDate}</div>
                      </div>
                    )}

                    {request.status !== '已完成' && (
                      <button className="py-2 bg-white text-[var(--morandi-charcoal)] border border-[var(--morandi-stone)] rounded-xl hover:bg-[var(--morandi-muted)] transition-colors text-sm font-medium">
                        更新狀態
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </TabsContent>

          {/* Tax Calculator Tab */}
          <TabsContent value="tax" className="space-y-6">
            <div className="bg-gradient-to-br from-[var(--morandi-sage)]/10 via-white to-[var(--morandi-slate)]/10 rounded-3xl p-8 border-2 border-[var(--morandi-sage)]/20 shadow-lg">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-14 h-14 bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] rounded-2xl flex items-center justify-center shadow-md">
                  <Shield className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-[var(--morandi-charcoal)]">公益出租人節稅試算</h2>
                  <p className="text-sm text-[var(--morandi-muted-foreground)]">{taxBenefits.description}</p>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div>
                  <label className="block text-sm font-medium text-[var(--morandi-charcoal)] mb-2">
                    每月租金收入
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--morandi-muted-foreground)]">$</span>
                    <input
                      type="number"
                      value={monthlyRent}
                      onChange={(e) => setMonthlyRent(parseInt(e.target.value) || 0)}
                      className="w-full pl-8 pr-4 py-3 bg-white rounded-xl border-2 border-[var(--morandi-stone)] focus:border-[var(--morandi-sage)] focus:ring-2 focus:ring-[var(--morandi-sage)]/20 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--morandi-charcoal)] mb-2">
                    年度地價稅
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--morandi-muted-foreground)]">$</span>
                    <input
                      type="number"
                      value={landTax}
                      onChange={(e) => setLandTax(parseInt(e.target.value) || 0)}
                      className="w-full pl-8 pr-4 py-3 bg-white rounded-xl border-2 border-[var(--morandi-stone)] focus:border-[var(--morandi-sage)] focus:ring-2 focus:ring-[var(--morandi-sage)]/20 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--morandi-charcoal)] mb-2">
                    年度房屋稅
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--morandi-muted-foreground)]">$</span>
                    <input
                      type="number"
                      value={houseTax}
                      onChange={(e) => setHouseTax(parseInt(e.target.value) || 0)}
                      className="w-full pl-8 pr-4 py-3 bg-white rounded-xl border-2 border-[var(--morandi-stone)] focus:border-[var(--morandi-sage)] focus:ring-2 focus:ring-[var(--morandi-sage)]/20 transition-all"
                    />
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-white rounded-2xl p-6 shadow-md border border-[var(--morandi-stone)]">
                  <h3 className="text-lg font-semibold text-[var(--morandi-charcoal)] mb-4 flex items-center gap-2">
                    <Award className="w-5 h-5 text-[var(--morandi-sage)]" />
                    年度節稅明細
                  </h3>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-[var(--morandi-stone)]">
                      <span className="text-[var(--morandi-muted-foreground)]">租金所得免稅額</span>
                      <span className="font-semibold text-[var(--morandi-sage)]">
                        ${savedIncomeTax.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center justify-between pb-3 border-b border-[var(--morandi-stone)]">
                      <span className="text-[var(--morandi-muted-foreground)]">地價稅節省</span>
                      <span className="font-semibold text-[var(--morandi-slate)]">
                        ${savedLandTax.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center justify-between pb-3 border-b border-[var(--morandi-stone)]">
                      <span className="text-[var(--morandi-muted-foreground)]">房屋稅節省</span>
                      <span className="font-semibold text-[var(--morandi-mauve)]">
                        ${savedHouseTax.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center justify-between pt-3">
                      <span className="text-lg font-semibold text-[var(--morandi-charcoal)]">年度總節稅</span>
                      <span className="text-2xl font-bold text-[var(--morandi-sage)]">
                        ${totalAnnualSavings.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] rounded-2xl p-6 shadow-xl text-white">
                  <h3 className="text-lg font-semibold mb-4">實際收益分析</h3>

                  <div className="space-y-4 mb-6">
                    <div>
                      <div className="text-sm text-white/80 mb-1">課稅所得（60%免稅）</div>
                      <div className="text-2xl font-bold">${taxableincome.toLocaleString()}</div>
                    </div>

                    <div>
                      <div className="text-sm text-white/80 mb-1">每月實際節省</div>
                      <div className="text-3xl font-bold">
                        ${Math.round(totalAnnualSavings / 12).toLocaleString()}
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4 border border-white/30">
                    <div className="text-sm text-white/90 mb-2">
                      💡 <strong>專業建議</strong>
                    </div>
                    <p className="text-sm text-white/80 leading-relaxed">
                      成為公益出租人後，您每年可節省 <strong>${totalAnnualSavings.toLocaleString()}</strong>，
                      相當於每月增加 <strong>${Math.round(totalAnnualSavings / 12).toLocaleString()}</strong> 收入。
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-center">
                <button className="px-8 py-4 bg-white text-[var(--morandi-sage)] rounded-xl hover:bg-[var(--morandi-warm-white)] transition-all duration-300 shadow-lg hover:shadow-xl font-semibold flex items-center gap-2">
                  <FileCheck className="w-5 h-5" />
                  申請成為公益出租人
                </button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
