import { useState } from 'react';
import { Search, MapPin, Home, BadgeCheck, Star, X, TrendingUp, ShoppingBag, Utensils, Hospital, GraduationCap, MessageSquare, ThumbsUp, CheckCircle2, Clock, DollarSign } from 'lucide-react';
import { Property } from '../../mockData';
import { Switch } from '../components/ui/switch';
import { Progress } from '../components/ui/progress';

interface RenterMapViewProps {
  properties: Property[];
  mrtStations: Array<{
    id: number;
    name: string;
    lat: number;
    lng: number;
    line: string;
  }>;
}

export default function RenterMapView({ properties, mrtStations }: RenterMapViewProps) {
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [subsidyOnly, setSubsidyOnly] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 50000]);
  const [selectedDistrict, setSelectedDistrict] = useState<string>('all');
  const [hoveredProperty, setHoveredProperty] = useState<number | null>(null);

  const filteredProperties = properties.filter((p) => {
    if (subsidyOnly && !p.subsidy) return false;
    if (p.price < priceRange[0] || p.price > priceRange[1]) return false;
    if (selectedDistrict !== 'all' && p.district !== selectedDistrict) return false;
    return true;
  });

  const districts = Array.from(new Set(properties.map((p) => p.district)));

  return (
    <div className="h-full flex flex-col lg:flex-row overflow-hidden bg-[var(--morandi-warm-white)]">
      {/* Left Sidebar - Filters & Results */}
      <div className="w-full lg:w-96 xl:w-[450px] bg-white border-r border-[var(--morandi-stone)] flex flex-col overflow-hidden shadow-lg">
        {/* Search & Filters */}
        <div className="p-5 border-b border-[var(--morandi-stone)] space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--morandi-muted-foreground)]" />
            <input
              type="text"
              placeholder="搜尋地點、捷運站、學校..."
              className="w-full pl-10 pr-4 py-3 bg-[var(--morandi-muted)] rounded-xl border-0 focus:ring-2 focus:ring-[var(--morandi-sage)] transition-all"
            />
          </div>

          {/* Subsidy Toggle */}
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-[var(--morandi-sage)]/10 to-[var(--morandi-slate)]/10 rounded-xl border border-[var(--morandi-sage)]/20">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-[var(--morandi-sage)]" />
              <span className="font-medium text-[var(--morandi-charcoal)]">只看租補合格物件</span>
            </div>
            <Switch checked={subsidyOnly} onCheckedChange={setSubsidyOnly} />
          </div>

          {/* District Filter */}
          <div>
            <label className="block text-sm font-medium text-[var(--morandi-charcoal)] mb-2">行政區</label>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="w-full px-4 py-2.5 bg-[var(--morandi-muted)] rounded-lg border-0 focus:ring-2 focus:ring-[var(--morandi-sage)] transition-all"
            >
              <option value="all">全部區域</option>
              {districts.map((district) => (
                <option key={district} value={district}>
                  {district}
                </option>
              ))}
            </select>
          </div>

          {/* Price Range */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-[var(--morandi-charcoal)]">價格範圍</label>
              <span className="text-sm text-[var(--morandi-muted-foreground)]">
                ${priceRange[0].toLocaleString()} - ${priceRange[1].toLocaleString()}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="50000"
              step="1000"
              value={priceRange[1]}
              onChange={(e) => setPriceRange([0, parseInt(e.target.value)])}
              className="w-full accent-[var(--morandi-sage)]"
            />
          </div>

          <div className="text-sm text-[var(--morandi-muted-foreground)] bg-[var(--morandi-muted)] px-3 py-2 rounded-lg">
            找到 <span className="font-semibold text-[var(--morandi-sage)]">{filteredProperties.length}</span> 個符合條件的房源
          </div>
        </div>

        {/* Property List */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-4 space-y-3">
            {filteredProperties.map((property) => (
              <div
                key={property.id}
                className={`bg-white rounded-xl border-2 transition-all duration-300 cursor-pointer hover:shadow-lg ${
                  hoveredProperty === property.id || selectedProperty?.id === property.id
                    ? 'border-[var(--morandi-sage)] shadow-md scale-[1.02]'
                    : 'border-[var(--morandi-stone)] hover:border-[var(--morandi-sage-light)]'
                }`}
                onClick={() => setSelectedProperty(property)}
                onMouseEnter={() => setHoveredProperty(property.id)}
                onMouseLeave={() => setHoveredProperty(null)}
              >
                <div className="flex gap-3 p-3">
                  <div className="relative w-28 h-28 flex-shrink-0 rounded-lg overflow-hidden">
                    <img
                      src={property.images[0]}
                      alt={property.title}
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                    />
                    {property.subsidy && (
                      <div className="absolute top-1 left-1 bg-[var(--morandi-sage)] text-white px-2 py-0.5 rounded-md text-xs font-medium shadow">
                        租補
                      </div>
                    )}
                    <div className="absolute bottom-1 right-1 bg-black/60 text-white px-2 py-0.5 rounded-md text-xs font-medium">
                      {property.aiMatch}%
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-[var(--morandi-charcoal)] mb-1 line-clamp-1">
                      {property.title}
                    </h3>

                    <div className="flex items-center gap-1 text-xs text-[var(--morandi-muted-foreground)] mb-2">
                      <MapPin className="w-3 h-3" />
                      <span className="line-clamp-1">{property.district}</span>
                    </div>

                    <div className="text-xl font-bold text-[var(--morandi-sage)] mb-2">
                      ${property.price.toLocaleString()}
                      <span className="text-xs font-normal text-[var(--morandi-muted-foreground)]">/月</span>
                    </div>

                    <div className="flex items-center gap-3 text-xs text-[var(--morandi-muted-foreground)]">
                      <span>{property.rooms} 房</span>
                      <span>·</span>
                      <span>{property.size} 坪</span>
                      {property.landlord.verified && (
                        <>
                          <span>·</span>
                          <div className="flex items-center gap-0.5 text-[var(--morandi-sage)]">
                            <BadgeCheck className="w-3 h-3" />
                            <span>認證</span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Side - Map & Property Details */}
      <div className="flex-1 relative bg-[var(--morandi-grey-taupe)]">
        {/* Mock Interactive Map */}
        <div className="absolute inset-0 overflow-hidden">
          <svg viewBox="0 0 800 600" className="w-full h-full">
            {/* Background */}
            <rect width="800" height="600" fill="#EBE6E0" />

            {/* Roads */}
            <path d="M 0 200 L 800 200" stroke="#D4CDC3" strokeWidth="3" />
            <path d="M 0 400 L 800 400" stroke="#D4CDC3" strokeWidth="3" />
            <path d="M 300 0 L 300 600" stroke="#D4CDC3" strokeWidth="3" />
            <path d="M 600 0 L 600 600" stroke="#D4CDC3" strokeWidth="3" />

            {/* MRT Stations */}
            {mrtStations.map((station, idx) => {
              const x = 150 + idx * 120;
              const y = 200 + (idx % 2) * 200;
              return (
                <g key={station.id}>
                  <circle cx={x} cy={y} r="8" fill="#98A8B8" stroke="white" strokeWidth="2" />
                  <text x={x} y={y + 25} textAnchor="middle" fontSize="10" fill="#4A4A4A" fontWeight="500">
                    {station.name}
                  </text>
                </g>
              );
            })}

            {/* Property Markers */}
            {filteredProperties.map((property, idx) => {
              const x = 100 + (idx % 5) * 140;
              const y = 100 + Math.floor(idx / 5) * 150;
              const isHovered = hoveredProperty === property.id || selectedProperty?.id === property.id;

              return (
                <g
                  key={property.id}
                  className="cursor-pointer transition-all duration-300"
                  style={{ transform: isHovered ? 'scale(1.2)' : 'scale(1)', transformOrigin: `${x}px ${y}px` }}
                  onMouseEnter={() => setHoveredProperty(property.id)}
                  onMouseLeave={() => setHoveredProperty(null)}
                  onClick={() => setSelectedProperty(property)}
                >
                  <circle
                    cx={x}
                    cy={y}
                    r={isHovered ? "20" : "16"}
                    fill={isHovered ? "#9CAF88" : "#B8C5AA"}
                    stroke="white"
                    strokeWidth="3"
                    className="transition-all duration-300"
                    style={{
                      filter: isHovered ? 'drop-shadow(0 4px 8px rgba(0,0,0,0.2))' : 'drop-shadow(0 2px 4px rgba(0,0,0,0.1))',
                      animation: isHovered ? 'bounce 0.5s ease-in-out' : 'none'
                    }}
                  />
                  <text
                    x={x}
                    y={y + 5}
                    textAnchor="middle"
                    fontSize={isHovered ? "14" : "12"}
                    fill="white"
                    fontWeight="bold"
                  >
                    ${(property.price / 1000).toFixed(0)}K
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Property Detail Popup */}
        {selectedProperty && (
          <div className="absolute bottom-0 left-0 right-0 lg:bottom-auto lg:top-4 lg:right-4 lg:left-auto lg:w-96 bg-white rounded-t-3xl lg:rounded-3xl shadow-2xl overflow-hidden animate-in slide-in-from-bottom lg:slide-in-from-right duration-300 max-h-[80vh] overflow-y-auto">
            <button
              onClick={() => setSelectedProperty(null)}
              className="absolute top-4 right-4 z-10 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg hover:bg-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="relative h-64">
              <img
                src={selectedProperty.images[0]}
                alt={selectedProperty.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />

              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex items-center gap-2 mb-2">
                  {selectedProperty.subsidy && (
                    <div className="bg-[var(--morandi-sage)] text-white px-3 py-1 rounded-full text-sm font-medium shadow-lg flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" />
                      租補合格
                    </div>
                  )}
                  <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium text-[var(--morandi-charcoal)] shadow-lg">
                    AI 契合度 {selectedProperty.aiMatch}%
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6">
              <h2 className="text-2xl font-bold text-[var(--morandi-charcoal)] mb-2">
                {selectedProperty.title}
              </h2>

              <div className="flex items-center gap-2 text-[var(--morandi-muted-foreground)] mb-4">
                <MapPin className="w-4 h-4" />
                <span>{selectedProperty.address}</span>
              </div>

              <div className="flex items-baseline gap-2 mb-6">
                <div className="text-3xl font-bold text-[var(--morandi-sage)]">
                  ${selectedProperty.price.toLocaleString()}
                </div>
                <div className="text-[var(--morandi-muted-foreground)]">/月</div>
                {selectedProperty.subsidy && (
                  <div className="ml-auto text-sm text-[var(--morandi-sage)] bg-[var(--morandi-sage)]/10 px-3 py-1 rounded-lg">
                    可省 ${selectedProperty.subsidyAmount}
                  </div>
                )}
              </div>

              {/* Property Info */}
              <div className="grid grid-cols-3 gap-4 mb-6 p-4 bg-[var(--morandi-muted)] rounded-xl">
                <div className="text-center">
                  <div className="text-2xl font-bold text-[var(--morandi-charcoal)]">{selectedProperty.rooms}</div>
                  <div className="text-xs text-[var(--morandi-muted-foreground)]">房間</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-[var(--morandi-charcoal)]">{selectedProperty.size}</div>
                  <div className="text-xs text-[var(--morandi-muted-foreground)]">坪數</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-[var(--morandi-charcoal)]">{selectedProperty.floor}</div>
                  <div className="text-xs text-[var(--morandi-muted-foreground)]">樓層</div>
                </div>
              </div>

              {/* Commute Info */}
              <div className="mb-6 p-4 bg-gradient-to-r from-[var(--morandi-slate)]/10 to-[var(--morandi-sage)]/10 rounded-xl border border-[var(--morandi-slate)]/20">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-5 h-5 text-[var(--morandi-slate)]" />
                  <span className="font-semibold text-[var(--morandi-charcoal)]">通勤資訊</span>
                </div>
                <div className="text-sm">
                  <span className="text-[var(--morandi-muted-foreground)]">步行至</span>{' '}
                  <span className="font-medium text-[var(--morandi-charcoal)]">{selectedProperty.commute.mrt}</span>{' '}
                  <span className="text-[var(--morandi-muted-foreground)]">約</span>{' '}
                  <span className="font-semibold text-[var(--morandi-slate)]">{selectedProperty.commute.walkTime} 分鐘</span>
                  <span className="text-[var(--morandi-muted-foreground)]">（{selectedProperty.commute.distance}m）</span>
                </div>
              </div>

              {/* Life Scores */}
              <div className="mb-6">
                <h3 className="font-semibold text-[var(--morandi-charcoal)] mb-3 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[var(--morandi-sage)]" />
                  生活機能評分
                </h3>
                <div className="space-y-2.5">
                  {[
                    { icon: MapPin, label: '交通', score: selectedProperty.lifeScores.transport, color: '#9CAF88' },
                    { icon: ShoppingBag, label: '購物', score: selectedProperty.lifeScores.shopping, color: '#98A8B8' },
                    { icon: Utensils, label: '餐飲', score: selectedProperty.lifeScores.dining, color: '#AFA3B0' },
                    { icon: Hospital, label: '醫療', score: selectedProperty.lifeScores.medical, color: '#B8C5AA' },
                    { icon: GraduationCap, label: '教育', score: selectedProperty.lifeScores.education, color: '#C4B5C7' },
                  ].map(({ icon: Icon, label, score, color }) => (
                    <div key={label} className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4" style={{ color }} />
                          <span className="text-[var(--morandi-charcoal)]">{label}</span>
                        </div>
                        <span className="font-semibold" style={{ color }}>{score}</span>
                      </div>
                      <Progress value={score} className="h-1.5" style={{ '--progress-background': color } as React.CSSProperties} />
                    </div>
                  ))}
                </div>
              </div>

              {/* Landlord Info */}
              <div className="mb-6 p-4 bg-white border border-[var(--morandi-stone)] rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] rounded-full flex items-center justify-center text-white font-semibold">
                      {selectedProperty.landlord.name[0]}
                    </div>
                    <div>
                      <div className="flex items-center gap-1">
                        <span className="font-medium text-[var(--morandi-charcoal)]">{selectedProperty.landlord.name}</span>
                        {selectedProperty.landlord.verified && (
                          <BadgeCheck className="w-4 h-4 text-[var(--morandi-sage)]" />
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-xs text-[var(--morandi-muted-foreground)]">
                        <Star className="w-3 h-3 fill-[var(--morandi-mauve)] text-[var(--morandi-mauve)]" />
                        <span>{selectedProperty.landlord.rating}</span>
                        <span>·</span>
                        <span>回覆率 {selectedProperty.landlord.responseRate}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Reviews */}
              <div className="mb-6">
                <h3 className="font-semibold text-[var(--morandi-charcoal)] mb-3 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-[var(--morandi-mauve)]" />
                  匿名評論 ({selectedProperty.reviews.length})
                </h3>
                <div className="space-y-3">
                  {selectedProperty.reviews.map((review) => (
                    <div key={review.id} className="p-4 bg-[var(--morandi-muted)] rounded-xl">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-[var(--morandi-charcoal)]">{review.author}</span>
                        <div className="flex items-center gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3.5 h-3.5 ${
                                i < review.rating
                                  ? 'fill-[var(--morandi-mauve)] text-[var(--morandi-mauve)]'
                                  : 'text-[var(--morandi-stone)]'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-sm text-[var(--morandi-charcoal)] mb-2">{review.content}</p>
                      <div className="flex items-center justify-between text-xs text-[var(--morandi-muted-foreground)]">
                        <span>{review.date}</span>
                        <button className="flex items-center gap-1 hover:text-[var(--morandi-sage)] transition-colors">
                          <ThumbsUp className="w-3 h-3" />
                          <span>有幫助 ({review.helpful})</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contact Button */}
              <button className="w-full py-4 bg-gradient-to-r from-[var(--morandi-sage)] to-[var(--morandi-slate)] text-white rounded-xl hover:shadow-lg transition-all duration-300 hover:scale-[1.02] font-semibold">
                聯絡房東
              </button>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
      `}</style>
    </div>
  );
}
