// Mock Data for 棲居 (Habitat) Rental Platform MVP

export interface Property {
  id: number;
  title: string;
  address: string;
  district: string;
  price: number;
  size: number;
  rooms: number;
  bathrooms: number;
  floor: string;
  type: '雅房' | '套房' | '整層住家' | '公寓' | '電梯大樓' | '樓中樓';
  lat: number;
  lng: number;
  images: string[];
  features: string[];
  furniture: string[];
  landlord: { name: string; verified: boolean; rating: number; responseRate: number };
  subsidy: boolean;
  subsidyAmount: number;
  lifeScores: { transport: number; shopping: number; dining: number; medical: number; education: number };
  commute: { mrt: string; distance: number; walkTime: number };
  reviews: Array<{ id: number; author: string; rating: number; date: string; content: string; helpful: number }>;
  aiMatch: number;
  matchReasons: string[];
}

const makeReview = (id: number, author: string, rating: number, date: string, content: string, helpful: number) =>
  ({ id, author, rating, date, content, helpful });

const makeScores = (t: number, s: number, d: number, m: number, e: number) =>
  ({ transport: t, shopping: s, dining: d, medical: m, education: e });

export const properties: Property[] = [
  // ── 10 共租雅房 ────────────────────────────────────────────────────────────
  {
    id: 101, title: '大安溫馨雅房', address: '台北市大安區和平東路二段', district: '大安區',
    price: 8500, size: 9, rooms: 1, bathrooms: 1, floor: '3/5', type: '雅房',
    lat: 25.0282, lng: 121.5395,
    images: ['https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?w=800&h=600&fit=crop',
             'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&h=600&fit=crop'],
    features: ['採光佳', '租補合格', '近師大夜市'], furniture: ['衣櫃', '書桌'],
    landlord: { name: '陳先生', verified: true, rating: 4.7, responseRate: 92 },
    subsidy: true, subsidyAmount: 2400,
    lifeScores: makeScores(88, 85, 95, 80, 92),
    commute: { mrt: '大安森林公園站', distance: 400, walkTime: 6 },
    reviews: [makeReview(1, '匿名租客 A', 5, '2026-05-10', '房東好溝通，衣櫃空間充足，採光很好！', 11)],
    aiMatch: 84, matchReasons: ['通勤便利', '價格實惠', '生活機能優']
  },
  {
    id: 102, title: '中山捷運雅房', address: '台北市中山區長安東路一段', district: '中山區',
    price: 7800, size: 8, rooms: 1, bathrooms: 1, floor: '4/6', type: '雅房',
    lat: 25.0487, lng: 121.5260,
    images: ['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&h=600&fit=crop'],
    features: ['近捷運', '包水費', '租補合格'], furniture: ['冷氣', '衣櫃'],
    landlord: { name: '王小姐', verified: true, rating: 4.5, responseRate: 88 },
    subsidy: true, subsidyAmount: 2400,
    lifeScores: makeScores(95, 90, 88, 82, 78),
    commute: { mrt: '中山站', distance: 250, walkTime: 4 },
    reviews: [makeReview(1, '匿名租客 B', 4, '2026-04-20', '捷運步行超近，冷氣很重要夏天有就很好。', 8)],
    aiMatch: 79, matchReasons: ['步行至捷運', '含冷氣', '價格親民']
  },
  {
    id: 103, title: '中正北科雅房', address: '台北市中正區八德路三段', district: '中正區',
    price: 8000, size: 10, rooms: 1, bathrooms: 1, floor: '2/4', type: '雅房',
    lat: 25.0415, lng: 121.5295,
    images: ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=600&fit=crop'],
    features: ['近北科大', '安靜社區', '租補合格'], furniture: ['雙人床', '書桌'],
    landlord: { name: '林太太', verified: true, rating: 4.6, responseRate: 90 },
    subsidy: true, subsidyAmount: 2400,
    lifeScores: makeScores(85, 80, 82, 88, 95),
    commute: { mrt: '忠孝新生站', distance: 350, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 C', 5, '2026-05-01', '離北科大超近，書桌很大很好用。', 14)],
    aiMatch: 88, matchReasons: ['近北科大', '書桌充足', '安靜適合讀書']
  },
  {
    id: 104, title: '松山採光雅房', address: '台北市松山區八德路四段', district: '松山區',
    price: 9000, size: 11, rooms: 1, bathrooms: 1, floor: '5/7', type: '雅房',
    lat: 25.0495, lng: 121.5640,
    images: ['https://images.unsplash.com/photo-1536376072261-38c75010e6c9?w=800&h=600&fit=crop'],
    features: ['全套家具', '採光佳', '電梯', '租補合格'], furniture: ['冷氣', '衣櫃', '書桌', '雙人床'],
    landlord: { name: '黃先生', verified: true, rating: 4.8, responseRate: 94 },
    subsidy: true, subsidyAmount: 2400,
    lifeScores: makeScores(88, 92, 85, 80, 76),
    commute: { mrt: '松山站', distance: 300, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 D', 5, '2026-04-15', '全套家具搬進來就能住，超方便！', 18)],
    aiMatch: 91, matchReasons: ['全套家具', '採光佳', '電梯建築']
  },
  {
    id: 105, title: '萬華小資雅房', address: '台北市萬華區西藏路', district: '萬華區',
    price: 7000, size: 7, rooms: 1, bathrooms: 1, floor: '3/5', type: '雅房',
    lat: 25.0355, lng: 121.4985,
    images: ['https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&h=600&fit=crop'],
    features: ['超值', '包水電', '生活機能佳', '租補合格'], furniture: ['衣櫃'],
    landlord: { name: '李太太', verified: false, rating: 4.2, responseRate: 75 },
    subsidy: true, subsidyAmount: 2400,
    lifeScores: makeScores(82, 88, 92, 78, 68),
    commute: { mrt: '龍山寺站', distance: 480, walkTime: 7 },
    reviews: [makeReview(1, '匿名租客 E', 4, '2026-03-12', '價格最便宜的一區，包水電很省心。', 9)],
    aiMatch: 70, matchReasons: ['最佳性價比', '包水電', '夜市生活圈']
  },
  {
    id: 106, title: '板橋便捷雅房', address: '新北市板橋區文化路一段', district: '板橋區',
    price: 7500, size: 9, rooms: 1, bathrooms: 1, floor: '2/5', type: '雅房',
    lat: 25.0135, lng: 121.4648,
    images: ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop'],
    features: ['近新埔站', '含洗衣機', '租補合格'], furniture: ['洗衣機'],
    landlord: { name: '吳先生', verified: true, rating: 4.4, responseRate: 85 },
    subsidy: true, subsidyAmount: 2400,
    lifeScores: makeScores(90, 85, 80, 82, 75),
    commute: { mrt: '新埔站', distance: 380, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 F', 4, '2026-05-20', '有洗衣機很方便，不用去外面洗。', 7)],
    aiMatch: 75, matchReasons: ['含洗衣機', '捷運近', '板橋生活圈']
  },
  {
    id: 107, title: '三重公寓雅房', address: '新北市三重區三和路四段', district: '三重區',
    price: 6800, size: 8, rooms: 1, bathrooms: 1, floor: '3/4', type: '雅房',
    lat: 25.0635, lng: 121.4880,
    images: ['https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop'],
    features: ['超值', '含冷氣', '生活機能佳', '租補合格'], furniture: ['冷氣'],
    landlord: { name: '鄭太太', verified: true, rating: 4.3, responseRate: 80 },
    subsidy: true, subsidyAmount: 2400,
    lifeScores: makeScores(85, 82, 78, 75, 70),
    commute: { mrt: '三重站', distance: 550, walkTime: 8 },
    reviews: [makeReview(1, '匿名租客 G', 4, '2026-04-08', '三重房租便宜很多，冷氣必備超實用。', 6)],
    aiMatch: 68, matchReasons: ['超值租金', '含冷氣', '雙北生活圈']
  },
  {
    id: 108, title: '中和溫暖雅房', address: '新北市中和區景平路', district: '中和區',
    price: 7200, size: 9, rooms: 1, bathrooms: 1, floor: '4/5', type: '雅房',
    lat: 24.9978, lng: 121.5018,
    images: ['https://images.unsplash.com/photo-1502672023488-70e25813eb80?w=800&h=600&fit=crop'],
    features: ['安靜巷弄', '租補合格', '近景安站'], furniture: ['雙人床', '衣櫃'],
    landlord: { name: '許先生', verified: true, rating: 4.5, responseRate: 87 },
    subsidy: true, subsidyAmount: 2400,
    lifeScores: makeScores(88, 80, 78, 82, 72),
    commute: { mrt: '景安站', distance: 420, walkTime: 6 },
    reviews: [makeReview(1, '匿名租客 H', 5, '2026-04-30', '雙人床和衣櫃都有，省了買家具的費用。', 13)],
    aiMatch: 76, matchReasons: ['含雙人床', '安靜環境', '近捷運']
  },
  {
    id: 109, title: '永和頂溪雅房', address: '新北市永和區永和路二段', district: '永和區',
    price: 7400, size: 9, rooms: 1, bathrooms: 1, floor: '5/6', type: '雅房',
    lat: 25.0098, lng: 121.5162,
    images: ['https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&h=600&fit=crop'],
    features: ['全套家具', '採光好', '租補合格'], furniture: ['冷氣', '衣櫃', '書桌', '雙人床'],
    landlord: { name: '蘇小姐', verified: true, rating: 4.6, responseRate: 91 },
    subsidy: true, subsidyAmount: 2400,
    lifeScores: makeScores(90, 85, 82, 80, 74),
    commute: { mrt: '頂溪站', distance: 310, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 I', 5, '2026-05-14', '全套家具，超級省事！頂溪站步行可達。', 16)],
    aiMatch: 82, matchReasons: ['全套家具', '近頂溪站', '性價比高']
  },
  {
    id: 110, title: '新莊輔大雅房', address: '新北市新莊區中正路', district: '新莊區',
    price: 6900, size: 8, rooms: 1, bathrooms: 1, floor: '2/4', type: '雅房',
    lat: 25.0363, lng: 121.4495,
    images: ['https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop'],
    features: ['近輔大', '含書桌', '租補合格'], furniture: ['書桌'],
    landlord: { name: '方先生', verified: false, rating: 4.3, responseRate: 78 },
    subsidy: true, subsidyAmount: 2400,
    lifeScores: makeScores(80, 78, 75, 72, 88),
    commute: { mrt: '輔大站', distance: 600, walkTime: 8 },
    reviews: [makeReview(1, '匿名租客 J', 4, '2026-03-25', '輔大學生很多在這附近，生活圈不錯。', 5)],
    aiMatch: 65, matchReasons: ['學區周邊', '含書桌', '最優惠租金']
  },

  // ── 20 套房 ────────────────────────────────────────────────────────────────
  {
    id: 201, title: '信義奢華套房', address: '台北市信義區松仁路', district: '信義區',
    price: 22000, size: 22, rooms: 1, bathrooms: 1, floor: '10/15', type: '套房',
    lat: 25.0375, lng: 121.5645,
    images: ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=600&fit=crop',
             'https://images.unsplash.com/photo-1536376072261-38c75010e6c9?w=800&h=600&fit=crop'],
    features: ['電梯', '健身房', '視野佳', '租補合格'], furniture: ['洗衣機', '衣櫃', '雙人床'],
    landlord: { name: '林小姐', verified: true, rating: 4.9, responseRate: 98 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(85, 98, 92, 88, 82),
    commute: { mrt: '象山站', distance: 280, walkTime: 4 },
    reviews: [makeReview(1, '匿名租客 K', 5, '2026-05-28', '信義豪宅區，獨立洗烘衣機超好用！', 15)],
    aiMatch: 93, matchReasons: ['高端配備', '信義商圈', '獨立洗衣']
  },
  {
    id: 202, title: '大安精品套房', address: '台北市大安區復興南路二段', district: '大安區',
    price: 18000, size: 18, rooms: 1, bathrooms: 1, floor: '7/10', type: '套房',
    lat: 25.0332, lng: 121.5430,
    images: ['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&h=600&fit=crop'],
    features: ['近捷運', '採光佳', '租補合格'], furniture: ['冰箱', '冷氣', '流理台'],
    landlord: { name: '張先生', verified: true, rating: 4.8, responseRate: 95 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(92, 88, 95, 85, 90),
    commute: { mrt: '大安站', distance: 350, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 L', 5, '2026-05-15', '附冰箱和流理台，料理很方便！', 12)],
    aiMatch: 89, matchReasons: ['含廚房設備', '大安學區', '採光良好']
  },
  {
    id: 203, title: '中山現代套房', address: '台北市中山區民生東路二段', district: '中山區',
    price: 16500, size: 16, rooms: 1, bathrooms: 1, floor: '8/12', type: '套房',
    lat: 25.0521, lng: 121.5338,
    images: ['https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&h=600&fit=crop'],
    features: ['含陽台', '獨立洗衣機', '租補合格'], furniture: ['洗衣機', '冷氣'],
    landlord: { name: '王先生', verified: true, rating: 4.7, responseRate: 93 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(90, 90, 88, 82, 80),
    commute: { mrt: '中山國中站', distance: 420, walkTime: 6 },
    reviews: [makeReview(1, '匿名租客 M', 5, '2026-04-22', '有陽台可以晾衣服，加上獨立洗衣機完美！', 10)],
    aiMatch: 87, matchReasons: ['含陽台', '獨立洗衣機', '高樓層']
  },
  {
    id: 204, title: '松山景觀套房', address: '台北市松山區南京東路五段', district: '松山區',
    price: 17500, size: 20, rooms: 1, bathrooms: 1, floor: '12/15', type: '套房',
    lat: 25.0511, lng: 121.5688,
    images: ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop'],
    features: ['全套家具', '大衣櫃', '高樓景觀', '租補合格'], furniture: ['冷氣', '衣櫃', '雙人床', '冰箱'],
    landlord: { name: '楊小姐', verified: true, rating: 4.6, responseRate: 89 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(87, 85, 90, 78, 76),
    commute: { mrt: '後山埤站', distance: 380, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 N', 5, '2026-05-05', '高樓景觀超美，大衣櫃收納超好！', 19)],
    aiMatch: 90, matchReasons: ['全套家具', '高樓景觀', '大收納空間']
  },
  {
    id: 205, title: '中正新生套房', address: '台北市中正區新生南路一段', district: '中正區',
    price: 16000, size: 15, rooms: 1, bathrooms: 1, floor: '4/7', type: '套房',
    lat: 25.0438, lng: 121.5302,
    images: ['https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?w=800&h=600&fit=crop'],
    features: ['獨立衛浴', '含冷氣', '近台大', '租補合格'], furniture: ['冷氣'],
    landlord: { name: '陳太太', verified: true, rating: 4.5, responseRate: 86 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(86, 82, 88, 85, 96),
    commute: { mrt: '古亭站', distance: 450, walkTime: 6 },
    reviews: [makeReview(1, '匿名租客 O', 4, '2026-04-10', '近台大商圈，獨立衛浴是必須。', 8)],
    aiMatch: 85, matchReasons: ['台大學區', '獨立衛浴', '含冷氣']
  },
  {
    id: 206, title: '內湖科技套房', address: '台北市內湖區瑞光路', district: '內湖區',
    price: 15500, size: 17, rooms: 1, bathrooms: 1, floor: '6/12', type: '套房',
    lat: 25.0675, lng: 121.5780,
    images: ['https://images.unsplash.com/photo-1502672023488-70e25813eb80?w=800&h=600&fit=crop'],
    features: ['近科學園區', '附停車', '租補合格'], furniture: ['冰箱', '洗衣機', '書桌'],
    landlord: { name: '黃先生', verified: true, rating: 4.7, responseRate: 92 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(80, 85, 80, 80, 78),
    commute: { mrt: '文湖線', distance: 600, walkTime: 8 },
    reviews: [makeReview(1, '匿名租客 P', 5, '2026-05-18', '科技園區上班族首選，冰箱洗衣機都有。', 14)],
    aiMatch: 83, matchReasons: ['科技園區步行圈', '完整家電', '有書桌']
  },
  {
    id: 207, title: '南港軟體套房', address: '台北市南港區三重路', district: '南港區',
    price: 19000, size: 20, rooms: 1, bathrooms: 1, floor: '9/14', type: '套房',
    lat: 25.0525, lng: 121.6065,
    images: ['https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop'],
    features: ['全新裝潢', '大衣櫃', '電梯', '租補合格'], furniture: ['衣櫃', '雙人床', '冰箱'],
    landlord: { name: '吳先生', verified: true, rating: 4.8, responseRate: 96 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(88, 80, 82, 78, 75),
    commute: { mrt: '南港展覽館站', distance: 320, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 Q', 5, '2026-05-25', '全新衣櫃超大，雙人床很舒服！', 17)],
    aiMatch: 88, matchReasons: ['全新裝潢', '大雙人床', '南港科技圈']
  },
  {
    id: 208, title: '板橋新板套房', address: '新北市板橋區新站路', district: '板橋區',
    price: 14500, size: 16, rooms: 1, bathrooms: 1, floor: '5/10', type: '套房',
    lat: 25.0112, lng: 121.4618,
    images: ['https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop'],
    features: ['全套實木家具', '近新板特區', '租補合格'], furniture: ['衣櫃', '雙人床', '書桌', '冷氣'],
    landlord: { name: '鄭先生', verified: true, rating: 4.6, responseRate: 90 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(92, 90, 86, 82, 78),
    commute: { mrt: '板橋站', distance: 280, walkTime: 4 },
    reviews: [makeReview(1, '匿名租客 R', 5, '2026-04-28', '實木家具質感好，新板特區很繁榮！', 11)],
    aiMatch: 86, matchReasons: ['實木家具', '新板特區', '近板橋站']
  },
  {
    id: 209, title: '三重河景套房', address: '新北市三重區重陽路', district: '三重區',
    price: 13000, size: 15, rooms: 1, bathrooms: 1, floor: '8/12', type: '套房',
    lat: 25.0638, lng: 121.4848,
    images: ['https://images.unsplash.com/photo-1536376072261-38c75010e6c9?w=800&h=600&fit=crop'],
    features: ['河景視野', '含冷氣', '獨立洗衣機', '租補合格'], furniture: ['冷氣', '洗衣機'],
    landlord: { name: '李先生', verified: true, rating: 4.5, responseRate: 88 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(85, 80, 75, 78, 70),
    commute: { mrt: '三重國小站', distance: 480, walkTime: 7 },
    reviews: [makeReview(1, '匿名租客 S', 4, '2026-04-14', '高樓河景很舒服，冷氣洗衣機都有！', 9)],
    aiMatch: 77, matchReasons: ['河景高樓', '獨立洗衣機', '含冷氣']
  },
  {
    id: 210, title: '中和景安套房', address: '新北市中和區景安路', district: '中和區',
    price: 12500, size: 14, rooms: 1, bathrooms: 1, floor: '4/8', type: '套房',
    lat: 24.9990, lng: 121.5062,
    images: ['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&h=600&fit=crop'],
    features: ['近景安站', '含熱水器', '租補合格'], furniture: ['熱水器', '雙人床'],
    landlord: { name: '許小姐', verified: true, rating: 4.4, responseRate: 85 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(90, 82, 78, 80, 72),
    commute: { mrt: '景安站', distance: 350, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 T', 4, '2026-05-02', '景安站步行5分鐘，熱水器有含很方便！', 7)],
    aiMatch: 74, matchReasons: ['近景安站', '含熱水器', '性價比優']
  },
  {
    id: 211, title: '永和頂溪套房', address: '新北市永和區文化路', district: '永和區',
    price: 13500, size: 15, rooms: 1, bathrooms: 1, floor: '6/9', type: '套房',
    lat: 25.0108, lng: 121.5188,
    images: ['https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&h=600&fit=crop'],
    features: ['含冰箱冷氣', '衣櫃', '近頂溪站', '租補合格'], furniture: ['衣櫃', '冰箱', '冷氣'],
    landlord: { name: '蔡先生', verified: true, rating: 4.6, responseRate: 91 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(90, 85, 82, 80, 74),
    commute: { mrt: '頂溪站', distance: 300, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 U', 5, '2026-05-10', '衣櫃冰箱冷氣一應俱全，住起來很舒適！', 13)],
    aiMatch: 81, matchReasons: ['三大家電齊全', '近頂溪站', '性價比高']
  },
  {
    id: 212, title: '新莊副都心套房', address: '新北市新莊區思源路', district: '新莊區',
    price: 14000, size: 16, rooms: 1, bathrooms: 1, floor: '7/10', type: '套房',
    lat: 25.0330, lng: 121.4508,
    images: ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop'],
    features: ['全套家電家具', '近副都心', '租補合格'], furniture: ['冷氣', '冰箱', '洗衣機', '衣櫃', '雙人床'],
    landlord: { name: '謝太太', verified: true, rating: 4.7, responseRate: 93 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(88, 85, 80, 78, 76),
    commute: { mrt: '新莊站', distance: 400, walkTime: 6 },
    reviews: [makeReview(1, '匿名租客 V', 5, '2026-04-25', '全套家電，拿起行李就能住，超讚！', 20)],
    aiMatch: 87, matchReasons: ['全套設備', '副都心商圈', '電梯大樓']
  },
  {
    id: 213, title: '土城海山套房', address: '新北市土城區學府路', district: '土城區',
    price: 11000, size: 13, rooms: 1, bathrooms: 1, floor: '3/6', type: '套房',
    lat: 24.9765, lng: 121.4422,
    images: ['https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?w=800&h=600&fit=crop'],
    features: ['含洗衣機', '簡易廚房', '租補合格'], furniture: ['洗衣機', '熱水器'],
    landlord: { name: '林先生', verified: false, rating: 4.3, responseRate: 80 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(85, 78, 72, 75, 82),
    commute: { mrt: '海山站', distance: 520, walkTime: 7 },
    reviews: [makeReview(1, '匿名租客 W', 4, '2026-03-20', '有簡易廚房可以自己煮，洗衣機也有。', 6)],
    aiMatch: 69, matchReasons: ['可自炊', '含洗衣機', '超值租金']
  },
  {
    id: 214, title: '蘆洲徐匯套房', address: '新北市蘆洲區中正路', district: '蘆洲區',
    price: 11500, size: 14, rooms: 1, bathrooms: 1, floor: '4/7', type: '套房',
    lat: 25.0862, lng: 121.4722,
    images: ['https://images.unsplash.com/photo-1502672023488-70e25813eb80?w=800&h=600&fit=crop'],
    features: ['含冷氣雙人床', '近徐匯中學', '租補合格'], furniture: ['冷氣', '雙人床'],
    landlord: { name: '孫先生', verified: true, rating: 4.4, responseRate: 84 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(82, 80, 76, 72, 78),
    commute: { mrt: '蘆洲站', distance: 450, walkTime: 6 },
    reviews: [makeReview(1, '匿名租客 X', 4, '2026-04-05', '冷氣雙人床都有，蘆洲租金便宜很多！', 8)],
    aiMatch: 71, matchReasons: ['含冷氣', '含雙人床', '蘆洲低租金']
  },
  {
    id: 215, title: '新店碧潭套房', address: '新北市新店區北新路三段', district: '新店區',
    price: 13500, size: 15, rooms: 1, bathrooms: 1, floor: '5/8', type: '套房',
    lat: 24.9645, lng: 121.5418,
    images: ['https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop'],
    features: ['獨立洗烘機', '含陽台', '碧潭步行圈'], furniture: ['洗衣機', '衣櫃'],
    landlord: { name: '方小姐', verified: true, rating: 4.6, responseRate: 90 },
    subsidy: false, subsidyAmount: 0,
    lifeScores: makeScores(85, 80, 82, 80, 76),
    commute: { mrt: '新店站', distance: 380, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 Y', 5, '2026-05-08', '碧潭景色超美，有陽台和洗烘機！', 12)],
    aiMatch: 78, matchReasons: ['陽台景觀', '洗烘機', '碧潭生活圈']
  },
  {
    id: 216, title: '汐止科學園區套房', address: '新北市汐止區新台五路', district: '汐止區',
    price: 12000, size: 14, rooms: 1, bathrooms: 1, floor: '6/10', type: '套房',
    lat: 25.0682, lng: 121.6528,
    images: ['https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop'],
    features: ['全套家具', '近科學園區', '租補合格'], furniture: ['冷氣', '冰箱', '衣櫃', '書桌'],
    landlord: { name: '蔣先生', verified: true, rating: 4.5, responseRate: 87 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(80, 78, 75, 78, 80),
    commute: { mrt: '汐止大同站', distance: 500, walkTime: 7 },
    reviews: [makeReview(1, '匿名租客 Z', 4, '2026-05-12', '全套家具，科技業上班族超合適！', 9)],
    aiMatch: 75, matchReasons: ['全套家具', '科學園區', '安靜社區']
  },
  {
    id: 217, title: '樹林車站套房', address: '新北市樹林區中山路', district: '樹林區',
    price: 10000, size: 12, rooms: 1, bathrooms: 1, floor: '2/5', type: '套房',
    lat: 24.9882, lng: 121.4178,
    images: ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=600&fit=crop'],
    features: ['含冷氣冰箱', '近樹林站', '租補合格'], furniture: ['冷氣', '冰箱', '雙人床'],
    landlord: { name: '江先生', verified: false, rating: 4.2, responseRate: 78 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(88, 75, 70, 72, 70),
    commute: { mrt: '樹林站', distance: 350, walkTime: 5 },
    reviews: [makeReview(1, '匿名租客 AA', 4, '2026-03-30', '樹林最便宜，冷氣冰箱都有！', 5)],
    aiMatch: 66, matchReasons: ['近火車站', '含冷氣冰箱', '超低租金']
  },
  {
    id: 218, title: '淡水捷運套房', address: '新北市淡水區中正路', district: '淡水區',
    price: 9500, size: 13, rooms: 1, bathrooms: 1, floor: '3/5', type: '套房',
    lat: 25.1693, lng: 121.4440,
    images: ['https://images.unsplash.com/photo-1536376072261-38c75010e6c9?w=800&h=600&fit=crop'],
    features: ['淡水老街旁', '租補合格', '近捷運'], furniture: ['衣櫃', '書桌', '冷氣'],
    landlord: { name: '翁小姐', verified: true, rating: 4.4, responseRate: 83 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(88, 82, 86, 75, 72),
    commute: { mrt: '淡水站', distance: 280, walkTime: 4 },
    reviews: [makeReview(1, '匿名租客 BB', 4, '2026-04-18', '淡水風景美，捷運超近，衣櫃書桌都有。', 7)],
    aiMatch: 72, matchReasons: ['近淡水站', '含衣櫃書桌', '觀光生活圈']
  },
  {
    id: 219, title: '林口三井套房', address: '新北市林口區文化二路', district: '林口區',
    price: 13000, size: 16, rooms: 1, bathrooms: 1, floor: '7/12', type: '套房',
    lat: 25.0778, lng: 121.3848,
    images: ['https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&h=600&fit=crop'],
    features: ['近三井OUTLET', '含雙人床衣櫃', '電梯大樓', '租補合格'], furniture: ['雙人床', '衣櫃', '洗衣機'],
    landlord: { name: '趙先生', verified: true, rating: 4.6, responseRate: 89 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(80, 90, 82, 78, 72),
    commute: { mrt: '林口站', distance: 600, walkTime: 8 },
    reviews: [makeReview(1, '匿名租客 CC', 5, '2026-05-22', '三井購物超方便，雙人床衣櫃獨立洗衣機！', 11)],
    aiMatch: 79, matchReasons: ['近三井購物', '含洗衣機', '電梯社區']
  },
  {
    id: 220, title: '五股電梯套房', address: '新北市五股區成泰路', district: '五股區',
    price: 11000, size: 13, rooms: 1, bathrooms: 1, floor: '5/9', type: '套房',
    lat: 25.0732, lng: 121.4418,
    images: ['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&h=600&fit=crop'],
    features: ['含熱水器冷氣', '電梯', '租補合格'], furniture: ['熱水器', '冷氣'],
    landlord: { name: '盧先生', verified: true, rating: 4.3, responseRate: 82 },
    subsidy: true, subsidyAmount: 3000,
    lifeScores: makeScores(78, 75, 72, 75, 70),
    commute: { mrt: '五股工業區站', distance: 700, walkTime: 10 },
    reviews: [makeReview(1, '匿名租客 DD', 4, '2026-04-10', '五股工業區工作方便，熱水器冷氣都有。', 4)],
    aiMatch: 67, matchReasons: ['含熱水器冷氣', '電梯建築', '工業區近便']
  },
];

// MRT Stations — NTUT-centric grid (5 lines)
export const mrtStations = [
  // Blue Line 板南線
  { id: 1,  name: '台北車站',   lat: 25.0478, lng: 121.5170, line: '板南線' },
  { id: 2,  name: '善導寺',     lat: 25.0449, lng: 121.5276, line: '板南線' },
  { id: 3,  name: '忠孝新生',   lat: 25.0424, lng: 121.5319, line: '板南線' },
  { id: 4,  name: '忠孝復興',   lat: 25.0414, lng: 121.5439, line: '板南線' },
  { id: 5,  name: '忠孝敦化',   lat: 25.0412, lng: 121.5510, line: '板南線' },
  // Green Line 松山新店線
  { id: 6,  name: '中山',       lat: 25.0527, lng: 121.5202, line: '松山新店線' },
  { id: 7,  name: '松江南京',   lat: 25.0516, lng: 121.5301, line: '松山新店線' },
  { id: 8,  name: '南京復興',   lat: 25.0514, lng: 121.5437, line: '松山新店線' },
  // Red Line 淡水信義線
  { id: 9,  name: '中正紀念堂', lat: 25.0318, lng: 121.5198, line: '淡水信義線' },
  { id: 10, name: '東門',       lat: 25.0335, lng: 121.5298, line: '淡水信義線' },
  { id: 11, name: '大安森林公園',lat: 25.0330, lng: 121.5360, line: '淡水信義線' },
  { id: 12, name: '大安',       lat: 25.0333, lng: 121.5434, line: '淡水信義線' },
  // Yellow Line 中和新蘆線
  { id: 13, name: '忠孝新生(Y)', lat: 25.0436, lng: 121.5296, line: '中和新蘆線' },
  { id: 14, name: '東門(Y)',     lat: 25.0335, lng: 121.5298, line: '中和新蘆線' },
  // Brown Line 文湖線
  { id: 15, name: '南京復興(B)', lat: 25.0514, lng: 121.5437, line: '文湖線' },
  { id: 16, name: '忠孝復興(B)', lat: 25.0414, lng: 121.5439, line: '文湖線' },
  { id: 17, name: '大安(B)',     lat: 25.0333, lng: 121.5434, line: '文湖線' },
];

// 41 Districts — Taipei + New Taipei
export const allDistricts = {
  taipei: ['中正區','大同區','中山區','松山區','大安區','萬華區','信義區','士林區','北投區','內湖區','南港區','文山區'],
  newTaipei: ['板橋區','三重區','中和區','永和區','新莊區','新店區','土城區','蘆洲區','樹林區','汐止區','三峽區','淡水區','鶯歌區','五股區','泰山區','林口區','深坑區','石碇區','坪林區','三芝區','石門區','八里區','平溪區','雙溪區','貢寮區','金山區','萬里區','烏來區','瑞芳區'],
};

// Tenant Profiles for Landlord Dashboard
export const tenantProfiles = [
  {
    id: 1, name: '李*安', age: 28, occupation: '軟體工程師', company: '某科技公司',
    income: '月薪 65,000', creditScore: 850, verified: true, profileComplete: 95,
    tags: ['穩定工作', '無不良紀錄', '準時繳款', '愛整潔'],
    rentHistory: '3年租屋經驗，無違約紀錄', applicationDate: '2026-05-28', status: '審核中',
    documents: { id: true, income: true, employment: true, credit: true },
    aiScore: 92, propertyInterested: '大安精品套房'
  },
  {
    id: 2, name: '王*婷', age: 25, occupation: '平面設計師', company: '自由接案',
    income: '月收入約 45,000', creditScore: 780, verified: true, profileComplete: 88,
    tags: ['創意工作者', '準時繳款', '安靜', '養貓'],
    rentHistory: '2年租屋經驗', applicationDate: '2026-05-25', status: '已簽約',
    documents: { id: true, income: true, employment: false, credit: true },
    aiScore: 85, propertyInterested: '中山現代套房'
  },
  {
    id: 3, name: '張*豪', age: 32, occupation: '業務主管', company: '某金融機構',
    income: '月薪 85,000', creditScore: 920, verified: true, profileComplete: 100,
    tags: ['高收入', '穩定工作', '無不良紀錄', '長期租約'],
    rentHistory: '5年租屋經驗，皆準時繳款', applicationDate: '2026-05-20', status: '已入住',
    documents: { id: true, income: true, employment: true, credit: true },
    aiScore: 98, propertyInterested: '信義奢華套房'
  }
];

export const contracts = [
  {
    id: 1, tenantName: '張*豪', propertyAddress: '台北市信義區松仁路',
    startDate: '2026-06-01', endDate: '2027-05-31', monthlyRent: 22000, deposit: 44000,
    status: '執行中', progress: 100, signedDate: '2026-05-22', nextPaymentDate: '2026-07-01'
  },
  {
    id: 2, tenantName: '王*婷', propertyAddress: '台北市中山區民生東路二段',
    startDate: '2026-06-15', endDate: '2027-06-14', monthlyRent: 16500, deposit: 33000,
    status: '待簽約', progress: 75, signedDate: null, nextPaymentDate: null
  }
];

export const rentPayments = [
  {
    id: 1, tenantName: '張*豪', propertyAddress: '台北市信義區松仁路',
    amount: 22000, dueDate: '2026-07-01', paidDate: null, status: '待繳納', method: null
  },
  {
    id: 2, tenantName: '王*婷', propertyAddress: '台北市中山區民生東路二段',
    amount: 16500, dueDate: '2026-06-15', paidDate: null, status: '待繳納', method: null
  }
];

export const maintenanceRequests = [
  {
    id: 1, tenantName: '張*豪', propertyAddress: '台北市信義區松仁路',
    issue: '浴室水龍頭滴水', category: '水電', urgency: '中', reportDate: '2026-05-28',
    status: '處理中', estimatedCost: 800, assignedTo: '王師傅水電行',
    scheduledDate: '2026-06-02',
    description: '浴室洗手台水龍頭關閉後仍有滴水現象，約每分鐘 3-4 滴。'
  },
  {
    id: 2, tenantName: '王*婷', propertyAddress: '台北市中山區民生東路二段',
    issue: '冷氣不冷', category: '家電', urgency: '高', reportDate: '2026-05-29',
    status: '已派工', estimatedCost: 1500, assignedTo: '永誠冷氣維修',
    scheduledDate: '2026-06-01',
    description: '客廳冷氣開啟後只送風不冷，懷疑冷媒不足或壓縮機問題。'
  }
];

export const taxBenefits = {
  incomeDeduction: 0.6, landTaxReduction: 0.78, houseTaxReduction: 0.67,
  description: '公益出租人可享有：1) 租金所得60%免稅 2) 地價稅按自用住宅稅率 3) 房屋稅按自用住宅稅率'
};

export const landlordStories = [
  {
    id: 1, title: '成為公益出租人，我的租金收入反而增加了', landlord: '王先生', district: '大安區',
    excerpt: '透過租補制度和稅務優惠，實際收入比原本還多...',
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600&h=400&fit=crop'
  },
  {
    id: 2, title: '數位管理讓我輕鬆管理三間出租房', landlord: '林小姐', district: '信義區',
    excerpt: '電子簽約、線上繳款、修繕追蹤，一個平台全搞定...',
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop'
  }
];

// Tenant's own contract info (for TenantDashboard)
export const myContract = {
  property: '大安精品套房', address: '台北市大安區復興南路二段',
  landlord: '張先生', landlordPhone: '0912-345-678',
  startDate: '2026-06-15', endDate: '2027-06-14', monthlyRent: 15000, deposit: 30000,
};

export const myRentHistory = [
  { month: '05月', amount: 15000, status: '已繳', date: '2026-05-03' },
  { month: '04月', amount: 15000, status: '已繳', date: '2026-04-03' },
  { month: '06月', amount: 15000, status: '待繳納', dueDate: '2026-07-05', date: null },
];
