指令一：品牌更名、快速註冊與密碼強度防錯

複製以下內容丟給 Figma AI：
"Redesign the platform branding, renaming the website to '棲居 (Habitat)'. Change the registration entry flow: When a user clicks the 'Register (註冊)' button on the homepage, it must jump directly to the Sign-up page (skip the login page entirely). On the Sign-up page, implement a strict password field validation UI. Under the password field, display a persistent helper text: '密碼須包含特殊符號、大小寫英文與數字組合，且長度達8位以上'. Design a state where validation fails, popping up a high-visibility Error Toast message with the exact text: '密碼須符合特殊符號加大小寫英數組合8位以上' and disabling the submit button."

📌 指令二：【新增家具】註冊頁面租客偏好、自身優勢

複製以下內容丟給 Figma AI：
"On the Tenant Sign-up page, add three detailed interactive input sections.

A dropdown menu titled 'Housing Preference (我想找什麼樣的房子)' with these exact options: ['獨立套房 (Studio Suite)', '分租套房 (Private Suite)', '家庭式整層住家 (Entire Apartment)', '優質雅房 (Shared Room)'].

A checklist section titled 'Required Furniture (期望家具配置)' containing these exact options: ['衣櫃 (Wardrobe)', '洗衣機 (Washing Machine)', '雙人床 (Double Bed)', '冰箱 (Refrigerator)', '冷氣 (Air Conditioner)', '熱水器 (Water Heater)'].

A multi-select tag chip section titled 'Personal Strengths (自身優勢)' containing these exact choice chips: ['愛乾淨 (Clean & Tidy)', '作息正常 (Regular Routine)', '不菸不酒 (No Smoking/Drinking)', '無寵物 (No Pets)', '準時交租 (Pays Rent on Time)']."

📌 指令三：房客後台首頁、模式切換與三大居住功能（合約、租金、修繕）

複製以下內容丟給 Figma AI：
"Create a 'Tenant Dashboard (房客後台)' view to serve as the default home screen after tenant login, replacing the search map. At the very top, design a prominent segmented control or toggle switch with two clear buttons: 'Search Mode (找房模式)' and 'Tenant Mode (房客模式)'. When 'Tenant Mode' is active, render three major card-based feature sections:

'View Contract (查看合約)' card: showing current rent details ['租期: 2026/06/15 - 2027/06/14', '月租金: $15,000', '房東聯絡電話: 0912-345-678'].

'Rent Payment (租金繳交)' card: showing payment status ['本月狀態: 待繳納 $15,000', '截止日期: 2026/07/05'], an 'Online Pay Now (立即繳費)' action button, and a brief history list ['05月已繳 $15,000', '04月已繳 $15,000'].

'Maintenance Requests (修繕申請)' card: containing an input field for 'Describe Issue (問題描述)', an 'Upload Photo (上傳損壞照片)' image placeholder box, a 'Submit Request (送出申請)' button, and a status tracking badge reading '維修處理中 (In Progress)'."

📌 指令四：【新增附帶家具】房東多物件管理後台

複製以下內容丟給 Figma AI：
"Design a Landlord Dashboard optimized for multi-property owners. The main screen should display a list layout showing multiple owned property cards. Add a prominent 'Upload New Property (上傳新物件)' floating button. This button opens a comprehensive property listing form containing:

A section for 'Property Deed Verification (房產驗證)' with a file upload drag-and-drop zone labeled '請上傳房屋所有權狀或謄本照片' and a status badge showing '審核中 (Under Review)'.

An 'Included Furniture & Appliances (附帶家具與家電)' multi-select checkbox area containing: ['衣櫃 (Wardrobe)', '洗衣機 (Washing Machine)', '冰箱 (Refrigerator)', '冷氣 (Air Conditioner)', '雙人床 (Double Bed)', '熱水器 (Water Heater)', '沙發 (Sofa)'].

A 'Property Advantages (房屋優勢)' multi-select checkbox group containing: ['專人代收垃圾 (Garbage Collection)', '近捷運站5分鐘 (Near MRT)', '有獨立陽台 (Private Balcony)', '可養寵物 (Pet Friendly)']."

📌 指令五：全雙北41個行政區、家具篩選與北科大捷運核心地圖

複製以下內容丟給 Figma AI：
"Design a property search screen with advanced filters and a map view. Inside the search bar filter panel, add a 'Furniture Filters (家具篩選)' filter containing checkboxes for: ['有洗衣機', '有衣櫃', '有冷氣', '有冰箱']. Populated the 'Area (區域)' dropdown filter with all these exact districts: [Taipei: 中正區, 大同區, 中山區, 松山區, 大安區, 萬華區, 信義區, 士林區, 北投區, 內湖區, 南港區, 文山區. New Taipei: 板橋區, 三重區, 中和區, 永和區, 新莊區, 新店區, 土城區, 蘆洲區, 樹林區, 汐止區, 三峽區, 淡水區, 鶯歌區, 五股區, 泰山區, 林口區, 深坑區, 石碇區, 坪林區, 三芝區, 石門區, 八里區, 平溪區, 雙溪區, 貢寮區, 金山區, 萬里區, 烏來區, 瑞芳區]. Below the filter, generate a map interface centered around National Taipei University of Technology (北科大), clearly showing a grid defined by these MRT lines and stations: Blue Line (台北車站, 善導寺, 忠孝新生, 忠孝復興, 忠孝敦化), Green Line (中山, 松江南京, 南京復興), Red Line (中正紀念堂, 東門, 大安森林公園, 大安), Yellow Line (松江南京, 忠孝新生, 東門), and Brown Line (南京復興, 忠孝復興, 大安)."

📌 指令六：30件假房源（包含家具備註）與點頭像更改個人資訊

複製以下內容丟給 Figma AI：
"Generate a property feed list with exactly 30 mock listing cards, explicitly split into 10 Shared Rooms (雅房) and 20 Suites (套房).
List the 10 Shared Rooms with furniture descriptions as: '1. 大安溫馨雅房 $8,500 (含衣櫃/書桌)', '2. 中山捷運雅房 $7,800 (含冷氣/衣櫃)', '3. 中正北科雅房 $8,000 (附雙人床/書桌)', '4. 松山採光雅房 $9,000 (全套家具)', '5. 萬華小資雅房 $7,000 (含衣櫃)', '6. 板橋便捷雅房 $7,500 (附洗衣機)', '7. 三重公寓雅房 $6,800 (含冷氣)', '8. 中和溫暖雅房 $7,200 (附單人床/衣櫃)', '9. 永和頂溪雅房 $7,400 (全套家具)', '10. 新莊輔大雅房 $6,900 (含書桌)'.
List the 20 Suites with furniture descriptions as: '1. 信義奢華套房 $22,000 (獨立洗烘衣機/衣櫃/雙人床)', '2. 大安精品套房 $18,000 (附流理台/冰箱/冷氣)', '3. 中山現代套房 $16,500 (含陽台/獨立洗衣機/冷氣)', '4. 松山景觀套房 $17,500 (全套家具/大衣櫃)', '5. 中正新生套房 $16,000 (含冷氣/獨立衛浴)', '6. 內湖科技套房 $15,500 (附冰箱/洗衣機/書桌)', '7. 南港軟體套房 $19,000 (附全新衣櫃/雙人床)', '8. 板橋新板套房 $14,500 (全套實木家具)', '9. 三重河景套房 $13,000 (附冷氣/獨立洗衣機)', '10. 中和景安套房 $12,500 (含熱水器/雙人床)', '11. 永和頂溪套房 $13,500 (附衣櫃/冰箱/冷氣)', '12. 新莊副都心套房 $14,000 (全套家電家具)', '13. 土城海山套房 $11,000 (附洗衣機/簡易廚房)', '14. 蘆洲徐匯套房 $11,500 (含冷氣/雙人床)', '15. 新店碧潭套房 $13,500 (附陽台/獨立洗烘機)', '16. 汐止科學園區套房 $12,000 (含全套家具)', '17. 樹林車站套房 $10,000 (附單人床/冷氣/冰箱)', '18. 淡水捷運套房 $9,500 (附衣櫃/書桌/冷氣)', '19. 林口三井套房 $13,000 (附雙人床/衣櫃/獨立洗衣機)', '20. 五股電梯套房 $11,000 (含熱水器/冷氣)'.
Furthermore, ensure that clicking the User Avatar in the header after login opens a 'Profile Edit Screen (修改個人資訊)'. This page must include input fields for: '更新大頭貼 (Change Avatar)', '姓名 (Full Name)', '聯絡電話 (Phone)', '電子信箱 (Email)', '密碼變更 (Change Password)', and a section to re-edit '個人優勢標籤 (Edit Personal Strengths)' and '期望家具配置列表 (Edit Furniture Preferences)'."