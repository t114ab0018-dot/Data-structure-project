import { useState } from 'react';
import { motion } from 'motion/react';
import { User, Phone, Mail, Lock, Tag, Sofa, CheckCircle2, Camera, ArrowLeft, Eye, EyeOff, Save } from 'lucide-react';

interface ProfileEditPageProps {
  user: { name: string; email: string; role: string | null; verified: boolean };
  onBack: () => void;
  onSave: (updated: { name: string; email: string; phone: string }) => void;
}

const STRENGTHS = ['愛乾淨', '作息正常', '不菸不酒', '無寵物', '準時交租'];
const FURNITURE_PREFS = ['衣櫃', '洗衣機', '雙人床', '冰箱', '冷氣', '熱水器'];
const AVATAR_COLORS = [
  'linear-gradient(135deg, #9CAF88, #98A8B8)',
  'linear-gradient(135deg, #AFA3B0, #C4B5C7)',
  'linear-gradient(135deg, #98A8B8, #9CAF88)',
  'linear-gradient(135deg, #C4B5C7, #9CAF88)',
  'linear-gradient(135deg, #B8C5AA, #AFA3B0)',
];

export default function ProfileEditPage({ user, onBack, onSave }: ProfileEditPageProps) {
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [phone, setPhone] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [oldPw, setOldPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(0);
  const [strengths, setStrengths] = useState<string[]>(['愛乾淨', '準時交租']);
  const [furniturePrefs, setFurniturePrefs] = useState<string[]>(['冷氣', '洗衣機']);
  const [saved, setSaved] = useState(false);

  const toggleChip = (arr: string[], setArr: (v: string[]) => void, val: string) => {
    setArr(arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val]);
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => {
      onSave({ name, email, phone });
    }, 1000);
  };

  return (
    <div className="min-h-full bg-[var(--morandi-warm-white)] px-4 py-6 sm:px-6">
      <div className="max-w-lg mx-auto">

        {/* Header */}
        <div className="flex items-center gap-3 mb-7">
          <button
            onClick={onBack}
            className="p-2.5 rounded-xl border border-[var(--morandi-stone)]/40 hover:bg-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-60" />
          </button>
          <div>
            <h2 className="text-[var(--morandi-charcoal)] font-semibold">修改個人資訊</h2>
            <p className="text-xs text-[var(--morandi-charcoal)] opacity-50">更新您的帳號與偏好設定</p>
          </div>
        </div>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">

          {/* Avatar Section */}
          <div className="bg-white rounded-2xl p-5 border border-[var(--morandi-stone)]/30 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <Camera className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-50" />
              <h3 className="text-sm font-semibold text-[var(--morandi-charcoal)]">更新大頭貼</h3>
            </div>
            <div className="flex items-center gap-4">
              {/* Current avatar preview */}
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center text-white text-2xl font-semibold shadow-md shrink-0"
                style={{ background: AVATAR_COLORS[selectedAvatar] }}
              >
                {name?.[0] ?? '?'}
              </div>
              {/* Color picker */}
              <div>
                <p className="text-xs text-[var(--morandi-charcoal)] opacity-45 mb-2">選擇顏色</p>
                <div className="flex gap-2">
                  {AVATAR_COLORS.map((g, i) => (
                    <button
                      key={i}
                      onClick={() => setSelectedAvatar(i)}
                      className="w-8 h-8 rounded-full transition-all"
                      style={{
                        background: g,
                        outline: selectedAvatar === i ? '2px solid var(--morandi-charcoal)' : '2px solid transparent',
                        outlineOffset: '2px',
                      }}
                    />
                  ))}
                </div>
              </div>
              {/* Upload button */}
              <button className="ml-auto px-3 py-2 rounded-lg border border-[var(--morandi-stone)]/50 text-xs text-[var(--morandi-charcoal)] opacity-60 hover:opacity-100 transition-opacity flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5" /> 上傳圖片
              </button>
            </div>
          </div>

          {/* Basic Info */}
          <div className="bg-white rounded-2xl p-5 border border-[var(--morandi-stone)]/30 shadow-sm space-y-3">
            <div className="flex items-center gap-2 mb-3">
              <User className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-50" />
              <h3 className="text-sm font-semibold text-[var(--morandi-charcoal)]">基本資料</h3>
            </div>
            <ProfileInput icon={User} label="姓名" value={name} onChange={setName} placeholder="您的真實姓名" />
            <ProfileInput icon={Phone} label="聯絡電話" value={phone} onChange={setPhone} placeholder="09xx-xxx-xxx" type="tel" />
            <ProfileInput icon={Mail} label="電子信箱" value={email} onChange={setEmail} placeholder="your@email.com" type="email" />
          </div>

          {/* Password Change */}
          <div className="bg-white rounded-2xl p-5 border border-[var(--morandi-stone)]/30 shadow-sm space-y-3">
            <div className="flex items-center gap-2 mb-3">
              <Lock className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-50" />
              <h3 className="text-sm font-semibold text-[var(--morandi-charcoal)]">密碼變更</h3>
            </div>
            <div className="relative">
              <ProfileInput icon={Lock} label="目前密碼" value={oldPw} onChange={setOldPw} placeholder="輸入目前密碼" type={showPw ? 'text' : 'password'} />
              <button
                className="absolute right-4 top-1/2 translate-y-1 text-[var(--morandi-charcoal)] opacity-40 hover:opacity-70 transition-opacity"
                onClick={() => setShowPw(p => !p)}
              >
                {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <ProfileInput icon={Lock} label="新密碼" value={newPw} onChange={setNewPw} placeholder="新密碼（8位以上）" type="password" />
            <p className="text-xs text-[var(--morandi-charcoal)] opacity-40 pl-1">
              密碼須包含特殊符號、大小寫英文與數字組合，且長度達8位以上
            </p>
          </div>

          {/* Personal Strengths */}
          <div className="bg-white rounded-2xl p-5 border border-[var(--morandi-stone)]/30 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              <Tag className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-50" />
              <h3 className="text-sm font-semibold text-[var(--morandi-charcoal)]">個人優勢標籤</h3>
              <span className="ml-auto text-xs text-[var(--morandi-charcoal)] opacity-40">{strengths.length} 已選</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {STRENGTHS.map(s => (
                <Chip
                  key={s} label={s} active={strengths.includes(s)}
                  onClick={() => toggleChip(strengths, setStrengths, s)}
                  color="var(--morandi-sage)"
                />
              ))}
            </div>
          </div>

          {/* Furniture Preferences */}
          <div className="bg-white rounded-2xl p-5 border border-[var(--morandi-stone)]/30 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              <Sofa className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-50" />
              <h3 className="text-sm font-semibold text-[var(--morandi-charcoal)]">期望家具配置</h3>
              <span className="ml-auto text-xs text-[var(--morandi-charcoal)] opacity-40">{furniturePrefs.length} 已選</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {FURNITURE_PREFS.map(f => (
                <Chip
                  key={f} label={f} active={furniturePrefs.includes(f)}
                  onClick={() => toggleChip(furniturePrefs, setFurniturePrefs, f)}
                  color="var(--morandi-slate)"
                />
              ))}
            </div>
          </div>

          {/* Save Button */}
          <button
            onClick={handleSave}
            className="w-full py-4 rounded-2xl text-white text-sm font-medium flex items-center justify-center gap-2 transition-all hover:shadow-lg active:scale-[0.98]"
            style={{ background: 'linear-gradient(135deg, var(--morandi-sage), var(--morandi-slate))' }}
          >
            {saved ? (
              <><CheckCircle2 className="w-4 h-4" /> 已儲存！</>
            ) : (
              <><Save className="w-4 h-4" /> 儲存變更</>
            )}
          </button>

          <div className="h-8" />
        </motion.div>
      </div>
    </div>
  );
}

function ProfileInput({
  icon: Icon, label, value, onChange, placeholder, type = 'text'
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string; value: string;
  onChange: (v: string) => void;
  placeholder: string; type?: string;
}) {
  return (
    <div className="relative">
      <label className="text-xs text-[var(--morandi-charcoal)] opacity-50 mb-1 block">{label}</label>
      <div className="relative">
        <Icon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--morandi-charcoal)] opacity-30" />
        <input
          type={type}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full pl-10 pr-4 py-3 rounded-xl border border-[var(--morandi-stone)]/50 bg-[var(--morandi-warm-white)] text-sm text-[var(--morandi-charcoal)] placeholder-[var(--morandi-charcoal)]/30 focus:outline-none focus:ring-2 focus:ring-[var(--morandi-sage)]/30 transition-all"
        />
      </div>
    </div>
  );
}

function Chip({ label, active, onClick, color }: { label: string; active: boolean; onClick: () => void; color: string }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium transition-all duration-200 border"
      style={active
        ? { background: `color-mix(in srgb, ${color} 15%, transparent)`, borderColor: color, color }
        : { background: 'transparent', borderColor: 'rgba(212,205,195,0.6)', color: 'rgba(74,74,74,0.55)' }}
    >
      {active && <CheckCircle2 className="w-3 h-3" />}
      {label}
    </button>
  );
}
