import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText, DollarSign, Wrench, CheckCircle2, Clock, Phone, Upload,
  AlertCircle, ChevronRight, Send, Home, Search, CreditCard, Calendar
} from 'lucide-react';
import { myContract, myRentHistory } from '../../mockData';

interface TenantDashboardProps {
  onSwitchToSearch: () => void;
}

export default function TenantDashboard({ onSwitchToSearch }: TenantDashboardProps) {
  const [mode, setMode] = useState<'search' | 'tenant'>('tenant');
  const [issueDesc, setIssueDesc] = useState('');
  const [photoUploaded, setPhotoUploaded] = useState(false);
  const [requestSent, setRequestSent] = useState(false);
  const [payNowClicked, setPayNowClicked] = useState(false);

  const pendingRent = myRentHistory.find(r => r.status === '待繳納');
  const paidHistory = myRentHistory.filter(r => r.status === '已繳');

  if (mode === 'search') {
    onSwitchToSearch();
    return null;
  }

  return (
    <div className="min-h-full bg-[var(--morandi-warm-white)] px-4 py-6 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">

        {/* Mode Toggle */}
        <div className="flex items-center justify-center mb-8">
          <div className="inline-flex items-center bg-white rounded-2xl p-1.5 shadow-sm border border-[var(--morandi-stone)]/40">
            <ModeBtn
              active={mode === 'search'}
              onClick={() => setMode('search')}
              icon={Search}
              label="找房模式"
              activeColor="var(--morandi-slate)"
            />
            <ModeBtn
              active={mode === 'tenant'}
              onClick={() => setMode('tenant')}
              icon={Home}
              label="房客模式"
              activeColor="var(--morandi-sage)"
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key="tenant-mode"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            className="space-y-5"
          >
            {/* Greeting */}
            <div className="mb-2">
              <h2 className="text-[var(--morandi-charcoal)] text-xl font-semibold">我的租屋管理</h2>
              <p className="text-sm text-[var(--morandi-charcoal)] opacity-55 mt-0.5">管理合約、繳租與修繕申請</p>
            </div>

            {/* ── Card 1: 查看合約 ───────────────────────────────────── */}
            <DashCard
              icon={FileText}
              title="查看合約"
              iconColor="var(--morandi-slate)"
              iconBg="rgba(152,168,184,0.15)"
            >
              <div className="space-y-3">
                <InfoRow label="租期" value={`${myContract.startDate} ～ ${myContract.endDate}`} icon={Calendar} />
                <InfoRow label="月租金" value={`$${myContract.monthlyRent.toLocaleString()}`} icon={DollarSign} />
                <InfoRow label="房東電話" value={myContract.landlordPhone} icon={Phone} />
                <div className="pt-2 border-t border-[var(--morandi-stone)]/30">
                  <p className="text-xs text-[var(--morandi-charcoal)] opacity-50">
                    {myContract.property} ｜ {myContract.address}
                  </p>
                </div>
                <button className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl border border-[var(--morandi-slate)]/40 text-sm text-[var(--morandi-slate)] hover:bg-[var(--morandi-slate)]/5 transition-colors">
                  <FileText className="w-4 h-4" />
                  查看完整電子合約
                  <ChevronRight className="w-3.5 h-3.5 ml-auto" />
                </button>
              </div>
            </DashCard>

            {/* ── Card 2: 租金繳交 ───────────────────────────────────── */}
            <DashCard
              icon={DollarSign}
              title="租金繳交"
              iconColor="var(--morandi-sage)"
              iconBg="rgba(156,175,136,0.15)"
              badge={pendingRent ? { label: '待繳', color: '#C48B88' } : undefined}
            >
              {pendingRent && (
                <div className="rounded-xl bg-[rgba(196,139,136,0.08)] border border-[rgba(196,139,136,0.25)] p-4 mb-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="text-sm font-medium text-[var(--morandi-charcoal)]">本月狀態：待繳納</p>
                      <p className="text-2xl font-semibold text-[var(--morandi-charcoal)] mt-1">
                        ${pendingRent.amount.toLocaleString()}
                      </p>
                    </div>
                    <AlertCircle className="w-5 h-5 text-[#C48B88] mt-1" />
                  </div>
                  <p className="text-xs text-[var(--morandi-charcoal)] opacity-55">
                    截止日期：{pendingRent.dueDate}
                  </p>
                </div>
              )}

              <button
                onClick={() => setPayNowClicked(true)}
                className="w-full py-3.5 rounded-xl text-white text-sm font-medium flex items-center justify-center gap-2 transition-all hover:shadow-md active:scale-[0.98]"
                style={{ background: payNowClicked ? 'var(--morandi-sage)' : 'linear-gradient(135deg, var(--morandi-sage), var(--morandi-slate))' }}
              >
                {payNowClicked ? (
                  <><CheckCircle2 className="w-4 h-4" /> 已送出繳費請求</>
                ) : (
                  <><CreditCard className="w-4 h-4" /> 立即繳費</>
                )}
              </button>

              <div className="mt-4 space-y-2">
                <p className="text-xs text-[var(--morandi-charcoal)] opacity-45 font-medium">繳款紀錄</p>
                {paidHistory.map(r => (
                  <div key={r.month} className="flex items-center justify-between py-2 border-b border-[var(--morandi-stone)]/20 last:border-0">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[var(--morandi-sage)]" />
                      <span className="text-sm text-[var(--morandi-charcoal)] opacity-70">{r.month}已繳</span>
                    </div>
                    <span className="text-sm text-[var(--morandi-charcoal)] font-medium">${r.amount.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </DashCard>

            {/* ── Card 3: 修繕申請 ───────────────────────────────────── */}
            <DashCard
              icon={Wrench}
              title="修繕申請"
              iconColor="var(--morandi-mauve)"
              iconBg="rgba(175,163,176,0.15)"
            >
              {/* Status badge */}
              <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-lg bg-[rgba(196,195,144,0.12)] border border-[rgba(196,195,144,0.3)] w-fit">
                <Clock className="w-3.5 h-3.5 text-[#A8A870]" />
                <span className="text-xs text-[#A8A870] font-medium">維修處理中</span>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs text-[var(--morandi-charcoal)] opacity-55 font-medium mb-1.5 block">問題描述</label>
                  <textarea
                    value={issueDesc}
                    onChange={e => setIssueDesc(e.target.value)}
                    placeholder="請詳細描述損壞情況，例如：浴室水龍頭漏水，已持續三天..."
                    rows={3}
                    className="w-full px-4 py-3 rounded-xl border border-[var(--morandi-stone)]/50 bg-[var(--morandi-warm-white)] text-sm text-[var(--morandi-charcoal)] placeholder-[var(--morandi-charcoal)]/30 focus:outline-none focus:ring-2 focus:ring-[var(--morandi-mauve)]/30 resize-none"
                  />
                </div>

                <button
                  onClick={() => setPhotoUploaded(p => !p)}
                  className="w-full flex flex-col items-center justify-center gap-2 py-5 rounded-xl border-2 border-dashed transition-all"
                  style={{
                    borderColor: photoUploaded ? 'var(--morandi-mauve)' : 'rgba(212,205,195,0.6)',
                    background: photoUploaded ? 'rgba(175,163,176,0.07)' : 'transparent',
                  }}
                >
                  {photoUploaded
                    ? <CheckCircle2 className="w-6 h-6 text-[var(--morandi-mauve)]" />
                    : <Upload className="w-6 h-6 text-[var(--morandi-charcoal)] opacity-30" />}
                  <span className="text-sm text-[var(--morandi-charcoal)] opacity-55">
                    {photoUploaded ? '照片已上傳' : '上傳損壞照片'}
                  </span>
                </button>

                <button
                  onClick={() => setRequestSent(true)}
                  disabled={!issueDesc.trim()}
                  className="w-full py-3.5 rounded-xl text-white text-sm font-medium flex items-center justify-center gap-2 transition-all hover:shadow-md active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed"
                  style={{ background: 'linear-gradient(135deg, var(--morandi-mauve), var(--morandi-slate))' }}
                >
                  {requestSent
                    ? <><CheckCircle2 className="w-4 h-4" /> 申請已送出</>
                    : <><Send className="w-4 h-4" /> 送出申請</>}
                </button>
              </div>
            </DashCard>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

// ── Sub-components ──────────────────────────────────────────────────────────

function ModeBtn({
  active, onClick, icon: Icon, label, activeColor
}: {
  active: boolean; onClick: () => void;
  icon: React.ComponentType<{ className?: string }>;
  label: string; activeColor: string;
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-200"
      style={active ? { background: activeColor, color: '#fff', boxShadow: '0 2px 8px rgba(0,0,0,0.15)' }
                    : { color: 'rgba(74,74,74,0.55)' }}
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  );
}

function DashCard({
  icon: Icon, title, iconColor, iconBg, badge, children
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string; iconColor: string; iconBg: string;
  badge?: { label: string; color: string };
  children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm border border-[var(--morandi-stone)]/30">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: iconBg }}>
          <Icon className="w-5 h-5" style={{ color: iconColor }} />
        </div>
        <h3 className="text-base font-semibold text-[var(--morandi-charcoal)]">{title}</h3>
        {badge && (
          <span className="ml-auto text-xs px-2.5 py-1 rounded-full text-white font-medium" style={{ background: badge.color }}>
            {badge.label}
          </span>
        )}
      </div>
      {children}
    </div>
  );
}

function InfoRow({
  label, value, icon: Icon
}: {
  label: string; value: string;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <div className="flex items-center gap-3">
      <Icon className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-35 shrink-0" />
      <span className="text-xs text-[var(--morandi-charcoal)] opacity-50 w-16 shrink-0">{label}</span>
      <span className="text-sm text-[var(--morandi-charcoal)] font-medium">{value}</span>
    </div>
  );
}
