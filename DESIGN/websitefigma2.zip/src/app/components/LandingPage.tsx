import { BadgeCheck, TrendingUp, Shield, Award, MapPin, Home, ArrowRight, Star, CheckCircle2 } from 'lucide-react';
import { properties, landlordStories } from '../../mockData';

interface LandingPageProps {
  onNavigate: (view: string) => void;
}

export default function LandingPage({ onNavigate }: LandingPageProps) {
  const topMatches = properties.slice(0, 3).sort((a, b) => b.aiMatch - a.aiMatch);

  return (
    <div className="min-h-full bg-gradient-to-br from-[var(--morandi-warm-white)] via-white to-[var(--morandi-grey-taupe)]">
      {/* Hero Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/60 backdrop-blur-sm rounded-full border border-[var(--morandi-sage)]/30 mb-6 shadow-sm animate-in fade-in slide-in-from-bottom-4 duration-700">
            <Award className="w-4 h-4 text-[var(--morandi-sage)]" />
            <span className="text-sm text-[var(--morandi-charcoal)]">AI 智能媒合 × 信任機制</span>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-[var(--morandi-charcoal)] mb-6 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-100">
            找到理想的家<br />
            <span className="text-[var(--morandi-sage)]">從此變得簡單</span>
          </h1>

          <p className="text-lg text-[var(--morandi-muted-foreground)] mb-10 max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200">
            透過 AI 精準媒合、透明評價系統與租補整合，為租客與房東打造安心、便利的租屋體驗
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-in fade-in slide-in-from-bottom-4 duration-700 delay-300">
            <button
              onClick={() => onNavigate('renter')}
              className="px-8 py-4 bg-[var(--morandi-sage)] text-white rounded-xl hover:bg-[var(--morandi-sage-light)] transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 flex items-center justify-center gap-2 group"
            >
              <span>開始找房</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => onNavigate('landlord')}
              className="px-8 py-4 bg-white text-[var(--morandi-charcoal)] rounded-xl hover:bg-[var(--morandi-muted)] transition-all duration-300 shadow-md hover:shadow-lg flex items-center justify-center gap-2"
            >
              <span>我是房東</span>
            </button>
          </div>
        </div>
      </section>

      {/* Trust Features */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-white/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-[var(--morandi-charcoal)] mb-12">
            為什麼選擇我們
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-[var(--morandi-stone)]">
              <div className="w-14 h-14 bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-sage-light)] rounded-2xl flex items-center justify-center mb-6 shadow-md">
                <BadgeCheck className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[var(--morandi-charcoal)] mb-3">
                實名認證機制
              </h3>
              <p className="text-[var(--morandi-muted-foreground)] leading-relaxed">
                房東與租客雙向認證，藍勾勾標章保證真實身分，打造透明安全的租屋環境
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-[var(--morandi-stone)]">
              <div className="w-14 h-14 bg-gradient-to-br from-[var(--morandi-slate)] to-[var(--morandi-slate-light)] rounded-2xl flex items-center justify-center mb-6 shadow-md">
                <TrendingUp className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[var(--morandi-charcoal)] mb-3">
                AI 智能媒合
              </h3>
              <p className="text-[var(--morandi-muted-foreground)] leading-relaxed">
                根據通勤需求、生活習慣、預算範圍，AI 自動計算契合度，優先推薦最適合的房源
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-[var(--morandi-stone)]">
              <div className="w-14 h-14 bg-gradient-to-br from-[var(--morandi-mauve)] to-[var(--morandi-mauve-light)] rounded-2xl flex items-center justify-center mb-6 shadow-md">
                <Shield className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[var(--morandi-charcoal)] mb-3">
                租補整合服務
              </h3>
              <p className="text-[var(--morandi-muted-foreground)] leading-relaxed">
                一鍵篩選租補合格物件，自動計算補助金額，讓你省錢又省心
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* AI Matched Properties */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-3xl font-bold text-[var(--morandi-charcoal)] mb-2">
                AI 為您推薦
              </h2>
              <p className="text-[var(--morandi-muted-foreground)]">
                根據您的需求，智能媒合最適合的房源
              </p>
            </div>
            <button
              onClick={() => onNavigate('renter')}
              className="hidden sm:flex items-center gap-2 text-[var(--morandi-sage)] hover:text-[var(--morandi-sage-light)] transition-colors group"
            >
              <span>查看全部</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {topMatches.map((property) => (
              <div
                key={property.id}
                className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-[var(--morandi-stone)] cursor-pointer group"
                onClick={() => onNavigate('renter')}
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={property.images[0]}
                    alt={property.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-3 right-3 bg-[var(--morandi-sage)] text-white px-3 py-1 rounded-full text-sm font-medium shadow-lg">
                    {property.aiMatch}% 契合
                  </div>
                  {property.subsidy && (
                    <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium text-[var(--morandi-sage)] shadow-md flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      租補
                    </div>
                  )}
                </div>

                <div className="p-5">
                  <h3 className="font-semibold text-[var(--morandi-charcoal)] mb-2 line-clamp-1">
                    {property.title}
                  </h3>

                  <div className="flex items-center gap-1.5 text-sm text-[var(--morandi-muted-foreground)] mb-3">
                    <MapPin className="w-4 h-4" />
                    <span className="line-clamp-1">{property.address}</span>
                  </div>

                  <div className="flex items-center justify-between mb-3">
                    <div className="text-2xl font-bold text-[var(--morandi-sage)]">
                      ${property.price.toLocaleString()}
                      <span className="text-sm font-normal text-[var(--morandi-muted-foreground)]">/月</span>
                    </div>
                    <div className="text-sm text-[var(--morandi-muted-foreground)]">
                      {property.size} 坪
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {property.landlord.verified && (
                      <div className="flex items-center gap-1 text-xs text-[var(--morandi-sage)]">
                        <BadgeCheck className="w-4 h-4" />
                        <span>已認證</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1 text-xs text-[var(--morandi-muted-foreground)]">
                      <Star className="w-4 h-4 fill-[var(--morandi-mauve)] text-[var(--morandi-mauve)]" />
                      <span>{property.landlord.rating}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={() => onNavigate('renter')}
            className="sm:hidden mt-6 w-full flex items-center justify-center gap-2 text-[var(--morandi-sage)] hover:text-[var(--morandi-sage-light)] transition-colors py-3"
          >
            <span>查看全部房源</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>

      {/* Landlord Stories */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-[var(--morandi-charcoal)] mb-12">
            房東真實分享
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {landlordStories.map((story) => (
              <div
                key={story.id}
                className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-[var(--morandi-stone)] cursor-pointer group"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={story.image}
                    alt={story.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                </div>

                <div className="p-6 -mt-16 relative z-10">
                  <div className="bg-white rounded-xl p-5 shadow-lg">
                    <h3 className="font-semibold text-[var(--morandi-charcoal)] mb-2 line-clamp-2">
                      {story.title}
                    </h3>
                    <p className="text-sm text-[var(--morandi-muted-foreground)] mb-3">
                      {story.excerpt}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="text-sm">
                        <span className="text-[var(--morandi-charcoal)] font-medium">{story.landlord}</span>
                        <span className="text-[var(--morandi-muted-foreground)]"> · {story.district}</span>
                      </div>
                      <ArrowRight className="w-5 h-5 text-[var(--morandi-sage)] group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] rounded-3xl p-10 text-center text-white shadow-2xl">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            準備好找到理想的家了嗎？
          </h2>
          <p className="text-white/90 mb-8 text-lg">
            加入我們，體驗全新的智能租屋服務
          </p>
          <button
            onClick={() => onNavigate('renter')}
            className="px-10 py-4 bg-white text-[var(--morandi-sage)] rounded-xl hover:bg-[var(--morandi-warm-white)] transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 inline-flex items-center gap-2 group"
          >
            <span className="font-semibold">立即開始</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </section>
    </div>
  );
}
