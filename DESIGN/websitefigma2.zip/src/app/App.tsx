import { useState } from 'react';
import { Home, Map, Building2, Menu, X, BadgeCheck, LogOut, User } from 'lucide-react';
import { Toaster } from 'sonner';
import { properties, tenantProfiles, contracts, rentPayments, maintenanceRequests, taxBenefits, mrtStations } from '../mockData';
import LandingPage from './components/LandingPage';
import RenterMapView from './components/RenterMapView';
import LandlordDashboard from './components/LandlordDashboard';
import TenantDashboard from './components/TenantDashboard';
import AuthPage from './components/AuthPage';
import ProfileEditPage from './components/ProfileEditPage';

type View = 'landing' | 'renter' | 'landlord' | 'tenant-dashboard';
type UserRole = 'tenant' | 'landlord' | 'agent' | null;

interface UserData {
  name: string;
  email: string;
  role: UserRole;
  verified: boolean;
}

export default function App() {
  const [currentView, setCurrentView] = useState<View>('landing');
  const [menuOpen, setMenuOpen] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [startOnRegister, setStartOnRegister] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [user, setUser] = useState<UserData | null>(null);

  const handleAuthSuccess = (_role: UserRole, userData: UserData) => {
    setUser(userData);
    setShowAuth(false);
    if (userData.role === 'tenant') setCurrentView('tenant-dashboard');
    else if (userData.role === 'landlord' || userData.role === 'agent') setCurrentView('landlord');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('landing');
    setShowProfile(false);
  };

  const openRegister = () => { setStartOnRegister(true); setShowAuth(true); };
  const openLogin = () => { setStartOnRegister(false); setShowAuth(true); };

  const roleMeta: Record<string, { label: string; color: string }> = {
    tenant: { label: '租客', color: 'var(--morandi-sage)' },
    landlord: { label: '房東', color: 'var(--morandi-slate)' },
    agent: { label: '業者', color: 'var(--morandi-mauve)' },
  };

  if (showAuth) {
    return (
      <>
        <Toaster richColors />
        <AuthPage onAuthSuccess={handleAuthSuccess} startOnRegister={startOnRegister} />
      </>
    );
  }

  if (showProfile && user) {
    return (
      <ProfileEditPage
        user={user}
        onBack={() => setShowProfile(false)}
        onSave={updated => { setUser(u => u ? { ...u, ...updated } : u); setShowProfile(false); }}
      />
    );
  }

  return (
    <div className="size-full bg-[var(--morandi-warm-white)] overflow-hidden flex flex-col">
      {/* MARKER-MAKE-KIT-INVOKED */}
      <Toaster richColors position="top-center" />

      {/* Header Navigation */}
      <header className="bg-white/80 backdrop-blur-md border-b border-[var(--morandi-stone)] sticky top-0 z-50 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentView('landing')}>
              <div className="w-10 h-10 bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] rounded-xl flex items-center justify-center shadow-sm">
                <Home className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-[var(--morandi-charcoal)] leading-none">棲居</h1>
                <p className="text-[10px] text-[var(--morandi-charcoal)] opacity-40 leading-none mt-0.5">Habitat</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-3">
              <NavBtn active={currentView === 'landing'} onClick={() => setCurrentView('landing')} icon={Home} label="首頁" />
              <NavBtn active={currentView === 'renter'} onClick={() => setCurrentView('renter')} icon={Map} label="找房地圖" />
              {user?.role === 'tenant' && (
                <NavBtn active={currentView === 'tenant-dashboard'} onClick={() => setCurrentView('tenant-dashboard')} icon={Home} label="我的租屋" />
              )}
              {(user?.role === 'landlord' || user?.role === 'agent') && (
                <NavBtn active={currentView === 'landlord'} onClick={() => setCurrentView('landlord')} icon={Building2} label="房東後台" />
              )}
              {!user && (
                <NavBtn active={currentView === 'landlord'} onClick={() => setCurrentView('landlord')} icon={Building2} label="房東後台" />
              )}

              {/* Auth area */}
              {user ? (
                <div className="flex items-center gap-2 ml-2">
                  <button
                    onClick={() => setShowProfile(true)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[var(--morandi-warm-white)] border border-[var(--morandi-stone)]/50 hover:border-[var(--morandi-sage)]/50 transition-all cursor-pointer"
                  >
                    <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] flex items-center justify-center">
                      <User className="w-3 h-3 text-white" />
                    </div>
                    <span className="text-sm text-[var(--morandi-charcoal)] font-medium">{user.name}</span>
                    {user.verified && (
                      <BadgeCheck className="w-4 h-4" style={{ color: roleMeta[user.role!]?.color }} />
                    )}
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full text-white font-medium"
                      style={{ background: roleMeta[user.role!]?.color }}>
                      {roleMeta[user.role!]?.label}
                    </span>
                  </button>
                  <button onClick={handleLogout}
                    className="p-2 rounded-lg text-[var(--morandi-charcoal)] opacity-50 hover:opacity-80 hover:bg-[var(--morandi-muted)] transition-all" title="登出">
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2 ml-2">
                  <button onClick={openLogin} className="px-4 py-2 rounded-lg text-sm text-[var(--morandi-charcoal)] hover:bg-[var(--morandi-muted)] transition-colors">
                    登入
                  </button>
                  <button onClick={openRegister} className="px-4 py-2 rounded-lg text-sm text-white bg-[var(--morandi-sage)] hover:opacity-90 transition-all shadow-sm">
                    免費註冊
                  </button>
                </div>
              )}
            </nav>

            {/* Mobile Menu Button */}
            <button className="md:hidden p-2 rounded-lg hover:bg-[var(--morandi-muted)] transition-colors" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {menuOpen && (
            <div className="md:hidden py-4 border-t border-[var(--morandi-stone)] space-y-2 animate-in slide-in-from-top duration-300">
              {[
                { view: 'landing' as View, icon: Home, label: '首頁' },
                { view: 'renter' as View, icon: Map, label: '找房地圖' },
                { view: 'landlord' as View, icon: Building2, label: '房東後台' },
              ].map(item => (
                <button key={item.view} onClick={() => { setCurrentView(item.view); setMenuOpen(false); }}
                  className={`w-full flex items-center gap-2 px-4 py-3 rounded-lg transition-all ${currentView === item.view ? 'bg-[var(--morandi-sage)] text-white' : 'text-[var(--morandi-charcoal)] hover:bg-[var(--morandi-muted)]'}`}>
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              ))}
              <div className="pt-2 border-t border-[var(--morandi-stone)]/40 flex gap-2">
                {user ? (
                  <>
                    <button onClick={() => { setShowProfile(true); setMenuOpen(false); }} className="flex-1 py-2.5 rounded-lg border border-[var(--morandi-stone)]/50 text-sm text-[var(--morandi-charcoal)] text-center">
                      修改資訊（{user.name}）
                    </button>
                    <button onClick={() => { handleLogout(); setMenuOpen(false); }} className="px-3 py-2.5 rounded-lg border border-[var(--morandi-stone)]/50 text-sm text-[var(--morandi-charcoal)]">
                      登出
                    </button>
                  </>
                ) : (
                  <>
                    <button onClick={() => { openLogin(); setMenuOpen(false); }} className="flex-1 py-2.5 rounded-lg border border-[var(--morandi-stone)]/50 text-sm text-[var(--morandi-charcoal)] text-center">登入</button>
                    <button onClick={() => { openRegister(); setMenuOpen(false); }} className="flex-1 py-2.5 rounded-lg bg-[var(--morandi-sage)] text-white text-sm text-center">免費註冊</button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {currentView === 'landing' && <LandingPage onNavigate={(v) => setCurrentView(v as View)} />}
        {currentView === 'renter' && <RenterMapView properties={properties} mrtStations={mrtStations} />}
        {currentView === 'tenant-dashboard' && (
          <TenantDashboard onSwitchToSearch={() => setCurrentView('renter')} />
        )}
        {currentView === 'landlord' && (
          <LandlordDashboard
            tenantProfiles={tenantProfiles}
            contracts={contracts}
            rentPayments={rentPayments}
            maintenanceRequests={maintenanceRequests}
            taxBenefits={taxBenefits}
          />
        )}
      </main>
    </div>
  );
}

function NavBtn({
  active, onClick, icon: Icon, label
}: {
  active: boolean; onClick: () => void;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}) {
  return (
    <button onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 text-sm ${active ? 'bg-[var(--morandi-sage)] text-white shadow-md' : 'text-[var(--morandi-charcoal)] hover:bg-[var(--morandi-muted)]'}`}>
      <Icon className="w-4 h-4" />
      <span>{label}</span>
    </button>
  );
}
