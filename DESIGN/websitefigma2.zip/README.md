# 🏠 次世代租屋平台 MVP

> 採用莫蘭迪美學的現代化智能租屋平台，整合 AI 媒合、租補服務與房東管理系統

[![React](https://img.shields.io/badge/React-18.3.1-61dafb?logo=react)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.x-3178c6?logo=typescript)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-4.1.12-38bdf8?logo=tailwind-css)](https://tailwindcss.com/)
[![Vite](https://img.shields.io/badge/Vite-6.3.5-646cff?logo=vite)](https://vitejs.dev/)

---

## ✨ 專案亮點

### 🎨 設計美學
- **莫蘭迪配色系統**：鼠尾草綠、煙燻紫、石楠藍的和諧搭配
- **Google Fonts**：Inter + Manrope 雙字體優雅排版
- **流暢動畫**：CSS3 原生動畫，60fps 絲滑體驗
- **響應式設計**：完美適配 Desktop / Tablet / Mobile

### 🚀 核心功能

#### 租客端
- ✅ AI 智能媒合（87-92% 高精準契合度）
- ✅ 互動式地圖（SVG 地圖 + 捷運站點標記）
- ✅ 租補整合篩選（一鍵過濾合格物件）
- ✅ 生活機能評分（5 大維度視覺化）
- ✅ 通勤時間試算（捷運距離 + 步行時間）
- ✅ 匿名評論系統（真實租客回饋）

#### 房東端
- ✅ 租客履歷管理（AI 評分 + 信用分數）
- ✅ 電子簽約追蹤（進度可視化）
- ✅ 租金催收系統（自動提醒）
- ✅ 修繕請求處理（緊急度分類）
- ✅ 節稅試算工具（公益出租人免稅計算）

### 🔐 信任機制
- 實名認證藍勾勾
- 房東評分與回覆率
- 租客信用分數檢視
- 文件上傳狀態追蹤

---

## 📁 專案結構

```
nextgen-rental/
├── src/
│   ├── app/
│   │   ├── App.tsx                    # 主應用程式（導航系統）
│   │   └── components/
│   │       ├── LandingPage.tsx        # 首頁（374 行）
│   │       ├── RenterMapView.tsx      # 找房地圖（607 行）
│   │       └── LandlordDashboard.tsx  # 房東後台（835 行）
│   ├── mockData.ts                    # Mock 資料（513 行）
│   └── styles/
│       ├── fonts.css                  # Google Fonts
│       ├── globals.css                # 全域樣式與動畫
│       ├── theme.css                  # 莫蘭迪配色系統
│       └── index.css                  # 樣式入口
├── package.json
├── vite.config.ts
├── PROJECT_SUMMARY.md                 # 專案總結
├── USER_GUIDE.md                      # 使用指南
└── README.md                          # 本文件

總計：2,389 行程式碼
```

---

## 🎨 莫蘭迪配色系統

```css
/* 主色調 */
--morandi-sage: #9CAF88          /* 鼠尾草綠 - 主要操作 */
--morandi-mauve: #AFA3B0         /* 煙燻紫 - 點綴色 */
--morandi-slate: #98A8B8         /* 石楠藍 - 次要色 */

/* 背景色 */
--morandi-warm-white: #F5F1ED    /* 暖白色 */
--morandi-grey-taupe: #EBE6E0    /* 灰陶色 */

/* 輔助色 */
--morandi-stone: #D4CDC3         /* 石灰色 - 邊框 */
--morandi-clay: #C9C0B8          /* 黏土色 */
--morandi-charcoal: #4A4A4A      /* 炭灰色 - 文字 */
```

---

## 🖼️ 頁面預覽

### 首頁（Landing Page）
- Hero Section with CTA
- 三大特色介紹（認證 / AI / 租補）
- AI 推薦房源（Top 3）
- 房東成功案例

### 找房地圖頁（Renter Map View）
- 左側：篩選器 + 房源列表
- 右側：互動式 SVG 地圖
- 彈窗：房源詳情（圖片 / 評分 / 評論）

### 房東後台（Landlord Dashboard）
- 統計儀表板（4 大指標）
- 5 大功能分頁：
  1. 租客履歷
  2. 合約管理
  3. 租金催收
  4. 修繕請求
  5. 節稅試算

---

## 🛠️ 技術棧

### 前端框架
- **React** 18.3.1 - UI 框架
- **TypeScript** - 型別安全
- **Vite** 6.3.5 - 快速構建工具

### 樣式系統
- **Tailwind CSS** 4.1.12 - 原子化 CSS
- **CSS Custom Properties** - 主題變數
- **CSS3 Animations** - 原生動畫

### UI 組件庫
- **Radix UI** - 無樣式組件（Tabs / Progress / Switch）
- **Lucide React** - 圖標庫
- **Unsplash** - 高畫質房源圖片

---

## 📊 資料模型

### Property（房源）
- 基本資訊：標題、地址、價格、坪數
- 房東資訊：姓名、認證狀態、評分
- 租補資訊：是否合格、補助金額
- 生活機能：5 大評分（交通/購物/餐飲/醫療/教育）
- 通勤資訊：最近捷運站、距離、時間
- 評論列表：匿名租客回饋
- AI 媒合：契合度百分比 + 原因

### Tenant（租客）
- 個人資料：姓名、年齡、職業
- 收入資訊：公司、月收入、信用分數
- 認證狀態：文件上傳進度
- AI 評分：契合度分數
- 標籤：穩定工作、無不良紀錄等

### Contract（合約）
- 租客與物件資訊
- 租約期間與金額
- 簽約進度追蹤
- 繳款日期提醒

### Maintenance（修繕）
- 問題描述與類別
- 緊急度分級（高/中/低）
- 處理狀態與師傅
- 預估費用與完成日期

---

## 🎯 核心功能實現

### AI 智能媒合
```typescript
// 根據用戶需求計算契合度
aiMatch: 87-92%
matchReasons: [
  "通勤時間符合",
  "生活機能優秀", 
  "價格在預算內"
]
```

### 租補篩選
```typescript
// Toggle 開關即時過濾
subsidyOnly: boolean
filteredProperties = properties.filter(p => 
  !subsidyOnly || p.subsidy
)
```

### 生活機能評分
```typescript
lifeScores: {
  transport: 92,   // 交通
  shopping: 88,    // 購物
  dining: 95,      // 餐飲
  medical: 85,     // 醫療
  education: 90    // 教育
}
```

### 節稅試算
```typescript
// 公益出租人享 60% 租金免稅
taxableIncome = monthlyRent * 12 * 0.6
savedIncomeTax = monthlyRent * 12 * 0.4 * 0.2

// 地價稅減免 22%
savedLandTax = landTax * 0.22

// 房屋稅減免 33%
savedHouseTax = houseTax * 0.33

// 年度總節稅
totalSavings = savedIncomeTax + savedLandTax + savedHouseTax
```

---

## 📱 響應式斷點

```css
/* Mobile First */
@media (min-width: 640px)  { /* sm */ }
@media (min-width: 768px)  { /* md - Tablet */ }
@media (min-width: 1024px) { /* lg - Desktop */ }
@media (min-width: 1280px) { /* xl */ }
```

### 佈局適配
- **Desktop（≥1024px）**：地圖頁左右分欄（列表 + 地圖）
- **Tablet（768-1023px）**：上下分欄或卡片網格
- **Mobile（<768px）**：單欄堆疊 + 漢堡選單

---

## 🌈 動畫系統

### 頁面切換
```css
.fade-in { 
  animation: fade-in 0.5s ease-in-out; 
}
```

### 卡片互動
```css
.hover\:scale-105:hover { 
  transform: scale(1.05); 
}
.hover\:shadow-xl:hover { 
  box-shadow: 0 20px 25px rgba(0,0,0,0.15); 
}
```

### 地圖標記
```css
@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
}
```

---

## 📖 文件導航

- **[專案總結](./PROJECT_SUMMARY.md)** - 完整功能列表與技術細節
- **[使用指南](./USER_GUIDE.md)** - 詳細操作說明與互動技巧
- **[README](./README.md)** - 本文件（專案概覽）

---

## 🎉 開始使用

### 預覽應用程式
應用程式已在 **Figma Make 預覽窗口**中運行，無需額外設定。

### 推薦體驗路徑
1. **首頁** - 了解平台特色與 AI 推薦
2. **找房地圖** - 調整篩選器，探索互動地圖
3. **房東後台** - 查看管理功能與節稅試算

### 互動技巧
- 🖱️ **Hover** 元素查看互動效果
- 🖱️ **點擊**房源卡片開啟詳情
- 🔄 **切換**篩選器即時更新列表
- 📝 **輸入**數字查看節稅計算

---

## 💡 設計理念

### 莫蘭迪美學
選用低飽和度配色，營造**專業、舒適、文青質感**的視覺體驗，讓用戶在找房過程中感受到平靜與信任。

### 信任優先
透過**實名認證**、**AI 評分**、**匿名評論**，建立雙向透明的信任機制，降低租屋糾紛風險。

### 租補整合
將政府租屋補助無縫整合進篩選流程，讓用戶**一鍵**找到合格物件，**自動**計算可省金額。

### 數據驅動
用**生活機能評分**、**通勤時間**等量化指標，幫助用戶做出更理性的租屋決策。

---

## 📈 未來展望

### Phase 2 功能規劃
- [ ] 真實地圖整合（Google Maps API）
- [ ] 後端 API 串接（Supabase / Firebase）
- [ ] 即時聊天系統（房東租客溝通）
- [ ] 線上簽約流程（電子簽章）
- [ ] 繳款金流整合（信用卡/轉帳）
- [ ] 推播通知系統（租金提醒/修繕更新）

### 技術優化
- [ ] SSR / SSG（Next.js）
- [ ] 圖片懶加載與優化
- [ ] PWA 離線支援
- [ ] 效能監控（Web Vitals）
- [ ] E2E 測試（Playwright）

---

## 🤝 貢獻指南

本專案為 MVP 原型，歡迎提供建議與回饋！

### 回饋方式
- 🐛 回報 Bug：描述問題與重現步驟
- 💡 功能建議：說明使用情境與預期效果
- 🎨 設計優化：提供視覺或互動改進建議

---

## 📄 授權

本專案僅供學習與展示用途。

---

## 🙏 致謝

- **設計靈感**：莫蘭迪色彩美學
- **圖片來源**：[Unsplash](https://unsplash.com/)
- **圖標來源**：[Lucide Icons](https://lucide.dev/)
- **UI 組件**：[Radix UI](https://www.radix-ui.com/)

---

<div align="center">

**Built with ❤️ using React + TypeScript + Tailwind CSS**

🏠 [查看完整專案總結](./PROJECT_SUMMARY.md) | 📖 [閱讀使用指南](./USER_GUIDE.md)

</div>
