window.mockData = (function() {
  // --- Generate 200 Properties ---
  const districts = ['大安區', '中山區', '信義區', '中正區', '松山區', '大同區', '萬華區', '文山區', '南港區', '內湖區'];
  const types = ['雅房', '套房', '整層住家'];
  const prefixes = ['文青', '簡約', '質感', '寬敞', '明亮', '舒適', '高樓景觀', '台水電', '可貓', '獨立陽台', '全新裝潢', '採光極佳'];
  const suffixes = ['精緻房', '小木屋', '大空間', '靜巷美屋', '捷運宅', '綠意房', '設計款', '溫馨窩'];
  
  // Define bounding box for districts - calibrated to Taipei MRT map image
  // Map image origin: top-left = NW Taipei, bottom-right = SE Taipei
  const districtBounds = {
    '大安區': { minX: 49, maxX: 59, minY: 60, maxY: 70 }, // Center (忠孝復興~大安)
    '中山區': { minX: 42, maxX: 56, minY: 43, maxY: 55 }, // Center-North (中山~行天宮~松江南京)
    '信義區': { minX: 62, maxX: 76, minY: 60, maxY: 70 }, // East (市政府~象山)
    '中正區': { minX: 37, maxX: 50, minY: 60, maxY: 71 }, // Center-West (東門~善導寺~中正紀念堂)
    '松山區': { minX: 58, maxX: 74, minY: 47, maxY: 57 }, // East-North (南京三民~松山)
    '大同區': { minX: 32, maxX: 46, minY: 40, maxY: 53 }, // West-North (大橋頭~雙連)
    '萬華區': { minX: 29, maxX: 42, minY: 55, maxY: 66 }, // West (西門~龍山寺)
    '文山區': { minX: 50, maxX: 72, minY: 82, maxY: 95 }, // South (動物園~萬芳)
    '南港區': { minX: 74, maxX: 92, minY: 55, maxY: 65 }, // Far East (昆陽~南港)
    '內湖區': { minX: 63, maxX: 90, minY: 34, maxY: 48 }  // NE (港墘~內湖)
  };

  // Per-station pin coordinates - carefully pixel-measured from Taipei MRT map image
  // Key reference anchors: 台北車站≈(38,58), 忠孝復興≈(52,62), 象山≈(70,65), 動物園≈(62,91)
  // Image is ~1100×1100px, map covers Taipei with NW at top-left, SE at bottom-right
  const stationCoords = {
    // 板南線 (Blue horizontal line across the middle)
    '善導寺':       { x: 43.0, y: 60.5 },
    '忠孝新生':    { x: 47.0, y: 61.5 },
    '忠孝復興':    { x: 52.0, y: 61.5 },
    '忠孝敦化':    { x: 57.5, y: 61.5 },
    '國父紀念館':  { x: 61.0, y: 61.5 },
    '市政府':     { x: 65.5, y: 61.5 },
    '後山埠':     { x: 72.5, y: 61.5 },
    '昆陽':       { x: 79.5, y: 61.5 },
    '南港':       { x: 87.0, y: 61.5 },
    '南港展覽館':  { x: 93.0, y: 61.5 },
    '西門':       { x: 37.5, y: 60.0 },
    '龍山寺':     { x: 32.5, y: 62.0 },
    '台大醫院':    { x: 40.5, y: 58.0 },

    // 淡水信義線 (Red: runs N-S on left, then SE)
    '雙連':       { x: 41.5, y: 46.5 },
    '中山':       { x: 41.5, y: 51.5 },
    '大安森林公園':  { x: 49.5, y: 65.5 },
    '大安':       { x: 52.5, y: 69.0 },
    '信義安和':    { x: 57.5, y: 69.0 },
    '台北101/世貿':  { x: 62.5, y: 69.0 },
    '象山':       { x: 70.0, y: 65.5 },
    '中正紀念堂':  { x: 40.0, y: 68.0 },

    // 中和新蘆線 (Orange: NW-center diagonal)
    '行天宮':     { x: 51.5, y: 50.0 },
    '松江南京':    { x: 46.5, y: 52.0 },
    '東門':       { x: 47.5, y: 65.5 },
    '大橋頭':     { x: 33.5, y: 47.5 },

    // 松山新店線 (Green: E-W central line)
    '南京復興':    { x: 55.0, y: 52.0 },
    '南京三民':    { x: 67.5, y: 49.5 },
    '松山':       { x: 75.0, y: 49.5 },
    '古亭':       { x: 45.5, y: 72.0 },

    // 文湖線 (Brown: eastern loop)
    '港墘':       { x: 69.5, y: 41.0 },
    '內湖':       { x: 76.0, y: 39.5 },
    '文德':       { x: 83.0, y: 37.5 },
    '萬芳醫院':    { x: 65.5, y: 83.5 },
    '萬芳社區':    { x: 67.0, y: 87.0 },
    '動物園':     { x: 62.0, y: 91.5 }
  };

  // MRT lines and stations mapping for Location Search Tree
  const mrtOptions = {
    '大安區': [{ line: '板南線', station: '忠孝復興' }, { line: '板南線', station: '國父紀念館' }, { line: '淡水信義線', station: '大安' }],
    '中山區': [{ line: '中和新蘆線', station: '行天宮' }, { line: '中和新蘆線', station: '松江南京' }, { line: '松山新店線', station: '南京復興' }],
    '信義區': [{ line: '淡水信義線', station: '象山' }, { line: '淡水信義線', station: '台北101/世貿' }, { line: '板南線', station: '市政府' }],
    '中正區': [{ line: '板南線', station: '善導寺' }, { line: '中和新蘆線', station: '東門' }, { line: '淡水信義線', station: '中正紀念堂' }, { line: '松山新店線', station: '古亭' }],
    '松山區': [{ line: '松山新店線', station: '南京三民' }, { line: '松山新店線', station: '松山' }],
    '大同區': [{ line: '淡水信義線', station: '雙連' }, { line: '中和新蘆線', station: '大橋頭' }],
    '萬華區': [{ line: '板南線', station: '西門' }, { line: '板南線', station: '龍山寺' }],
    '文山區': [{ line: '文湖線', station: '動物園' }, { line: '文湖線', station: '萬芳醫院' }],
    '南港區': [{ line: '板南線', station: '南港' }, { line: '板南線', station: '昆陽' }],
    '內湖區': [{ line: '文湖線', station: '內湖' }, { line: '文湖線', station: '港墘' }]
  };
  
  const properties = [];
  for (let i = 1; i <= 200; i++) {
    const isSubsidy = Math.random() > 0.3; // 70% chance
    const priceBucket = (i - 1) % 10;
    let type = '雅房';
    let price = 8000;
    if (priceBucket <= 3) {
      type = priceBucket % 2 === 0 ? '雅房' : '套房';
      price = 6500 + Math.floor(Math.random() * 4) * 800;
    } else if (priceBucket <= 6) {
      type = priceBucket % 2 === 0 ? '套房' : '雅房';
      price = 11000 + Math.floor(Math.random() * 6) * 700;
    } else if (priceBucket <= 8) {
      type = priceBucket % 2 === 0 ? '套房' : '整層住家';
      price = 15000 + Math.floor(Math.random() * 6) * 800;
    } else {
      type = '整層住家';
      price = 21000 + Math.floor(Math.random() * 9) * 1500;
    }
    
    const dist = districts[i % districts.length];
    const bounds = districtBounds[dist];
    // 改回原本的行政區隨機散布，提升地圖點定位精確度與視覺協調度
    const mapX = bounds.minX + Math.random() * (bounds.maxX - bounds.minX);
    const mapY = bounds.minY + Math.random() * (bounds.maxY - bounds.minY);
    
    const pre = prefixes[Math.floor(Math.random() * prefixes.length)];
    const suf = suffixes[Math.floor(Math.random() * suffixes.length)];
    const rating = (4 + Math.random()).toFixed(1);

    // MRT Line & Station assignment
    const options = mrtOptions[dist];
    const chosenMrt = options[(i - 1) % options.length];
    
    properties.push({
      id: 1000 + i,
      title: `${dist} ${pre}${suf} ${type}`,
      address: `台北市${dist}XX路XX號`,
      district: dist,
      price: price,
      size: 5 + Math.floor(Math.random() * 25),
      type: type,
      subsidy: isSubsidy,
      mrtLine: chosenMrt.line,
      mrtStation: chosenMrt.station,
      images: [
        `https://images.unsplash.com/photo-${1500000000000 + (i%50) * 10000}?w=800&h=600&fit=crop`
      ],
      aiMatch: 60 + Math.floor(Math.random() * 38),
      mapX: mapX,
      mapY: mapY,
      landlord: { rating: rating },
      reviews: Array(Math.floor(Math.random() * 20) + 1).fill(0)
    });
  }
  
  // Safe sample images
  const sampleImages = [
    'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1536376072261-38c75010e6c9?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop'
  ];
  properties.forEach((p, i) => p.images[0] = sampleImages[i % sampleImages.length]);

  // --- Generate 20 Roommates with logic attributes ---
  const roommateNames = ['林大志', '陳小如', '王彥文', '張嘉慧', '李明翰', '黃佳玲', '吳柏毅', '劉子瑜', '蔡秉叡', '楊宜蓁', '許建國', '鄭欣宜', '謝承恩', '郭品妤', '洪偉哲', '邱郁婷', '曾俊傑', '廖家儀', '賴柏宇', '徐珮琪'];
  const depts = ['資工系', '設計系', '企管系', '電機系', '機械系', '化工系', '材資系', '土木系', '光電系', '建都所'];
  
  const roommates = [];
  for (let i = 0; i < 20; i++) {
    roommates.push({
      id: 2000 + i,
      name: roommateNames[i],
      dept: `${depts[i % depts.length]} ${1 + Math.floor(Math.random()*4)} 年級`,
      tags: ['早睡早起', '愛乾淨', '不抽菸', '偶爾帶朋友', '有養貓', '隨和', '晚睡'].sort(() => 0.5 - Math.random()).slice(0, 3),
      img: `https://i.pravatar.cc/150?img=${10 + i}`,
      traits: {
        sleep: Math.floor(Math.random() * 3),
        pet: Math.floor(Math.random() * 3),
        clean: Math.floor(Math.random() * 3),
        cook: Math.floor(Math.random() * 3),
        rent: Math.floor(Math.random() * 3)
      },
      match: 0
    });
  }

  // --- Generate Landlord Dashboard Data ---
  const llProperties = [];
  const llTenants = [];
  const llContracts = [];
  const llPayments = [];
  const llRepairs = [];
  const llTaxes = [];
  
  // Create 5 coherent stories (added repair severity for Heap sorting)
  const stories = [
    {
      propName: '大安區 靜巷美套房', address: '台北市大安區和平東路二段',
      price: 18000, status: '出租中', tenant: '陳信宏',
      contractStart: '2025-08-01', contractEnd: '2026-07-31',
      paymentStatus: '已繳清', repairIssue: '無', repairStatus: '無',
      repairSeverity: 4,
      taxStatus: '符合公益出租'
    },
    {
      propName: '中山區 捷運高樓景觀', address: '台北市中山區南京東路三段',
      price: 25000, status: '出租中', tenant: '林依晨',
      contractStart: '2025-10-15', contractEnd: '2026-10-14',
      paymentStatus: '逾期未繳', repairIssue: '冷氣不冷', repairStatus: '處理中',
      repairSeverity: 2,
      taxStatus: '符合公益出租'
    },
    {
      propName: '信義區 簡約一房一廳', address: '台北市信義區信義路五段',
      price: 32000, status: '出租中', tenant: '周杰倫',
      contractStart: '2026-02-01', contractEnd: '2027-01-31',
      paymentStatus: '已繳清', repairIssue: '熱水器故障', repairStatus: '已結案',
      repairSeverity: 2,
      taxStatus: '不符合 (無申請租補)'
    },
    {
      propName: '松山區 溫馨小雅房', address: '台北市松山區民生東路四段',
      price: 9000, status: '待簽約', tenant: '蔡依林',
      contractStart: '-', contractEnd: '-',
      paymentStatus: '-', repairIssue: '無', repairStatus: '無',
      repairSeverity: 4,
      taxStatus: '審核中'
    },
    {
      propName: '中正區 北車通勤宅', address: '台北市中正區羅斯福路一段',
      price: 15000, status: '空置中', tenant: null,
      contractStart: '-', contractEnd: '-',
      paymentStatus: '-', repairIssue: '全室油漆粉刷', repairStatus: '處理中',
      repairSeverity: 4,
      taxStatus: '無租約'
    }
  ];

  stories.forEach((story, i) => {
    const isRented = story.status === '出租中';
    const isPending = story.status === '待簽約';

    llProperties.push({
      id: 3000 + i,
      name: story.propName,
      address: story.address,
      status: story.status,
      price: story.price,
      tenant: story.tenant,
      nextDate: isRented ? '2026-07-05' : null,
    });
    
    if (isRented || isPending) {
      llTenants.push({
        name: story.tenant,
        target: story.propName,
        status: isRented ? '審核通過' : '審核中',
        date: isRented ? story.contractStart : '2026-06-10'
      });
    }

    if (isRented) {
      llContracts.push({
        target: story.propName,
        tenant: story.tenant,
        endDate: story.contractEnd,
        status: '生效中'
      });
      
      llPayments.push({
        target: story.propName,
        tenant: story.tenant,
        amount: story.price,
        dueDate: '2026-06-05',
        status: story.paymentStatus
      });
    }

    if (story.repairIssue !== '無') {
      llRepairs.push({
        target: story.propName,
        issue: story.repairIssue,
        date: '2026-06-01',
        status: story.repairStatus,
        severity: story.repairSeverity,
        note: story.repairStatus === '處理中' ? '已排定水電師傅前往。' : '租客確認修復完畢。'
      });
    }
    
    if (isRented || isPending) {
       llTaxes.push({
         target: story.propName,
         rentIncome: story.price * 12,
         savedTax: story.taxStatus.includes('符合') ? 14400 : 0,
         status: story.taxStatus
       });
     }
  });

  // Add a Severity 1 emergency ticket to showcase Priority Queue heap-sorting on load
  llRepairs.push({
    target: '大安區 靜巷美套房',
    issue: '瓦斯漏氣及主水管破裂',
    date: '2026-06-17',
    status: '待處理',
    severity: 1,
    note: '租客反映廚房後陽台有瓦斯味，且室內主水管破裂出現積水滲漏，需緊急派員！'
  });

  // Landlord auto-reply chat templates
  const chatReplies = [
    "您好！我是這間房源的房東。這間房子通風採光非常好，且離北科大跟捷運站都很近，請問您什麼時候方便預約看房呢？",
    "同學您好！這間房源目前已經有兩組學生在詢問囉，非常搶手。如果您有意願，可以先完成北科實名驗證，並在線上與我約時間看屋！",
    "您好，電費是照獨立電錶收費（依照台電費率核實收費，不溢收）。押金部分依照規定收取兩個月，退租點交後立即歸還喔！",
    "好的！這週六下午兩點到四點我方便帶您看房。我們可以直接約在房源樓下大門口見面，到了再傳訊息或打電話給我就好！",
    "您好，本物件完全配合『定型化契約』規範，房東也已認證為『公益出租人』，因此非常歡迎同學向政府申請『租金補貼』，合法報稅申報扣除額！"
  ];

  return {
    properties,
    roommates,
    chatReplies,
    landlord: {
      properties: llProperties,
      tenants: llTenants,
      contracts: llContracts,
      payments: llPayments,
      repairs: llRepairs,
      taxes: llTaxes
    }
  };
})();
