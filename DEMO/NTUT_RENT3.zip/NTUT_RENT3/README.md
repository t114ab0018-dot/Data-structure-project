# 北科安心租 NTUT_RENT2

這是一個純前端靜態 Demo，展示「北科安心租」學生租屋與房東管理流程。

## 如何執行

下載後直接用瀏覽器開啟 `index.html` 即可。

不需要：

- npm
- 後端伺服器
- 資料庫
- API key
- 真實登入系統

## 主要檔案

- `index.html`：頁面 0 到頁面 8 的 DOM 結構
- `style.css`：全域樣式、卡片、地圖、Dashboard、個人資料頁
- `script.js`：頁面切換、登入狀態、房源渲染、簽約、報修、房東管理互動
- `data/mockData.js`：房源、室友、房東後台假資料
- `Untitled design.png`：Page 3 靜態地圖圖片

## Demo 頁面

- Page 0：首頁
- Page 1：學生登入 / 註冊
- Page 2：房東認證 / 登入
- Page 3：地圖找房
- Page 4：室友配對
- Page 5：合約簽署
- Page 6：我的租屋生活
- Page 7：房東管理後台
- Page 8：學生個人資料
