// Global Navigation
function navigateTo(pageId) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(page => {
    page.classList.remove('active');
  });
  // Show target page
  const targetPage = document.getElementById(`page-${pageId}`);
  if (targetPage) {
    targetPage.classList.add('active');
    if (pageId === 8) renderProfilePage();
    if (pageId === 3) {
      updateMapDashboardButton();
      filterProperties();
    }
    updateNavState();
    window.scrollTo(0, 0);
  }
}

// Global state
let currentLandlordTab = 'properties';
let currentStudentTab = 'rent';
let currentZoom = 0.5; // Start zoomed out slightly
let signedPropertyPrice = 15000; // Track signed property price
let uploadedLandlordDocs = false;
let studentAfterLoginTarget = null;
let pendingStudentAction = null;
let appState = {
  studentLoggedIn: false,
  landlordLoggedIn: false,
  signedContract: false,
  signedProperty: null,
  rentRecords: [],
  repairTickets: [],
  contractNotes: [],
  landlordNotes: {},
  profile: {},
  favoritePropertyIds: new Set(),
  recentPropertyIds: []
};

function createInitialState() {
  return {
    studentLoggedIn: false,
    landlordLoggedIn: false,
    signedContract: false,
    signedProperty: null,
    rentRecords: [
      { date: '2026-05-03', status: '已繳清', amount: signedPropertyPrice, method: '線上轉帳' },
      { date: '2026-04-05', status: '已繳清', amount: signedPropertyPrice, method: '線上轉帳' },
      { date: '2026-03-02', status: '已繳清', amount: signedPropertyPrice, method: 'ATM' },
      { date: '2026-02-05', status: '已繳清', amount: signedPropertyPrice, method: '線上轉帳' },
      { date: '2026-01-04', status: '已繳清', amount: signedPropertyPrice, method: '線上轉帳' },
      { date: '2025-12-05', status: '已繳清', amount: signedPropertyPrice, method: 'ATM' }
    ],
    repairTickets: [
      { date: '2026-05-29', issue: '冷氣不冷 (客廳)', status: '處理中', class: 'badge-warning', note: '房東已派師傅聯繫' },
      { date: '2025-10-12', issue: '熱水器點火不順', status: '已結案', class: 'badge-gray', note: '已更換電池' },
      { date: '2025-08-03', issue: '洗手台水管微漏水', status: '已結案', class: 'badge-gray', note: '已重新鎖緊接頭' }
    ],
    contractNotes: [
      { date: '2026-06-15', text: '已完成電子簽約與閱讀確認。' }
    ],
    landlordNotes: {},
    profile: {
      name: '王小明',
      phone: '0912-345-678',
      email: 'student@ntut.edu.tw',
      dept: '資工系 3 年級',
      avatarColor: 0
    },
    favoritePropertyIds: new Set(),
    recentPropertyIds: []
  };
}

// Initial Data Loading
document.addEventListener('DOMContentLoaded', () => {
  appState = createInitialState();
  if (window.mockData && window.mockData.properties) {
    renderHomeCarousel(window.mockData.properties);
    renderMapList(window.mockData.properties);
    renderMapMarkers(window.mockData.properties);
    initDraggableMap();
    handlePriceRangeInput(false);
    switchLandlordTab('properties'); // Init Page 7
    switchStudentTab('rent'); // Init Page 6
    
    // Set initial filter count
    document.getElementById('property-count').innerText = window.mockData.properties.length;
    updateNavState();
  }
});

function updateNavState() {
  const activePageId = document.querySelector('.page.active')?.id || 'page-0';
  const pageNumber = Number(activePageId.replace('page-', ''));
  const homeLink = document.getElementById('nav-home-link');
  const studentLink = document.getElementById('nav-student-link');
  const landlordLink = document.getElementById('nav-landlord-link');
  const profileIcon = document.getElementById('nav-profile-icon');
  const hideHomeAndStudent = [3, 5, 6, 7, 8].includes(pageNumber);
  if (homeLink) {
    homeLink.style.display = hideHomeAndStudent ? 'none' : '';
  }
  if (studentLink) {
    studentLink.style.display = hideHomeAndStudent ? 'none' : '';
  }
  if (landlordLink) {
    landlordLink.style.display = appState.studentLoggedIn || pageNumber === 7 ? 'none' : '';
  }
  if (profileIcon) {
    profileIcon.classList.toggle('visible', appState.studentLoggedIn);
  }
}

function updateMapDashboardButton() {
  const btn = document.getElementById('back-to-dashboard-btn');
  if (btn) btn.style.display = appState.signedContract ? 'inline-flex' : 'none';
}

function goStudentEntry() {
  if (!appState.studentLoggedIn) {
    navigateTo(1);
    return;
  }
  navigateTo(appState.signedContract ? 6 : 3);
}

function goProfileEntry() {
  if (!appState.studentLoggedIn) {
    studentAfterLoginTarget = 8;
    navigateTo(1);
    return;
  }
  navigateTo(8);
}

function goLandlordEntry() {
  navigateTo(appState.landlordLoggedIn ? 7 : 2);
}

function switchAuthPanel(role, mode) {
  const loginPanel = document.getElementById(`${role}-login-panel`);
  const registerPanel = document.getElementById(`${role}-register-panel`);
  const buttons = document.querySelectorAll(`#page-${role === 'student' ? 1 : 2} .segmented-control button`);
  if (!loginPanel || !registerPanel) return;
  loginPanel.style.display = mode === 'login' ? 'block' : 'none';
  registerPanel.style.display = mode === 'register' ? 'block' : 'none';
  buttons.forEach(btn => btn.classList.remove('active'));
  buttons[mode === 'login' ? 0 : 1]?.classList.add('active');
}

function loginStudent(mode = 'login') {
  appState.studentLoggedIn = true;
  appState.landlordLoggedIn = false;
  setupStudentSession(mode);
  syncProfileInputsFromLogin();
  if (pendingStudentAction) {
    const action = pendingStudentAction;
    pendingStudentAction = null;
    if (action.type === 'favorite') {
      toggleFavoriteProperty(action.propertyId);
      navigateTo(8);
      return;
    }
    if (action.type === 'contract') {
      prepareContract(action.price, action.propertyId);
      return;
    }
  }
  if (studentAfterLoginTarget) {
    const target = studentAfterLoginTarget;
    studentAfterLoginTarget = null;
    navigateTo(target);
    return;
  }
  navigateTo(appState.signedContract ? 6 : 3);
}

function setupStudentSession(mode) {
  if (mode === 'register') {
    appState.favoritePropertyIds = new Set();
    appState.recentPropertyIds = [];
    renderHomeCarousel(window.mockData.properties);
    return;
  }
  if (appState.favoritePropertyIds.size === 0 && appState.recentPropertyIds.length === 0 && window.mockData?.properties) {
    appState.favoritePropertyIds = new Set(window.mockData.properties.slice(0, 2).map(prop => prop.id));
    appState.recentPropertyIds = window.mockData.properties.slice(2, 5).map(prop => prop.id);
  }
  renderHomeCarousel(window.mockData.properties);
}

function loginLandlord() {
  appState.landlordLoggedIn = true;
  appState.studentLoggedIn = false;
  updateNavState();
  navigateTo(7);
}

function getTodayString() {
  return new Date().toISOString().slice(0, 10);
}

function openModal(title, bodyHtml, actionsHtml = '') {
  closeModal();
  const modal = document.createElement('div');
  modal.className = 'modal-backdrop';
  modal.id = 'app-modal';
  modal.innerHTML = `
    <div class="modal-panel">
      <div class="flex justify-between items-center gap-4">
        <h3 style="margin:0;">${title}</h3>
        <button class="btn btn-outline" style="padding:0.35rem 0.75rem;" onclick="closeModal()">關閉</button>
      </div>
      <div style="margin-top:1rem;">${bodyHtml}</div>
      ${actionsHtml ? `<div class="modal-actions">${actionsHtml}</div>` : ''}
    </div>
  `;
  modal.addEventListener('click', (event) => {
    if (event.target.id === 'app-modal') closeModal();
  });
  document.body.appendChild(modal);
}

function closeModal() {
  const modal = document.getElementById('app-modal');
  if (modal) modal.remove();
}

function getPropertyById(propertyId) {
  return window.mockData.properties.find(prop => prop.id === propertyId);
}

function recordPropertyView(propertyId) {
  appState.recentPropertyIds = [propertyId, ...appState.recentPropertyIds.filter(id => id !== propertyId)].slice(0, 6);
}

function toggleFavoriteProperty(propertyId) {
  if (!appState.studentLoggedIn) {
    pendingStudentAction = { type: 'favorite', propertyId };
    studentAfterLoginTarget = null;
    navigateTo(1);
    return;
  }
  if (appState.favoritePropertyIds.has(propertyId)) {
    appState.favoritePropertyIds.delete(propertyId);
  } else {
    appState.favoritePropertyIds.add(propertyId);
  }
  renderProfilePage();
  filterProperties();
}

// Accordion Toggle
function toggleAccordion(element) {
  const content = element.nextElementSibling;
  const icon = element.querySelector('svg');
  if (content.style.maxHeight) {
    content.style.maxHeight = null;
    content.style.marginTop = '0';
    icon.style.transform = 'rotate(0deg)';
  } else {
    content.style.maxHeight = content.scrollHeight + "px";
    content.style.marginTop = '0.5rem';
    icon.style.transform = 'rotate(180deg)';
  }
}

// --- Page 0: Home Carousel ---
function renderHomeCarousel(properties) {
  const container = document.getElementById('home-carousel');
  if (!container) return;
  
  const topProps = properties.slice(0, 5);
  let html = '';
  topProps.forEach(prop => {
    const badgeHtml = prop.subsidy 
      ? `<div class="abs-badge badge">可租補</div>`
      : `<div class="abs-badge badge badge-gray">不可租補</div>`;
      
    html += `
      <div class="property-card">
        ${badgeHtml}
        <img src="${prop.images[0]}" alt="Property Image" onclick="viewPropertyDetail(${prop.id})">
        <div class="content">
          <div class="flex justify-between items-center mb-2">
            <h3 style="margin:0;">${prop.title}</h3>
            <div class="price">$${prop.price.toLocaleString()}</div>
          </div>
          <p style="font-size:0.9rem; margin-bottom:0.5rem;">${prop.address} · ${prop.size}坪 · ${prop.type}</p>
          <div class="flex items-center justify-between mt-2">
            <div style="font-size:0.8rem; color:#E2B255; font-weight:600;">
              ★ ${prop.landlord.rating} (${prop.reviews.length}則評價)
            </div>
            <div style="font-size:0.8rem; color:var(--morandi-sage); font-weight:600;">
              AI 契合度: ${prop.aiMatch}%
            </div>
          </div>
          <div class="flex gap-2 mt-4">
            <button class="btn btn-outline" style="flex:1; padding:0.45rem; font-size:0.85rem;" onclick="toggleFavoriteProperty(${prop.id})">${appState.favoritePropertyIds.has(prop.id) ? '已收藏' : '收藏'}</button>
            <button class="btn btn-primary" style="flex:1; padding:0.45rem; font-size:0.85rem;" onclick="prepareContract(${prop.price}, ${prop.id})">簽約</button>
          </div>
        </div>
      </div>
    `;
  });
  container.innerHTML = html;
}

// --- Page 2: Landlord Upload Simulation ---
function simulateUpload() {
  const text = document.getElementById('dropzone-text');
  const dropzone = document.getElementById('dropzone');
  
  dropzone.style.borderColor = 'var(--morandi-sage)';
  dropzone.style.background = 'rgba(156, 175, 136, 0.1)';
  text.innerHTML = '✅ 檔案已成功載入：身分證正反面.pdf, 房屋權狀.pdf';
  
  document.getElementById('upload-status').style.display = 'block';
  uploadedLandlordDocs = true;
}

function simulateLandlordApproval() {
  if (!uploadedLandlordDocs) {
    simulateUpload();
  }
  const btn = document.getElementById('btn-landlord-submit');
  btn.innerText = '審核中...';
  btn.style.opacity = '0.7';
  
  setTimeout(() => {
    appState.studentLoggedIn = false;
    appState.landlordLoggedIn = true;
    navigateTo(7);
    btn.innerText = '提交並前往管理後台';
    btn.style.opacity = '1';
  }, 1000);
}

// --- Page 3: Map View & Filters ---
function handlePriceRangeInput(shouldFilter = true) {
  const maxInput = document.getElementById('filter-price-max');
  const maxLabel = document.getElementById('price-max-label');
  if (!maxInput) return;

  const max = Number(maxInput.value);
  maxLabel.innerText = max >= 35000 ? '$35,000+' : `$${max.toLocaleString()}`;
  if (shouldFilter) filterProperties();
}

function filterProperties() {
  const dist = document.getElementById('filter-district').value;
  const priceMax = Number(document.getElementById('filter-price-max').value);
  const type = document.getElementById('filter-type').value;
  const subsidyOnly = document.getElementById('filter-subsidy').checked;

  let filtered = window.mockData.properties;

  if (dist !== '全部') {
    filtered = filtered.filter(p => p.district === dist);
  }
  
  filtered = filtered.filter(p => p.price <= priceMax);
  
  if (type !== '全部' && type !== '套房') {
    filtered = filtered.filter(p => p.type === type);
  } else if (type === '套房') {
    filtered = filtered.filter(p => p.type === '套房');
  }

  if (subsidyOnly) {
    filtered = filtered.filter(p => p.subsidy === true);
  }

  document.getElementById('property-count').innerText = filtered.length;
  renderMapList(filtered);
  renderMapMarkers(filtered);
}

function renderMapList(properties) {
  const container = document.getElementById('map-property-list');
  if (!container) return;
  
  const displayProps = properties.slice(0, 15);
  let listHtml = '';
  
  if (properties.length === 0) {
    container.innerHTML = `<p style="text-align:center; color:#888; margin-top:2rem;">沒有符合條件的房源</p>`;
    return;
  }
  
  displayProps.forEach(prop => {
    const favoriteLabel = appState.favoritePropertyIds.has(prop.id) ? '取消收藏' : '收藏';
    const signButton = appState.signedContract
      ? `<button class="btn btn-outline" style="padding:0.25rem 0.5rem; font-size:0.8rem; margin-top:0.5rem; width:100%;" onclick="showAlreadySignedNotice()">已簽約，僅供瀏覽</button>`
      : `<button class="btn btn-primary" style="padding:0.25rem 0.5rem; font-size:0.8rem; margin-top:0.5rem; width:100%;" onclick="prepareContract(${prop.price}, ${prop.id})">立即簽約</button>`;
    listHtml += `
      <div class="glass-card mb-4" style="padding:1rem;">
        <div class="flex gap-4">
          <img src="${prop.images[0]}" style="width:80px; height:80px; object-fit:cover; border-radius:8px;">
          <div style="flex:1;">
            <h4 style="margin:0; font-size:1rem;">${prop.title}</h4>
            <div style="color:var(--morandi-sage); font-weight:700;">$${prop.price.toLocaleString()}</div>
            <p style="font-size:0.8rem; margin:0.25rem 0;">${prop.type} · ${prop.size} 坪</p>
            <div class="flex gap-2 mt-4">
              <button class="btn btn-outline" style="padding:0.25rem 0.5rem; font-size:0.8rem; flex:1;" onclick="viewPropertyDetail(${prop.id})">查看</button>
              <button class="btn btn-outline" style="padding:0.25rem 0.5rem; font-size:0.8rem; flex:1;" onclick="toggleFavoriteProperty(${prop.id})">${favoriteLabel}</button>
            </div>
            ${signButton}
          </div>
        </div>
      </div>
    `;
  });
  
  container.innerHTML = listHtml;
}

function renderMapMarkers(properties) {
  const layer = document.getElementById('map-markers-layer');
  if (!layer) return;
  
  let html = '';
  properties.forEach(prop => {
    html += `
      <div class="map-marker" style="top:${prop.mapY}%; left:${prop.mapX}%;" onclick="highlightProperty(${prop.id})">
        $${(prop.price/1000).toFixed(1)}k
      </div>
    `;
  });
  layer.innerHTML = html;
}

function highlightProperty(id) {
  const prop = window.mockData.properties.find(p => p.id === id);
  if(!prop) return;
  recordPropertyView(id);
  const favoriteLabel = appState.favoritePropertyIds.has(prop.id) ? '取消收藏' : '加入收藏';
  const signButton = appState.signedContract
    ? `<button class="btn btn-outline" style="padding:0.5rem; font-size:1rem; margin-top:1rem; width:100%;" onclick="showAlreadySignedNotice()">已簽約，僅供瀏覽</button>`
    : `<button class="btn btn-primary" style="padding:0.5rem; font-size:1rem; margin-top:1rem; width:100%;" onclick="prepareContract(${prop.price}, ${prop.id})">立即簽約</button>`;
  
  const container = document.getElementById('map-property-list');
  container.innerHTML = `
    <h4 style="color:var(--morandi-sage); margin-bottom:1rem;">您選中的房源：</h4>
    <div class="glass-card mb-4" style="padding:1rem; border:2px solid var(--morandi-sage);">
      <img src="${prop.images[0]}" style="width:100%; height:150px; object-fit:cover; border-radius:8px; margin-bottom:1rem;">
      <h4 style="margin:0; font-size:1.1rem;">${prop.title}</h4>
      <div style="color:var(--morandi-sage); font-weight:700; font-size:1.2rem;">$${prop.price.toLocaleString()}</div>
      <p style="font-size:0.9rem; margin:0.25rem 0;">${prop.address}</p>
      <p style="font-size:0.8rem; margin:0.25rem 0;">${prop.type} · ${prop.size} 坪</p>
      <p style="font-size:0.8rem; font-weight:bold;">AI 契合度: ${prop.aiMatch}%</p>
      <button class="btn btn-outline" style="padding:0.5rem; font-size:1rem; margin-top:1rem; width:100%;" onclick="toggleFavoriteProperty(${prop.id}); highlightProperty(${prop.id})">${favoriteLabel}</button>
      ${signButton}
    </div>
    <button class="btn btn-outline w-full" onclick="filterProperties()">返回過濾列表</button>
  `;
}

function checkRoommateTrigger(val) {
  if (val === '雅房') {
    if(confirm("尋找雅房？是否進入「AI 室友配對系統」尋找志同道合的室友？")) {
      navigateTo(4);
    }
  }
}

function prepareContract(price, propertyId) {
  if (!appState.studentLoggedIn) {
    pendingStudentAction = { type: 'contract', price, propertyId };
    navigateTo(1);
    return;
  }
  if (appState.signedContract) {
    showAlreadySignedNotice();
    return;
  }
  signedPropertyPrice = price;
  appState.studentLoggedIn = true;
  appState.signedProperty = window.mockData.properties.find(p => p.id === propertyId) || appState.signedProperty;
  recordPropertyView(propertyId);
  navigateTo(5);
}

function showAlreadySignedNotice() {
  openModal('已完成簽約', `
    <p>您目前已有生效租約，仍可繼續看房與尋找室友，但 Demo 模式不會重複建立第二份簽約。</p>
    <p>可回到「我的租屋生活」查看租金、報修與合約狀態。</p>
  `, `<button class="btn btn-primary" onclick="closeModal(); navigateTo(6);">前往我的租屋生活</button>`);
}

function viewPropertyDetail(propertyId) {
  const prop = getPropertyById(propertyId);
  if (!prop) return;
  recordPropertyView(propertyId);
  const favoriteLabel = appState.favoritePropertyIds.has(propertyId) ? '取消收藏' : '加入收藏';
  const signAction = appState.signedContract
    ? `<button class="btn btn-outline" onclick="showAlreadySignedNotice()">已簽約，僅供瀏覽</button>`
    : `<button class="btn btn-primary" onclick="closeModal(); prepareContract(${prop.price}, ${propertyId});">立即簽約</button>`;
  openModal('房源快速預覽', `
    <img src="${prop.images[0]}" style="width:100%; height:220px; object-fit:cover; border-radius:12px; margin-bottom:1rem;">
    <h3>${prop.title}</h3>
    <p>${prop.address}</p>
    <p><strong>月租金：</strong>$${prop.price.toLocaleString()} / <strong>坪數：</strong>${prop.size} 坪 / <strong>房型：</strong>${prop.type}</p>
    <p><strong>AI 契合度：</strong>${prop.aiMatch}% ${prop.subsidy ? ' / 可申請租補' : ' / 不可租補'}</p>
  `, `
    <button class="btn btn-outline" onclick="toggleFavoriteProperty(${propertyId}); closeModal();">${favoriteLabel}</button>
    ${signAction}
  `);
}

// Draggable Map Logic & Zoom with clamping
function initDraggableMap() {
  const mapContainerOuter = document.getElementById('map-container-outer');
  const map = document.getElementById('draggable-map');
  if(!map || !mapContainerOuter) return;

  const mapWidth = 2000;
  const mapHeight = 2000;
  let isDragging = false;
  let startX, startY, currentX = -100, currentY = -100; // initial offset
  
  function clampCoordinates() {
    const containerW = mapContainerOuter.offsetWidth;
    const containerH = mapContainerOuter.offsetHeight;
    
    const scaledW = mapWidth * currentZoom;
    const scaledH = mapHeight * currentZoom;
    
    // Min X/Y (furthest negative we can go without showing right/bottom edge)
    const minX = containerW - scaledW;
    const minY = containerH - scaledH;
    
    // Max X/Y (furthest positive we can go without showing left/top edge)
    const maxX = 0;
    const maxY = 0;
    
    // If scaled map is smaller than container, lock it to center (rare but possible if zoomed out too much)
    if (scaledW < containerW) {
      currentX = (containerW - scaledW) / 2;
    } else {
      if (currentX > maxX) currentX = maxX;
      if (currentX < minX) currentX = minX;
    }
    
    if (scaledH < containerH) {
      currentY = (containerH - scaledH) / 2;
    } else {
      if (currentY > maxY) currentY = maxY;
      if (currentY < minY) currentY = minY;
    }
  }
  
  function applyMapTransform() {
    clampCoordinates();
    map.style.transform = `translate(${currentX}px, ${currentY}px) scale(${currentZoom})`;
  }
  
  // Set initial position
  applyMapTransform();

  map.addEventListener('mousedown', (e) => {
    isDragging = true;
    startX = e.clientX - currentX;
    startY = e.clientY - currentY;
    map.style.cursor = 'grabbing';
    map.style.transition = 'none'; // disable transition while dragging for snappiness
  });

  window.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    e.preventDefault();
    currentX = e.clientX - startX;
    currentY = e.clientY - startY;
    applyMapTransform();
  });

  window.addEventListener('mouseup', () => {
    if(isDragging) {
      isDragging = false;
      map.style.cursor = 'grab';
      map.style.transition = 'transform 0.05s linear'; // restore
      applyMapTransform();
    }
  });
  
  // Wheel Zoom
  mapContainerOuter.addEventListener('wheel', (e) => {
    e.preventDefault();
    
    // Calculate mouse position relative to map before zooming
    const rect = mapContainerOuter.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    // Convert to relative map coordinates
    const mapMouseX = (mouseX - currentX) / currentZoom;
    const mapMouseY = (mouseY - currentY) / currentZoom;
    
    const oldZoom = currentZoom;
    if (e.deltaY < 0) {
      currentZoom *= 1.1; // zoom in
    } else {
      currentZoom *= 0.9; // zoom out
    }
    
    // clamp zoom
    if(currentZoom < 0.3) currentZoom = 0.3;
    if(currentZoom > 2.5) currentZoom = 2.5;
    
    // Adjust currentX and currentY so the point under the mouse stays under the mouse
    currentX = mouseX - (mapMouseX * currentZoom);
    currentY = mouseY - (mapMouseY * currentZoom);
    
    applyMapTransform();
  });
  
  // Expose zoom map function globally for buttons
  window.zoomMap = function(factor) {
    const containerW = mapContainerOuter.offsetWidth;
    const containerH = mapContainerOuter.offsetHeight;
    
    const centerX = containerW / 2;
    const centerY = containerH / 2;
    
    const mapCenterX = (centerX - currentX) / currentZoom;
    const mapCenterY = (centerY - currentY) / currentZoom;
    
    currentZoom *= factor;
    if(currentZoom < 0.3) currentZoom = 0.3;
    if(currentZoom > 2.5) currentZoom = 2.5;
    
    currentX = centerX - (mapCenterX * currentZoom);
    currentY = centerY - (mapCenterY * currentZoom);
    
    applyMapTransform();
  }
}

// --- Page 4: Roommate Matching ---
function resetRoommates() {
  // Optional UI reset logic when form changes
}

function renderRoommates() {
  document.getElementById('roommate-results-section').style.display = 'block';
  const container = document.getElementById('roommate-results');
  
  // Get form values
  const qSleep = parseInt(document.getElementById('rm-q1').value);
  const qPet = parseInt(document.getElementById('rm-q3').value);
  const qClean = parseInt(document.getElementById('rm-q4').value);
  const qCook = parseInt(document.getElementById('rm-q8').value);
  const qRent = parseInt(document.getElementById('rm-q10').value);
  
  // Calculate dynamic match
  const roommates = window.mockData.roommates;
  roommates.forEach(person => {
    let penalty = 0;
    penalty += Math.abs(person.traits.sleep - qSleep) * 8;
    penalty += Math.abs(person.traits.pet - qPet) * 10;
    penalty += Math.abs(person.traits.clean - qClean) * 8;
    penalty += Math.abs(person.traits.cook - qCook) * 5;
    penalty += Math.abs(person.traits.rent - qRent) * 5;
    
    let matchScore = 99 - penalty;
    // Introduce slight randomness for realism so it's not identical integers
    matchScore = Math.floor(matchScore - (Math.random() * 3));
    if(matchScore < 40) matchScore = 40 + Math.floor(Math.random() * 10);
    
    person.match = matchScore;
  });
  
  // Sort roommates by match descending and take top 3
  const sortedRoommates = [...roommates].sort((a, b) => b.match - a.match);
  const top3 = sortedRoommates.slice(0, 3);
  
  let html = '';
  top3.forEach(person => {
    html += `
      <div class="glass-card slide-up">
        <div class="flex items-center gap-4 mb-4">
          <img src="${person.img}" style="width:60px; height:60px; border-radius:50%; object-fit:cover;">
          <div>
            <h3 style="margin:0;">${person.name}</h3>
            <p style="font-size:0.8rem; margin:0;">${person.dept}</p>
          </div>
        </div>
        <div class="mb-2">
          <div class="flex justify-between" style="font-size:0.9rem;">
            <span>契合度</span>
            <span style="color:var(--morandi-sage); font-weight:600;">${person.match}%</span>
          </div>
          <div class="progress-bar-bg">
            <div class="progress-bar-fill" style="width: 0%;" data-target="${person.match}%"></div>
          </div>
        </div>
        <div class="flex gap-2 flex-wrap mt-4 mb-4">
          ${person.tags.map(t => `<span class="badge badge-secondary" style="font-size:0.7rem;">${t}</span>`).join('')}
        </div>
        <div class="flex gap-2">
          <button class="btn btn-primary" style="flex:1; padding:0.5rem;" onclick="alert('正在播號給 ${person.name}...')">電話</button>
          <button class="btn btn-outline" style="flex:1; padding:0.5rem;" onclick="alert('已發送 Email 邀請給 ${person.name}！')">Email</button>
        </div>
      </div>
    `;
  });
  
  container.innerHTML = html;
  
  setTimeout(() => {
    document.querySelectorAll('.progress-bar-fill').forEach(bar => {
      bar.style.width = bar.getAttribute('data-target');
    });
  }, 100);
  
  setTimeout(() => {
    document.getElementById('roommate-results-section').scrollIntoView({ behavior: 'smooth' });
  }, 200);
}

// --- Page 5: Contract ---
function signContract() {
  const cb = document.getElementById('contract-agree');
  if(!cb.checked) {
    alert("請先勾選同意契約條款！");
    return;
  }
  alert("合約簽署成功！正在為您跳轉至「我的租屋生活」...");
  appState.studentLoggedIn = true;
  appState.signedContract = true;
  if (!appState.signedProperty) {
    appState.signedProperty = {
      title: '平台精選物件',
      address: '台北市精華區',
      price: signedPropertyPrice
    };
  }
  appState.rentRecords.forEach(record => record.amount = signedPropertyPrice);
  appState.contractNotes.unshift({ date: getTodayString(), text: `簽署 ${appState.signedProperty.title}，月租金 $${signedPropertyPrice.toLocaleString()}。` });
  
  // Force update Page 6 DOM
  const rentTopCard = document.getElementById('student-top-rent-amount');
  if(rentTopCard) rentTopCard.innerText = `$${signedPropertyPrice.toLocaleString()}`;
  switchStudentTab('rent');
  
  navigateTo(6);
}

// --- Page 6: Student Dashboard ---
function switchStudentTab(tabName) {
  currentStudentTab = tabName;
  
  // Update pill styles
  const buttons = document.querySelectorAll('#student-tabs button');
  buttons.forEach(btn => btn.classList.remove('active'));
  const btnArray = Array.from(buttons);
  const tabNames = ['rent', 'repairs', 'contract'];
  const activeIndex = tabNames.indexOf(tabName);
  if(activeIndex >= 0) buttons[activeIndex].classList.add('active');
  
  // Render Data
  const container = document.getElementById('student-list-container');
  let html = '';
  
  if (tabName === 'rent') {
    html += `
      <div class="dashboard-actions">
        <button class="btn btn-primary" onclick="addRentRecord()">新增本月繳租紀錄</button>
        <button class="btn btn-outline" onclick="markLatestRentPaid()">將最新租金標為已繳清</button>
      </div>
    `;
    appState.rentRecords.forEach((item, index) => {
      html += `
        <div class="list-item">
          <div>
            <h4 style="margin:0;">月租金繳款</h4>
            <p style="margin:0; font-size:0.85rem; color:#666;">繳款日期：${item.date} / 方式：${item.method}</p>
          </div>
          <div class="flex items-center gap-4">
            <span style="font-weight:bold;">$${item.amount.toLocaleString()}</span>
            <span class="badge ${item.status === '待繳款' ? 'badge-warning' : ''}">${item.status}</span>
            <button class="btn btn-outline" style="padding:0.25rem 0.75rem; font-size:0.85rem;" onclick="toggleRentStatus(${index})">切換狀態</button>
          </div>
        </div>
      `;
    });
  } else if (tabName === 'repairs') {
    html += `
      <div class="dashboard-actions">
        <button class="btn btn-primary" onclick="focusRepairForm()">新增報修</button>
        <button class="btn btn-outline" onclick="advanceFirstRepair()">推進第一筆處理中報修</button>
      </div>
      <div class="repair-create-form" id="student-repair-form">
        <div class="input-group">
          <label>報修項目</label>
          <input type="text" id="student-repair-issue" placeholder="例如：浴室排水變慢">
        </div>
        <div class="input-group">
          <label>補充說明</label>
          <input type="text" id="student-repair-note" placeholder="例如：晚上洗澡後積水約 10 分鐘">
        </div>
        <button class="btn btn-primary" onclick="addRepairTicketFromForm()">送出報修</button>
      </div>
    `;
    appState.repairTickets.forEach((item, index) => {
      html += `
        <div class="list-item">
          <div>
            <h4 style="margin:0;">${item.issue}</h4>
            <p style="margin:0; font-size:0.85rem; color:#666;">回報日期：${item.date}</p>
            <div class="detail-note">${item.note || ''}</div>
          </div>
          <div class="flex items-center gap-4">
            <span class="badge ${item.class}">${item.status}</span>
            <button class="btn btn-outline" style="padding:0.25rem 0.75rem; font-size:0.85rem;" onclick="updateRepairTicket(${index})">更新</button>
          </div>
        </div>
      `;
    });
  } else if (tabName === 'contract') {
    const propertyName = appState.signedProperty ? appState.signedProperty.title : '尚未簽約物件';
    const propertyAddress = appState.signedProperty ? appState.signedProperty.address : '完成簽約後會顯示完整地址';
    const contractStatus = appState.signedContract ? '已生效' : '尚未簽署';
    html = `
      <div class="dashboard-actions">
        <button class="btn btn-primary" onclick="addContractNote()">新增合約備註</button>
        <button class="btn btn-outline" onclick="showContractSummary()">查看簽約摘要</button>
      </div>
      <div style="padding: 2rem;">
        <h3 class="mb-4">房屋租賃契約書 (${contractStatus})</h3>
        <div class="scrollable-text-box" style="height: 300px; overflow-y: auto; background: #FAFAF8; padding: 1.5rem; border: 1px solid rgba(0,0,0,0.1); border-radius: var(--border-radius-sm); line-height: 1.8;">
          <p><strong>立契約書人：</strong> 出租人 平台認證房東 (以下簡稱甲方)、承租人 學生 (以下簡稱乙方)</p>
          <p>茲為房屋租賃事宜，雙方同意訂立本契約，條款如下：</p>
          <br>
          <h4>第一條：租賃標的物</h4>
          <p>${propertyAddress} / ${propertyName}</p>
          <br>
          <h4>第二條：租賃期間</h4>
          <p>自民國 115 年 06 月 15 日起，至 116 年 06 月 14 日止，計一年。</p>
          <br>
          <h4>第三條：租金及押金</h4>
          <p>1. 租金 $${signedPropertyPrice.toLocaleString()} / 月。<br>2. 押金為兩個月租金，於簽約時一次付清。</p>
          <br>
          <h4>第四條：修繕責任</h4>
          <p>房屋因自然損耗產生之修繕由甲方負責。若因乙方人為破壞，則由乙方負擔修繕費用。</p>
          <br>
          <p class="text-center" style="color:var(--morandi-sage); font-weight:bold;">${appState.signedContract ? '已於本次 Demo 簽署生效' : '尚未簽署，請先完成房源簽約流程'}</p>
        </div>
        <h4 class="mt-6">合約互動備註</h4>
        ${appState.contractNotes.map(note => `<div class="list-item"><span>${note.date}</span><span style="font-size:0.9rem; color:#666;">${note.text}</span></div>`).join('')}
      </div>
    `;
  }
  
  container.innerHTML = html;
}

function addRentRecord() {
  appState.rentRecords.unshift({
    date: getTodayString(),
    status: '待繳款',
    amount: signedPropertyPrice,
    method: '待確認'
  });
  switchStudentTab('rent');
}

function markLatestRentPaid() {
  if (appState.rentRecords.length === 0) addRentRecord();
  appState.rentRecords[0].status = '已繳清';
  appState.rentRecords[0].method = '線上轉帳';
  switchStudentTab('rent');
}

function toggleRentStatus(index) {
  const record = appState.rentRecords[index];
  if (!record) return;
  record.status = record.status === '已繳清' ? '待繳款' : '已繳清';
  record.method = record.status === '已繳清' ? '線上轉帳' : '待確認';
  switchStudentTab('rent');
}

function focusRepairForm() {
  const input = document.getElementById('student-repair-issue');
  if (input) input.focus();
}

function addRepairTicketFromForm() {
  const issueInput = document.getElementById('student-repair-issue');
  const noteInput = document.getElementById('student-repair-note');
  const issue = issueInput ? issueInput.value.trim() : '';
  if (!issue) return;
  appState.repairTickets.unshift({
    date: getTodayString(),
    issue,
    status: '已送出',
    class: 'badge-warning',
    note: noteInput && noteInput.value.trim() ? noteInput.value.trim() : '等待房東確認'
  });
  if (issueInput) issueInput.value = '';
  if (noteInput) noteInput.value = '';
  switchStudentTab('repairs');
}

function updateRepairTicket(index) {
  const ticket = appState.repairTickets[index];
  if (!ticket) return;
  if (ticket.status === '已送出') {
    ticket.status = '處理中';
    ticket.note = '房東已收到並安排維修';
    ticket.class = 'badge-warning';
  } else if (ticket.status === '處理中') {
    ticket.status = '已結案';
    ticket.note = '租客確認問題已排除';
    ticket.class = 'badge-gray';
  } else {
    ticket.status = '已送出';
    ticket.note = '重新開啟報修單';
    ticket.class = 'badge-warning';
  }
  switchStudentTab('repairs');
}

function advanceFirstRepair() {
  const index = appState.repairTickets.findIndex(ticket => ticket.status !== '已結案');
  if (index >= 0) updateRepairTicket(index);
}

function addContractNote() {
  const text = prompt('新增合約備註', '已確認押金與租金金額。');
  if (!text) return;
  appState.contractNotes.unshift({ date: getTodayString(), text });
  switchStudentTab('contract');
}

function showContractSummary() {
  const propertyName = appState.signedProperty ? appState.signedProperty.title : '尚未簽約';
  openModal('簽約摘要', `
    <p><strong>簽約狀態：</strong>${appState.signedContract ? '已簽署' : '尚未簽署'}</p>
    <p><strong>房源：</strong>${propertyName}</p>
    <p><strong>月租金：</strong>$${signedPropertyPrice.toLocaleString()}</p>
    <p><strong>租約倒數：</strong>364 天</p>
  `);
}

// --- Page 8: Student Profile ---
const avatarGradients = [
  'linear-gradient(135deg,#9CAF88,#98A8B8)',
  'linear-gradient(135deg,#AFA3B0,#C4B5C7)',
  'linear-gradient(135deg,#98A8B8,#9CAF88)',
  'linear-gradient(135deg,#B8C5AA,#AFA3B0)'
];

function syncProfileInputsFromLogin() {
  const registerName = document.getElementById('student-register-name')?.value.trim();
  const loginId = document.getElementById('student-login-id')?.value.trim();
  if (registerName) appState.profile.name = registerName;
  if (loginId) appState.profile.email = `${loginId}@mail.ntut.edu.tw`;
}

function renderProfilePage() {
  const page = document.getElementById('page-8');
  if (!page) return;
  const profile = appState.profile;
  const nameInput = document.getElementById('profile-name');
  const phoneInput = document.getElementById('profile-phone');
  const emailInput = document.getElementById('profile-email');
  const deptInput = document.getElementById('profile-dept');
  if (nameInput && document.activeElement !== nameInput) nameInput.value = profile.name;
  if (phoneInput && document.activeElement !== phoneInput) phoneInput.value = profile.phone;
  if (emailInput && document.activeElement !== emailInput) emailInput.value = profile.email;
  if (deptInput && document.activeElement !== deptInput) deptInput.value = profile.dept;
  syncProfileAvatar();
  renderPropertyMiniList('profile-favorites', Array.from(appState.favoritePropertyIds), '尚未收藏房源。可在地圖找房或推薦卡片中加入收藏。', true);
  renderPropertyMiniList('profile-recent', appState.recentPropertyIds, '尚未瀏覽房源。點擊房源查看後會出現在這裡。', false);
  renderProfileRecommendations();
}

function syncProfileAvatar() {
  const preview = document.getElementById('profile-avatar-preview');
  const name = document.getElementById('profile-name')?.value || appState.profile.name || '?';
  if (!preview) return;
  preview.innerText = name.trim().charAt(0) || '?';
  preview.style.background = avatarGradients[appState.profile.avatarColor] || avatarGradients[0];
  document.querySelectorAll('.avatar-swatches button').forEach((btn, index) => {
    btn.classList.toggle('active', index === appState.profile.avatarColor);
  });
}

function selectAvatarColor(index) {
  appState.profile.avatarColor = index;
  syncProfileAvatar();
}

function simulateAvatarUpload() {
  openModal('上傳圖片', '<p>Demo 模式已模擬上傳完成。您可以使用色票切換頭像視覺。</p>');
}

function saveProfileChanges() {
  appState.profile.name = document.getElementById('profile-name').value.trim() || appState.profile.name;
  appState.profile.phone = document.getElementById('profile-phone').value.trim();
  appState.profile.email = document.getElementById('profile-email').value.trim();
  appState.profile.dept = document.getElementById('profile-dept').value.trim();
  const saveText = document.getElementById('profile-save-text');
  if (saveText) {
    saveText.innerText = '已儲存！';
    setTimeout(() => saveText.innerText = '儲存變更', 1200);
  }
  syncProfileAvatar();
}

function renderPropertyMiniList(containerId, ids, emptyText, allowRemove) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const props = ids.map(getPropertyById).filter(Boolean);
  if (props.length === 0) {
    container.innerHTML = `<div class="profile-empty">${emptyText}</div>`;
    return;
  }
  container.innerHTML = props.map(prop => `
    <div class="profile-property-mini">
      <img src="${prop.images[0]}" alt="${prop.title}">
      <div>
        <h4>${prop.title}</h4>
        <p>$${prop.price.toLocaleString()} / ${prop.type} / ${prop.size} 坪</p>
        <div class="profile-mini-actions">
          <button class="btn btn-outline" onclick="viewPropertyDetail(${prop.id})">查看</button>
          ${allowRemove
            ? `<button class="btn btn-outline" onclick="toggleFavoriteProperty(${prop.id})">移除收藏</button>`
            : `<button class="btn btn-outline" onclick="toggleFavoriteProperty(${prop.id})">${appState.favoritePropertyIds.has(prop.id) ? '已收藏' : '收藏'}</button>`}
          <button class="btn btn-primary" onclick="prepareContract(${prop.price}, ${prop.id})">簽約</button>
        </div>
      </div>
    </div>
  `).join('');
}

function renderProfileRecommendations() {
  const container = document.getElementById('profile-recommendations');
  if (!container || !window.mockData?.properties) return;
  const excluded = new Set([...appState.favoritePropertyIds, ...appState.recentPropertyIds]);
  const recommendations = window.mockData.properties
    .filter(prop => !excluded.has(prop.id))
    .sort((a, b) => b.aiMatch - a.aiMatch)
    .slice(0, 3);
  container.innerHTML = recommendations.map(prop => `
    <div class="profile-recommend-card">
      <img src="${prop.images[0]}" alt="${prop.title}">
      <div class="content">
        <div class="flex justify-between items-center gap-2">
          <h4 style="margin:0;">${prop.title}</h4>
          <span class="badge">${prop.aiMatch}%</span>
        </div>
        <p style="font-size:0.85rem; margin:0.45rem 0;">$${prop.price.toLocaleString()} / ${prop.type} / ${prop.district}</p>
        <div class="profile-mini-actions">
          <button class="btn btn-outline" onclick="viewPropertyDetail(${prop.id})">查看</button>
          <button class="btn btn-primary" onclick="toggleFavoriteProperty(${prop.id})">收藏</button>
        </div>
      </div>
    </div>
  `).join('');
}

// --- Page 7: Landlord Dashboard ---
function switchLandlordTab(tabName) {
  currentLandlordTab = tabName;
  
  // Update pill styles
  const buttons = document.querySelectorAll('#landlord-tabs button');
  buttons.forEach(btn => btn.classList.remove('active'));
  const btnArray = Array.from(buttons);
  const tabNames = ['properties', 'tenants', 'contracts', 'payments', 'repairs'];
  const activeIndex = tabNames.indexOf(tabName);
  if(activeIndex >= 0) buttons[activeIndex].classList.add('active');
  
  // Render Data
  const container = document.getElementById('landlord-list-container');
  const data = window.mockData.landlord[tabName];
  let html = '';
  const tabLabels = {
    properties: '物件',
    tenants: '租客履歷',
    contracts: '合約',
    payments: '租金紀錄',
    repairs: '修繕請求'
  };
  const plusIcon = `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 5v14"></path><path d="M5 12h14"></path></svg>`;
  html += `
    <div class="dashboard-actions">
      <button class="btn btn-primary" onclick="addLandlordItem('${tabName}')">${plusIcon}<span>新增${tabLabels[tabName]}</span></button>
      <button class="btn btn-outline" onclick="showLandlordTabSummary('${tabName}')">查看本頁統計</button>
    </div>
  `;
  
  const iconSvg = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--morandi-charcoal)" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>`;
  
  data.forEach((item, i) => {
    let mainTitle = '';
    let subTitle = '';
    let statusBadge = '';
    let infoStr = '';
    
    if (tabName === 'properties') {
      mainTitle = `物件 ${String.fromCharCode(65 + i)}： ${item.name}`;
      subTitle = item.address;
      statusBadge = item.status === "出租中" ? `<span class="badge">出租中</span>` : `<span class="badge badge-gray">${item.status}</span>`;
      infoStr = `資訊欄：月租金 $${item.price.toLocaleString()} ` + (item.tenant ? `/ 當前租客 ${item.tenant}` : '') + (item.nextDate ? ` / 下次收租 ${item.nextDate}` : '');
    } else if (tabName === 'tenants') {
      mainTitle = `租客履歷： ${item.name}`;
      subTitle = `申請物件：${item.target}`;
      statusBadge = item.status === '審核通過' ? `<span class="badge">審核通過</span>` : `<span class="badge badge-warning">${item.status}</span>`;
      infoStr = `申請日期：${item.date}`;
    } else if (tabName === 'contracts') {
      mainTitle = `合約： ${item.tenant}`;
      subTitle = `租賃標的：${item.target}`;
      statusBadge = item.status === '生效中' ? `<span class="badge">生效中</span>` : `<span class="badge badge-warning">${item.status}</span>`;
      infoStr = `合約到期日：${item.endDate}`;
    } else if (tabName === 'payments') {
      mainTitle = `租金催收： ${item.tenant}`;
      subTitle = `租賃標的：${item.target}`;
      statusBadge = item.status === '已繳清' ? `<span class="badge">已繳清</span>` : `<span class="badge badge-warning">${item.status}</span>`;
      infoStr = `應繳金額：$${item.amount.toLocaleString()} / 繳款期限：${item.dueDate}`;
    } else if (tabName === 'repairs') {
      mainTitle = `修繕請求： ${item.issue}`;
      subTitle = `物件：${item.target}`;
      statusBadge = item.status === '已完成' || item.status === '已結案' ? `<span class="badge badge-gray">${item.status}</span>` : `<span class="badge badge-warning">${item.status}</span>`;
      infoStr = `回報日期：${item.date}` + (item.note ? ` / 備註：${item.note}` : '');
    }
    const noteKey = `${tabName}-${i}`;
    const note = appState.landlordNotes[noteKey] ? `<div class="detail-note">${appState.landlordNotes[noteKey]}</div>` : '';
    const mediaHtml = item.photo
      ? `<img src="${item.photo}" style="width:56px; height:56px; object-fit:cover; border-radius:50%; box-shadow:0 4px 12px rgba(0,0,0,0.12);">`
      : iconSvg;

    html += `
      <div class="list-item">
        <div class="flex items-center gap-4" style="flex:1;">
          <div style="background:var(--morandi-grey-taupe); padding:1rem; border-radius:50%; display:flex; align-items:center; justify-content:center;">
            ${mediaHtml}
          </div>
          <div>
            <div class="flex items-center gap-2 mb-1">
              <h4 style="margin:0; font-size:1rem;">${mainTitle} <span style="font-size:0.8rem; font-weight:normal; color:#666;">(${subTitle})</span></h4>
            </div>
            <div class="flex items-center gap-2 mt-2">
              ${statusBadge}
              <span style="font-size:0.85rem; color:#666;">${infoStr}</span>
            </div>
            ${note}
          </div>
        </div>
        <button class="btn btn-outline" style="padding:0.25rem 0.75rem; font-size:0.85rem;" onclick="manageLandlordItem('${tabName}', ${i})">管理 / 查看</button>
      </div>
      ${tabName === 'repairs' ? renderLandlordRepairControls(i, item) : ''}
    `;
  });
  if (data.length === 0) {
    html += `<div class="list-item"><p style="margin:0;">目前沒有資料，可點擊上方新增。</p></div>`;
  }
  
  container.innerHTML = html;
}

function addLandlordItem(tabName) {
  const data = window.mockData.landlord[tabName];
  const today = getTodayString();
  if (tabName === 'properties') {
    openLandlordPropertyForm();
  } else if (tabName === 'tenants') {
    openLandlordTenantForm();
  } else if (tabName === 'contracts') {
    data.unshift({ target: '北科旁機能套房', tenant: '王同學', endDate: '2027-06-15', status: '草稿' });
  } else if (tabName === 'payments') {
    data.unshift({ target: '北科旁機能套房', tenant: '王同學', amount: 16800, dueDate: today, status: '待催收' });
  } else if (tabName === 'repairs') {
    data.unshift({ target: '北科旁機能套房', issue: '門鎖鬆動', date: today, status: '待處理', note: '' });
  }
  if (!['properties', 'tenants'].includes(tabName)) switchLandlordTab(tabName);
}

function openLandlordPropertyForm() {
  openModal('新增出租物件', `
    <div class="modal-form-grid">
      <div class="input-group">
        <label>物件名稱</label>
        <input id="ll-property-name" type="text" value="北科旁機能套房">
      </div>
      <div class="input-group">
        <label>地址</label>
        <input id="ll-property-address" type="text" value="台北市大安區復興南路一段">
      </div>
      <div class="input-group">
        <label>月租金</label>
        <input id="ll-property-price" type="number" value="16800">
      </div>
      <div class="input-group">
        <label>出租狀態</label>
        <select id="ll-property-status">
          <option value="空置中">空置中</option>
          <option value="待簽約">待簽約</option>
          <option value="出租中">出租中</option>
        </select>
      </div>
      <div class="input-group">
        <label>房源照片</label>
        <input id="ll-property-photo" type="file" accept="image/*" onchange="previewLandlordFileName('ll-property-photo', 'll-property-photo-name')">
        <p id="ll-property-photo-name" class="detail-note">尚未選擇照片，送出後會使用 Demo 預設照片。</p>
      </div>
    </div>
  `, `
    <button class="btn btn-primary" onclick="submitLandlordPropertyForm()">新增物件</button>
  `);
}

function submitLandlordPropertyForm() {
  const name = document.getElementById('ll-property-name').value.trim() || '未命名物件';
  const address = document.getElementById('ll-property-address').value.trim() || '未填寫地址';
  const price = Number(document.getElementById('ll-property-price').value) || 0;
  const status = document.getElementById('ll-property-status').value;
  window.mockData.landlord.properties.unshift({
    id: Date.now(),
    name,
    address,
    status,
    price,
    tenant: null,
    nextDate: status === '出租中' ? '2026-07-05' : null,
    photo: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=600&fit=crop'
  });
  closeModal();
  switchLandlordTab('properties');
}

function openLandlordTenantForm() {
  const propertyOptions = window.mockData.landlord.properties
    .map(property => `<option value="${property.name}">${property.name}</option>`)
    .join('');
  openModal('新增房客履歷', `
    <div class="modal-form-grid">
      <div class="input-group">
        <label>房客姓名</label>
        <input id="ll-tenant-name" type="text" value="王同學">
      </div>
      <div class="input-group">
        <label>申請物件</label>
        <select id="ll-tenant-target">${propertyOptions}</select>
      </div>
      <div class="input-group">
        <label>審核狀態</label>
        <select id="ll-tenant-status">
          <option value="審核中">審核中</option>
          <option value="審核通過">審核通過</option>
        </select>
      </div>
      <div class="input-group">
        <label>房客照片</label>
        <input id="ll-tenant-photo" type="file" accept="image/*" onchange="previewLandlordFileName('ll-tenant-photo', 'll-tenant-photo-name')">
        <p id="ll-tenant-photo-name" class="detail-note">尚未選擇照片，送出後會使用 Demo 預設頭像。</p>
      </div>
    </div>
  `, `
    <button class="btn btn-primary" onclick="submitLandlordTenantForm()">新增房客</button>
  `);
}

function submitLandlordTenantForm() {
  const name = document.getElementById('ll-tenant-name').value.trim() || '未命名房客';
  const target = document.getElementById('ll-tenant-target').value;
  const status = document.getElementById('ll-tenant-status').value;
  const item = {
    name,
    target,
    status,
    date: getTodayString(),
    photo: 'https://i.pravatar.cc/150?img=32'
  };
  window.mockData.landlord.tenants.unshift(item);
  syncLandlordStatus('tenants', item);
  closeModal();
  switchLandlordTab('tenants');
}

function previewLandlordFileName(inputId, targetId) {
  const input = document.getElementById(inputId);
  const target = document.getElementById(targetId);
  if (input && target && input.files && input.files[0]) {
    target.innerText = `已選擇：${input.files[0].name}`;
  }
}

function renderLandlordRepairControls(index, item) {
  const statuses = ['待處理', '已聯絡', '處理中', '已完成'];
  return `
    <div class="repair-note-box">
      <div class="repair-status-actions">
        ${statuses.map(status => `
          <button class="btn ${item.status === status ? 'btn-primary' : 'btn-outline'}" onclick="setLandlordRepairStatus(${index}, '${status}')">${status}</button>
        `).join('')}
      </div>
      <div class="input-group">
        <label>房東修繕備註</label>
        <textarea id="landlord-repair-note-${index}" placeholder="例如：已聯絡水電師傅，預計週五下午到場。">${item.note || ''}</textarea>
      </div>
      <div>
        <button class="btn btn-outline" onclick="saveLandlordRepairNote(${index})">儲存備註</button>
      </div>
    </div>
  `;
}

function setLandlordRepairStatus(index, status) {
  const item = window.mockData.landlord.repairs[index];
  if (!item) return;
  item.status = status;
  syncLandlordStatus('repairs', item);
  switchLandlordTab('repairs');
}

function saveLandlordRepairNote(index) {
  const item = window.mockData.landlord.repairs[index];
  const input = document.getElementById(`landlord-repair-note-${index}`);
  if (!item || !input) return;
  item.note = input.value.trim();
  syncLandlordStatus('repairs', item);
  switchLandlordTab('repairs');
}

function showLandlordTabSummary(tabName) {
  const data = window.mockData.landlord[tabName];
  const pendingCount = data.filter(item => {
    const status = item.status || item.paymentStatus || '';
    return status.includes('待') || status.includes('處理中') || status.includes('逾期') || status.includes('審核中');
  }).length;
  openModal('本頁統計', `
    <p><strong>資料類型：</strong>${tabName}</p>
    <p><strong>總筆數：</strong>${data.length}</p>
    <p><strong>需注意筆數：</strong>${pendingCount}</p>
  `);
}

function manageLandlordItem(tabName, index) {
  const item = window.mockData.landlord[tabName][index];
  if (!item) return;
  const noteKey = `${tabName}-${index}`;
  const detailHtml = Object.entries(item).map(([key, value]) => {
    const shownValue = value === null ? '無' : value;
    return `<p><strong>${key}：</strong>${shownValue}</p>`;
  }).join('') + (appState.landlordNotes[noteKey] ? `<p><strong>管理備註：</strong>${appState.landlordNotes[noteKey]}</p>` : '');
  openModal('管理 / 查看', detailHtml, `
    <button class="btn btn-primary" onclick="updateLandlordItemStatus('${tabName}', ${index})">推進狀態</button>
    <button class="btn btn-outline" onclick="addLandlordItemNote('${tabName}', ${index})">新增備註</button>
  `);
}

function updateLandlordItemStatus(tabName, index) {
  const item = window.mockData.landlord[tabName][index];
  if (!item) return;
  if (tabName === 'properties') {
    item.status = item.status === '出租中' ? '空置中' : '出租中';
    item.nextDate = item.status === '出租中' ? '2026-07-05' : null;
  } else if (tabName === 'tenants') {
    item.status = item.status === '審核通過' ? '審核中' : '審核通過';
  } else if (tabName === 'contracts') {
    item.status = item.status === '生效中' ? '待簽署' : '生效中';
  } else if (tabName === 'payments') {
    item.status = item.status === '已繳清' ? '逾期未繳' : '已繳清';
  } else if (tabName === 'repairs') {
    const statuses = ['待處理', '已聯絡', '處理中', '已完成'];
    const currentIndex = statuses.indexOf(item.status);
    item.status = statuses[(currentIndex + 1) % statuses.length];
  } else if (tabName === 'taxes') {
    item.status = item.status && item.status.includes('符合') ? '審核中' : '符合公益出租';
    item.savedTax = item.status.includes('符合') ? 14400 : 0;
  }
  syncLandlordStatus(tabName, item);
  closeModal();
  switchLandlordTab(tabName);
}

function syncLandlordStatus(tabName, item) {
  const landlord = window.mockData.landlord;
  const targetName = item.name || item.target;
  const tenantName = item.tenant || item.name;

  if (tabName === 'properties') {
    const isRented = item.status === '出租中';
    landlord.contracts
      .filter(contract => contract.target === item.name)
      .forEach(contract => contract.status = isRented ? '生效中' : '待簽署');
    landlord.payments
      .filter(payment => payment.target === item.name)
      .forEach(payment => payment.status = isRented ? '已繳清' : '待催收');
    landlord.tenants
      .filter(tenant => tenant.target === item.name)
      .forEach(tenant => tenant.status = isRented ? '審核通過' : '審核中');
    landlord.taxes
      .filter(tax => tax.target === item.name)
      .forEach(tax => {
        tax.status = isRented ? '符合公益出租' : '審核中';
        tax.savedTax = isRented ? 14400 : 0;
      });
  }

  if (tabName === 'tenants') {
    const approved = item.status === '審核通過';
    landlord.properties
      .filter(property => property.name === item.target)
      .forEach(property => {
        property.status = approved ? '出租中' : '待簽約';
        property.tenant = approved ? item.name : property.tenant;
        property.nextDate = approved ? '2026-07-05' : null;
      });
    landlord.contracts
      .filter(contract => contract.target === item.target || contract.tenant === item.name)
      .forEach(contract => contract.status = approved ? '生效中' : '待簽署');
  }

  if (tabName === 'contracts') {
    const active = item.status === '生效中';
    landlord.properties
      .filter(property => property.name === item.target)
      .forEach(property => {
        property.status = active ? '出租中' : '待簽約';
        property.tenant = item.tenant;
        property.nextDate = active ? '2026-07-05' : null;
      });
    landlord.tenants
      .filter(tenant => tenant.name === item.tenant || tenant.target === item.target)
      .forEach(tenant => tenant.status = active ? '審核通過' : '審核中');
    landlord.payments
      .filter(payment => payment.target === item.target || payment.tenant === item.tenant)
      .forEach(payment => payment.status = active ? '已繳清' : '待催收');
  }

  if (tabName === 'payments') {
    landlord.properties
      .filter(property => property.name === item.target)
      .forEach(property => {
        property.nextDate = item.status === '已繳清' ? '2026-07-05' : '逾期提醒中';
      });
  }

  if (tabName === 'repairs') {
    landlord.properties
      .filter(property => property.name === item.target)
      .forEach(property => {
        appState.landlordNotes[`properties-${landlord.properties.indexOf(property)}`] = `最新修繕：${item.issue} / ${item.status}${item.note ? ` / ${item.note}` : ''}`;
      });
  }

}

function addLandlordItemNote(tabName, index) {
  const note = prompt('請輸入管理備註', '已電話聯繫確認。');
  if (!note) return;
  appState.landlordNotes[`${tabName}-${index}`] = note;
  closeModal();
  switchLandlordTab(tabName);
}
