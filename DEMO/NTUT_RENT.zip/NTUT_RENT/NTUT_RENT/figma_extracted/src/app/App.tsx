import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Home, Map, Building2, Menu, X, BadgeCheck, LogOut, User, ChevronDown } from 'lucide-react';
import { Toaster } from 'sonner';
import { properties, tenantProfiles, contracts, rentPayments, maintenanceRequests, taxBenefits, mrtStations } from '../mockData';
import LandingPage from './components/LandingPage';
import RenterMapView from './components/RenterMapView';
import LandlordDashboard from './components/LandlordDashboard';
import AgencyDashboard from './components/AgencyDashboard';
import TenantDashboard from './components/TenantDashboard';
import AuthPage from './components/AuthPage';
import ProfileEditPage from './components/ProfileEditPage';

type View = 'landing' | 'renter' | 'landlord' | 'agency' | 'tenant-dashboard';
type UserRole = 'tenant' | 'landlord' | 'agent' | null;

interface UserData {
  name: string;
  email: string;
  role: UserRole;
  verified: boolean;
}

// Lime-green accent color per spec
const LIME = '#a3e635';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('landing');
  const [menuOpen, setMenuOpen] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [startOnRegister, setStartOnRegister] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [user, setUser] = useState<UserData | null>(null);
  const [avatarMenuOpen, setAvatarMenuOpen] = useState(false);

  const handleAuthSuccess = (_role: UserRole, userData: UserData) => {
    setUser(userData);
    setShowAuth(false);
    if (userData.role === 'tenant') setCurrentView('tenant-dashboard');
    else if (userData.role === 'landlord') setCurrentView('landlord');
    else if (userData.role === 'agent') setCurrentView('agency');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('landing');
    setShowProfile(false);
    setAvatarMenuOpen(false);
  };

  const openRegister = () => { setStartOnRegister(true); setShowAuth(true); setMenuOpen(false); };
  const openLogin    = () => { setStartOnRegister(false); setShowAuth(true); setMenuOpen(false); };

  if (showAuth) return (
    <>
      <Toaster richColors position="top-center" />
      <AuthPage onAuthSuccess={handleAuthSuccess} startOnRegister={startOnRegister} />
    </>
  );

  if (showProfile && user) return (
    <ProfileEditPage
      user={user}
      onBack={() => setShowProfile(false)}
      onSave={updated => { setUser(u => u ? { ...u, ...updated } : u); setShowProfile(false); }}
    />
  );

  // ── Dynamic nav items per role ──────────────────────────────────────────
  const navItems = () => {
    if (!user) return [
      { label: '首頁', view: 'landing' as View, icon: Home },
    ];
    if (user.role === 'tenant') return [
      { label: '首頁',     view: 'landing' as View,           icon: Home },
      { label: '找房地圖', view: 'renter' as View,            icon: Map },
      { label: '房客後台', view: 'tenant-dashboard' as View,  icon: User },
    ];
    if (user.role === 'landlord') return [
      { label: '首頁',     view: 'landing' as View,   icon: Home },
      { label: '房東後台', view: 'landlord' as View,  icon: Building2 },
    ];
    if (user.role === 'agent') return [
      { label: '首頁',     view: 'landing' as View,  icon: Home },
      { label: '業者後台', view: 'agency' as View,   icon: Building2 },
    ];
    return [{ label: '首頁', view: 'landing' as View, icon: Home }];
  };

  return (
    <div className="size-full flex flex-col overflow-hidden" style={{ background: '#0f1117' }}>
      {/* MARKER-MAKE-KIT-INVOKED */}
      <Toaster richColors position="top-center" />

      {/* ── Dark Navigation Bar ─────────────────────────────────────────── */}
      <header
        className="sticky top-0 z-50 border-b"
        style={{ background: 'rgba(15,17,23,0.96)', backdropFilter: 'blur(16px)', borderColor: 'rgba(255,255,255,0.07)' }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">

            {/* Logo */}
            <button
              className="flex items-center gap-3 group"
              onClick={() => setCurrentView('landing')}
            >
              <div className="w-9 h-9 rounded-xl flex items-center justify-center shadow-lg"
                style={{ background: `linear-gradient(135deg, ${LIME}, #65a30d)` }}>
                <Home className="w-5 h-5 text-black" />
              </div>
              <div className="text-left">
                <p className="text-sm font-bold text-white leading-none tracking-wide">棲居</p>
                <p className="text-[9px] leading-none mt-0.5" style={{ color: LIME }}>Habitat</p>
              </div>
            </button>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems().map(item => (
                <NavBtn key={item.view} active={currentView === item.view}
                  onClick={() => setCurrentView(item.view)} icon={item.icon} label={item.label} lime={LIME} />
              ))}
            </nav>

            {/* Right: auth area */}
            <div className="hidden md:flex items-center gap-2">
              {user ? (
                <div className="relative">
                  <button
                    onClick={() => setAvatarMenuOpen(o => !o)}
                    className="flex items-center gap-2.5 px-3.5 py-2 rounded-xl border transition-all"
                    style={{ background: 'rgba(255,255,255,0.06)', borderColor: 'rgba(255,255,255,0.1)' }}
                  >
                    <div className="w-7 h-7 rounded-full flex items-center justify-center text-black text-xs font-bold"
                      style={{ background: LIME }}>
                      {user.name[0]}
                    </div>
                    <span className="text-sm text-white font-medium">{user.name}</span>
                    {user.verified && <BadgeCheck className="w-4 h-4" style={{ color: LIME }} />}
                    <ChevronDown className="w-3.5 h-3.5 text-white opacity-40" />
                  </button>

                  <AnimatePresence>
                    {avatarMenuOpen && (
                      <motion.div
                        initial={{ opacity: 0, y: -8, scale: 0.96 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -8, scale: 0.96 }}
                        className="absolute right-0 top-full mt-2 w-44 rounded-2xl border shadow-2xl overflow-hidden z-50"
                        style={{ background: '#1a1d27', borderColor: 'rgba(255,255,255,0.1)' }}
                      >
                        <button onClick={() => { setShowProfile(true); setAvatarMenuOpen(false); }}
                          className="w-full text-left px-4 py-3 text-sm text-white hover:bg-white/5 transition-colors flex items-center gap-2">
                          <User className="w-4 h-4 opacity-60" /> 修改個人資訊
                        </button>
                        <div style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }} />
                        <button onClick={handleLogout}
                          className="w-full text-left px-4 py-3 text-sm flex items-center gap-2 hover:bg-white/5 transition-colors"
                          style={{ color: '#f87171' }}>
                          <LogOut className="w-4 h-4" /> 登出
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <button onClick={openLogin}
                    className="px-4 py-2 rounded-lg text-sm text-white/70 hover:text-white hover:bg-white/5 transition-all">
                    登入
                  </button>
                  <button onClick={openRegister}
                    className="px-4 py-2 rounded-lg text-sm font-semibold text-black transition-all hover:opacity-90 shadow-lg"
                    style={{ background: LIME }}>
                    免費註冊
                  </button>
                </div>
              )}
            </div>

            {/* Mobile hamburger */}
            <button className="md:hidden p-2 rounded-lg text-white hover:bg-white/10 transition-colors"
              onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

          {/* Mobile menu */}
          <AnimatePresence>
            {menuOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="md:hidden overflow-hidden"
                style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}
              >
                <div className="py-3 space-y-1">
                  {navItems().map(item => (
                    <button key={item.view}
                      onClick={() => { setCurrentView(item.view); setMenuOpen(false); }}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-all"
                      style={currentView === item.view
                        ? { background: `${LIME}22`, color: LIME }
                        : { color: 'rgba(255,255,255,0.7)' }}>
                      <item.icon className="w-4 h-4" />
                      {item.label}
                    </button>
                  ))}
                  <div className="pt-3 pb-1 px-1 flex gap-2" style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}>
                    {user ? (
                      <>
                        <button onClick={() => { setShowProfile(true); setMenuOpen(false); }}
                          className="flex-1 py-2.5 rounded-lg text-sm text-white border border-white/10 text-center">
                          修改資訊
                        </button>
                        <button onClick={() => { handleLogout(); setMenuOpen(false); }}
                          className="px-4 py-2.5 rounded-lg text-sm border border-white/10 text-red-400">
                          登出
                        </button>
                      </>
                    ) : (
                      <>
                        <button onClick={openLogin} className="flex-1 py-2.5 rounded-lg text-sm text-white border border-white/10 text-center">登入</button>
                        <button onClick={openRegister} className="flex-1 py-2.5 rounded-lg text-sm font-semibold text-black text-center" style={{ background: LIME }}>免費註冊</button>
                      </>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>

      {/* ── Main Content ──────────────────────────────────────────────────── */}
      <main className="flex-1 overflow-auto" style={{ background: 'var(--morandi-warm-white)' }}>
        {currentView === 'landing' && <LandingPage onNavigate={v => setCurrentView(v as View)} />}
        {currentView === 'renter' && <RenterMapView properties={properties} mrtStations={mrtStations} />}
        {currentView === 'tenant-dashboard' && <TenantDashboard onSwitchToSearch={() => setCurrentView('renter')} />}
        {currentView === 'landlord' && (
          <LandlordDashboard
            tenantProfiles={tenantProfiles} contracts={contracts}
            rentPayments={rentPayments} maintenanceRequests={maintenanceRequests}
            taxBenefits={taxBenefits}
          />
        )}
        {currentView === 'agency' && (
          <AgencyDashboard
            tenantProfiles={tenantProfiles} contracts={contracts}
            rentPayments={rentPayments} maintenanceRequests={maintenanceRequests}
            taxBenefits={taxBenefits}
          />
        )}
      </main>

      {/* close avatar menu on outside click */}
      {avatarMenuOpen && (
        <div className="fixed inset-0 z-40" onClick={() => setAvatarMenuOpen(false)} />
      )}
    </div>
  );
}

function NavBtn({ active, onClick, icon: Icon, label, lime }: {
  active: boolean; onClick: () => void;
  icon: React.ComponentType<{ className?: string }>;
  label: string; lime: string;
}) {
  return (
    <button onClick={onClick}
      className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200"
      style={active
        ? { background: `${lime}22`, color: lime, outline: `1px solid ${lime}44` }
        : { color: 'rgba(255,255,255,0.6)' }}
      onMouseEnter={e => { if (!active) (e.currentTarget as HTMLElement).style.color = '#fff'; }}
      onMouseLeave={e => { if (!active) (e.currentTarget as HTMLElement).style.color = 'rgba(255,255,255,0.6)'; }}
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  );
}
