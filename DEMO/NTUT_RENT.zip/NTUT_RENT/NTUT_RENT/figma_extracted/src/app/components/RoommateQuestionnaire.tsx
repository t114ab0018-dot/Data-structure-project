import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Users, CheckCircle2, ChevronRight, Heart } from 'lucide-react';

interface RoommateQuestionnaireProps {
  onClose: () => void;
}

const LIME = '#a3e635';

const QUESTIONS = [
  {
    key: 'schedule',
    label: '生活作息',
    options: ['早起型 (Early Bird)', '夜貓型 (Night Owl)', '不限制'],
  },
  {
    key: 'hygiene',
    label: '公共衛生習慣',
    options: ['每日打掃', '每週打掃', '垃圾不落地'],
  },
  {
    key: 'guests',
    label: '訪客限制',
    options: ['完全不可帶人', '僅限同性', '提前告知即可'],
  },
  {
    key: 'pets',
    label: '寵物接受度',
    options: ['不接受寵物', '可接受貓咪', '可接受狗狗', '不限制'],
  },
  {
    key: 'smoking',
    label: '吸菸習慣',
    options: ['絕對禁菸', '陽台可', '無限制'],
  },
  {
    key: 'cooking',
    label: '烹飪習慣',
    options: ['不開伙', '限輕食無油煙', '可大火烹飪'],
  },
  {
    key: 'electricity',
    label: '公共電費分攤方式',
    options: ['按人頭均分', '按房型面積', '依電錶自付'],
  },
  {
    key: 'sharing',
    label: '共用物品習慣',
    options: ['嚴禁未經同意借用', '公共消耗品均分費用', '各自獨立購買'],
  },
  {
    key: 'ac',
    label: '冷氣使用時段',
    options: ['不限制', '晚上睡覺才開', '省電不常開'],
  },
  {
    key: 'noise',
    label: '聲音接受度',
    options: ['需絕對安靜', '一般生活音量可接受', '可接受放音樂'],
  },
];

const MATCHES = [
  { name: '陳小華', score: 98, avatar: '陳', tags: ['工程師', '作息規律', '不菸無寵', '喜歡安靜'], color: '#9CAF88' },
  { name: '林美玲', score: 95, avatar: '林', tags: ['設計師', '貓奴', '愛乾淨', '偶爾輕食'], color: '#AFA3B0' },
  { name: '張家豪', score: 92, avatar: '張', tags: ['大學生', '陽光開朗', '不帶異性過夜', '準時交租'], color: '#98A8B8' },
  { name: '許雅婷', score: 90, avatar: '許', tags: ['公務員', '極度愛乾淨', '早睡早起', '禁菸無寵'], color: '#B8C5AA' },
  { name: '王志明', score: 88, avatar: '王', tags: ['上班族', '夜貓子', '偶爾小酌', '喜歡音樂'], color: '#C4B5C7' },
  { name: '劉芳妤', score: 87, avatar: '劉', tags: ['護理師', '作息彈性', '愛貓', '尊重隱私'], color: '#AFA3B0' },
  { name: '賴冠宇', score: 85, avatar: '賴', tags: ['外送員', '隨和', '不開伙', '自備消耗品'], color: '#9CAF88' },
  { name: '蔡晴雯', score: 83, avatar: '蔡', tags: ['文字工作者', '靜音型', '無菸', '每週大掃除'], color: '#98A8B8' },
  { name: '曾子軒', score: 81, avatar: '曾', tags: ['軟體研發', '極簡主義', '無寵', '早出晚歸'], color: '#B8C5AA' },
  { name: '董佩君', score: 80, avatar: '董', tags: ['研究生', '偶爾同性訪客', '開伙輕食', '自律'], color: '#C4B5C7' },
];

export default function RoommateQuestionnaire({ onClose }: RoommateQuestionnaireProps) {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [currentQ, setCurrentQ] = useState(0);

  const allAnswered = QUESTIONS.every(q => answers[q.key]);
  const progress = (Object.keys(answers).length / QUESTIONS.length) * 100;

  const handleAnswer = (key: string, opt: string) => {
    setAnswers(a => ({ ...a, [key]: opt }));
    if (currentQ < QUESTIONS.length - 1) {
      setTimeout(() => setCurrentQ(q => q + 1), 280);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-3xl w-full max-w-lg max-h-[90vh] overflow-hidden shadow-2xl flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[var(--morandi-stone)]/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${LIME}22` }}>
              <Users className="w-5 h-5" style={{ color: LIME }} />
            </div>
            <div>
              <h3 className="font-semibold text-[var(--morandi-charcoal)]">室友希望條件篩選</h3>
              <p className="text-xs text-[var(--morandi-charcoal)] opacity-50">Desired Roommate Questionnaire</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-[var(--morandi-muted)] transition-colors">
            <X className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-60" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          <AnimatePresence mode="wait">
            {!submitted ? (
              <motion.div key="quiz" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-6">
                {/* Progress bar */}
                <div className="mb-5">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-[var(--morandi-charcoal)] opacity-50">{Object.keys(answers).length} / {QUESTIONS.length} 完成</span>
                    <span className="font-medium" style={{ color: LIME }}>{Math.round(progress)}%</span>
                  </div>
                  <div className="h-1.5 bg-[var(--morandi-muted)] rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${progress}%`, background: LIME }} />
                  </div>
                </div>

                {/* Questions */}
                <div className="space-y-4">
                  {QUESTIONS.map((q, idx) => (
                    <div
                      key={q.key}
                      className={`rounded-2xl border p-4 transition-all duration-200 ${idx === currentQ ? 'shadow-md' : ''}`}
                      style={{
                        borderColor: answers[q.key] ? `${LIME}60` : idx === currentQ ? 'rgba(163,230,53,0.3)' : 'rgba(212,205,195,0.4)',
                        background: answers[q.key] ? `${LIME}08` : idx === currentQ ? `${LIME}05` : 'transparent',
                        opacity: idx > currentQ && !answers[q.key] ? 0.45 : 1,
                      }}
                    >
                      <div className="flex items-center gap-2 mb-3">
                        <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                          style={{ background: answers[q.key] ? LIME : 'rgba(0,0,0,0.08)', color: answers[q.key] ? '#000' : 'rgba(74,74,74,0.5)' }}>
                          {answers[q.key] ? <CheckCircle2 className="w-3.5 h-3.5" /> : idx + 1}
                        </span>
                        <p className="text-sm font-semibold text-[var(--morandi-charcoal)]">{q.label}</p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {q.options.map(opt => (
                          <button key={opt} onClick={() => handleAnswer(q.key, opt)}
                            className="px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-150"
                            style={answers[q.key] === opt
                              ? { background: LIME, color: '#000', borderColor: LIME }
                              : { background: 'transparent', borderColor: 'rgba(212,205,195,0.6)', color: 'rgba(74,74,74,0.7)' }}>
                            {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setSubmitted(true)}
                  disabled={!allAnswered}
                  className="w-full mt-5 py-3.5 rounded-xl text-sm font-semibold transition-all hover:shadow-lg disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  style={{ background: allAnswered ? LIME : 'rgba(0,0,0,0.08)', color: allAnswered ? '#000' : 'rgba(74,74,74,0.4)' }}
                >
                  開始配對室友 <ChevronRight className="w-4 h-4" />
                </button>
              </motion.div>
            ) : (
              <motion.div key="results" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="p-6">
                <div className="text-center mb-5">
                  <div className="w-14 h-14 mx-auto rounded-full flex items-center justify-center mb-3 shadow-md"
                    style={{ background: `${LIME}22` }}>
                    <Heart className="w-7 h-7" style={{ color: LIME }} />
                  </div>
                  <h3 className="font-bold text-[var(--morandi-charcoal)] text-lg">找到 10 位室友候選人！</h3>
                  <p className="text-xs text-[var(--morandi-charcoal)] opacity-50 mt-1">依契合度排列，點擊卡片查看詳情</p>
                </div>

                <div className="space-y-3">
                  {MATCHES.map((m, idx) => (
                    <motion.div
                      key={m.name}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.06 }}
                      className="flex items-center gap-4 p-4 rounded-2xl border border-[var(--morandi-stone)]/30 hover:border-[var(--morandi-sage)]/40 hover:shadow-md transition-all cursor-pointer bg-white"
                    >
                      {/* Avatar */}
                      <div className="w-11 h-11 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0 shadow-sm"
                        style={{ background: m.color }}>
                        {m.avatar}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-semibold text-sm text-[var(--morandi-charcoal)]">{m.name}</span>
                          <span className="text-xs font-bold px-2 py-0.5 rounded-full text-black"
                            style={{ background: LIME }}>{m.score}% 契合</span>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {m.tags.map(t => (
                            <span key={t} className="text-[10px] px-2 py-0.5 rounded-full bg-[var(--morandi-muted)] text-[var(--morandi-charcoal)] opacity-70">
                              {t}
                            </span>
                          ))}
                        </div>
                      </div>

                      <ChevronRight className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-30 shrink-0" />
                    </motion.div>
                  ))}
                </div>

                <button onClick={onClose}
                  className="w-full mt-5 py-3.5 rounded-xl text-sm font-semibold text-black transition-all hover:opacity-90"
                  style={{ background: LIME }}>
                  確認，開始找共享雅房
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
