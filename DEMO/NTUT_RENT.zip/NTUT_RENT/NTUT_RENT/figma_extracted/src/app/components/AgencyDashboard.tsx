/**
 * 業者管理後台 (Agency Dashboard)
 * Same layout as LandlordDashboard, tailored for third-party agency operators.
 */
import { useState } from 'react';
import { Users, FileText, DollarSign, Wrench, Calculator, BadgeCheck, TrendingUp, AlertCircle, CheckCircle2, Clock, FileCheck, Shield, Plus, X, Upload, Home, Star, Building2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Progress } from '../components/ui/progress';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';

const FURNITURE_OPTIONS = ['衣櫃 (Wardrobe)', '洗衣機 (Washing Machine)', '冰箱 (Refrigerator)', '冷氣 (Air Conditioner)', '雙人床 (Double Bed)', '熱水器 (Water Heater)', '沙發 (Sofa)'];
const ADVANTAGE_OPTIONS = ['代收垃圾 (Garbage Collection)', '近捷運站 (Near MRT)', '可養寵物 (Pet Friendly)', '有獨立陽台 (Private Balcony)'];

const MOCK_AGENCY_PROPERTIES = [
  { id: 1, title: '信義奢華套房', address: '台北市信義區松仁路', rent: 22000, status: '出租中', tenant: '張*豪', nextRent: '2026-07-01' },
  { id: 2, title: '中山現代套房', address: '台北市中山區民生東路', rent: 16500, status: '待簽約', tenant: '王*婷', nextRent: null },
  { id: 3, title: '板橋新板套房', address: '新北市板橋區新站路', rent: 14500, status: '空置中', tenant: null, nextRent: null },
  { id: 4, title: '大安陽台整層住家', address: '台北市大安區信義路四段', rent: 38000, status: '出租中', tenant: '李*民', nextRent: '2026-07-01' },
];

interface AgencyDashboardProps {
  tenantProfiles: any[];
  contracts: any[];
  rentPayments: any[];
  maintenanceRequests: any[];
  taxBenefits: any;
}

export default function AgencyDashboard({
  tenantProfiles, contracts, rentPayments, maintenanceRequests, taxBenefits
}: AgencyDashboardProps) {
  const [activeTab, setActiveTab] = useState('properties');
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [deedUploaded, setDeedUploaded] = useState(false);
  const [selectedFurniture, setSelectedFurniture] = useState<string[]>([]);
  const [selectedAdvantages, setSelectedAdvantages] = useState<string[]>([]);
  const [newPropForm, setNewPropForm] = useState({ title: '', address: '', rent: '', floor: '', size: '' });
  const [monthlyRent, setMonthlyRent] = useState(25000);
  const [landTax, setLandTax] = useState(8000);
  const [houseTax, setHouseTax] = useState(12000);

  const toggleArr = (arr: string[], setArr: (v: string[]) => void, val: string) =>
    setArr(arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val]);

  const savedIncomeTax = monthlyRent * 12 * (1 - taxBenefits.incomeDeduction) * 0.2;
  const savedLandTax = landTax * (1 - taxBenefits.landTaxReduction);
  const savedHouseTax = houseTax * (1 - taxBenefits.houseTaxReduction);
  const totalAnnualSavings = savedIncomeTax + savedLandTax + savedHouseTax;

  return (
    <div className="min-h-full bg-gradient-to-br from-[var(--morandi-warm-white)] via-white to-[var(--morandi-grey-taupe)] p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="mb-8 flex items-start gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-[var(--morandi-mauve)] to-[var(--morandi-slate)] rounded-2xl flex items-center justify-center shadow-lg">
            <Building2 className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--morandi-charcoal)]">業者管理後台</h1>
            <p className="text-sm text-[var(--morandi-charcoal)] opacity-50">Agency Dashboard — 專業房仲與物業管理後台</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Users, label: '委託租客', value: tenantProfiles.length, color: 'from-[var(--morandi-sage)] to-[var(--morandi-sage-light)]' },
            { icon: FileText, label: '委託物件', value: MOCK_AGENCY_PROPERTIES.length, color: 'from-[var(--morandi-slate)] to-[var(--morandi-slate-light)]' },
            { icon: DollarSign, label: '管理月收', value: `$${MOCK_AGENCY_PROPERTIES.reduce((s, p) => s + p.rent, 0).toLocaleString()}`, color: 'from-[var(--morandi-mauve)] to-[var(--morandi-mauve-light)]' },
            { icon: Wrench, label: '待處理案', value: maintenanceRequests.length, color: 'from-[var(--morandi-clay)] to-[var(--morandi-stone)]' },
          ].map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="bg-white p-5 rounded-2xl shadow-md border border-[var(--morandi-stone)] hover:shadow-lg transition-shadow">
              <div className={`w-11 h-11 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center mb-3`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div className="text-xl font-bold text-[var(--morandi-charcoal)]">{value}</div>
              <div className="text-xs text-[var(--morandi-charcoal)] opacity-50 mt-0.5">{label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-5">
          <TabsList className="bg-white rounded-xl p-1 shadow-md border border-[var(--morandi-stone)] flex flex-wrap gap-1">
            {[
              { value: 'properties', icon: Home, label: '委託物件' },
              { value: 'tenants', icon: Users, label: '租客履歷' },
              { value: 'payments', icon: DollarSign, label: '租金管理' },
              { value: 'maintenance', icon: Wrench, label: '修繕管理' },
            ].map(tab => (
              <TabsTrigger key={tab.value} value={tab.value}
                className="rounded-lg data-[state=active]:bg-[var(--morandi-mauve)] data-[state=active]:text-white text-sm">
                <tab.icon className="w-4 h-4 mr-1.5" />{tab.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {/* Properties Tab */}
          <TabsContent value="properties" className="space-y-4">
            {MOCK_AGENCY_PROPERTIES.map(p => (
              <div key={p.id} className="bg-white rounded-2xl p-5 shadow-md border border-[var(--morandi-stone)] hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[var(--morandi-mauve)] to-[var(--morandi-mauve-light)] flex items-center justify-center shrink-0">
                      <Home className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[var(--morandi-charcoal)]">{p.title}</h3>
                      <p className="text-xs text-[var(--morandi-charcoal)] opacity-50">{p.address}</p>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium shrink-0 ${
                    p.status === '出租中' ? 'bg-[var(--morandi-sage)]/10 text-[var(--morandi-sage)] border border-[var(--morandi-sage)]/20'
                    : p.status === '待簽約' ? 'bg-[var(--morandi-slate)]/10 text-[var(--morandi-slate)] border border-[var(--morandi-slate)]/20'
                    : 'bg-[var(--morandi-mauve)]/10 text-[var(--morandi-mauve)] border border-[var(--morandi-mauve)]/20'
                  }`}>{p.status}</span>
                </div>
                <div className="mt-3 flex items-center gap-6 text-sm">
                  <div>
                    <span className="block text-[10px] text-[var(--morandi-charcoal)] opacity-45">月租金</span>
                    <span className="font-semibold text-[var(--morandi-sage)]">${p.rent.toLocaleString()}</span>
                  </div>
                  {p.tenant && (
                    <div>
                      <span className="block text-[10px] text-[var(--morandi-charcoal)] opacity-45">租客</span>
                      <span className="font-medium text-[var(--morandi-charcoal)]">{p.tenant}</span>
                    </div>
                  )}
                  {p.nextRent && (
                    <div>
                      <span className="block text-[10px] text-[var(--morandi-charcoal)] opacity-45">下次收租</span>
                      <span className="font-medium text-[var(--morandi-charcoal)]">{p.nextRent}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </TabsContent>

          {/* Tenants Tab */}
          <TabsContent value="tenants" className="space-y-4">
            {tenantProfiles.map(tenant => (
              <div key={tenant.id} className="bg-white rounded-2xl p-5 shadow-md border border-[var(--morandi-stone)]">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-[var(--morandi-mauve)] to-[var(--morandi-slate)] rounded-xl flex items-center justify-center text-white font-bold">
                    {tenant.name[0]}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-[var(--morandi-charcoal)]">{tenant.name}</span>
                      {tenant.verified && <BadgeCheck className="w-4 h-4 text-[var(--morandi-mauve)]" />}
                    </div>
                    <p className="text-xs text-[var(--morandi-charcoal)] opacity-50">{tenant.occupation} · AI 評分 {tenant.aiScore}</p>
                  </div>
                  <span className={`ml-auto text-xs px-3 py-1 rounded-full font-medium ${
                    tenant.status === '已入住' ? 'bg-[var(--morandi-sage)]/10 text-[var(--morandi-sage)]'
                    : 'bg-[var(--morandi-mauve)]/10 text-[var(--morandi-mauve)]'
                  }`}>{tenant.status}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {tenant.tags.map((t: string) => (
                    <span key={t} className="text-[10px] px-2 py-0.5 rounded-full bg-[var(--morandi-muted)] text-[var(--morandi-charcoal)] opacity-70">{t}</span>
                  ))}
                </div>
              </div>
            ))}
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments" className="space-y-4">
            {rentPayments.map(payment => (
              <div key={payment.id} className="bg-white rounded-2xl p-5 shadow-md border border-[var(--morandi-stone)]">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-[var(--morandi-charcoal)]">{payment.tenantName}</span>
                  <span className={`text-xs px-3 py-1 rounded-full font-medium ${payment.status === '已繳納' ? 'bg-[var(--morandi-sage)]/10 text-[var(--morandi-sage)]' : 'bg-[#C48B88]/10 text-[#C48B88]'}`}>
                    {payment.status}
                  </span>
                </div>
                <p className="text-xs text-[var(--morandi-charcoal)] opacity-50 mb-2">{payment.propertyAddress}</p>
                <div className="text-xl font-bold text-[var(--morandi-charcoal)]">${payment.amount.toLocaleString()}</div>
                <p className="text-xs text-[var(--morandi-charcoal)] opacity-40 mt-1">截止日：{payment.dueDate}</p>
              </div>
            ))}
          </TabsContent>

          {/* Maintenance Tab */}
          <TabsContent value="maintenance" className="space-y-4">
            {maintenanceRequests.map(req => (
              <div key={req.id} className="bg-white rounded-2xl p-5 shadow-md border border-[var(--morandi-stone)]">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <p className="font-semibold text-[var(--morandi-charcoal)]">{req.issue}</p>
                    <p className="text-xs text-[var(--morandi-charcoal)] opacity-50">{req.tenantName} · {req.propertyAddress}</p>
                  </div>
                  <span className={`text-xs px-3 py-1 rounded-full font-medium shrink-0 ${
                    req.status === '已完成' ? 'bg-[var(--morandi-sage)]/10 text-[var(--morandi-sage)]'
                    : req.status === '處理中' ? 'bg-[var(--morandi-mauve)]/10 text-[var(--morandi-mauve)]'
                    : 'bg-[var(--morandi-slate)]/10 text-[var(--morandi-slate)]'
                  }`}>{req.status}</span>
                </div>
                <Progress value={req.status === '已完成' ? 100 : req.status === '已派工' ? 60 : 30} className="h-1.5" />
              </div>
            ))}
          </TabsContent>
        </Tabs>
      </div>

      {/* FAB */}
      <button onClick={() => setShowUploadForm(true)}
        className="fixed bottom-8 right-8 z-40 flex items-center gap-2.5 px-5 py-3.5 rounded-2xl text-white font-semibold text-sm shadow-2xl transition-all hover:scale-105 active:scale-95"
        style={{ background: 'linear-gradient(135deg, var(--morandi-mauve), var(--morandi-slate))' }}>
        <Plus className="w-5 h-5" />上傳新物件
      </button>

      {/* Upload Modal */}
      <AnimatePresence>
        {showUploadForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm p-4">
            <motion.div initial={{ opacity: 0, y: 60 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 60 }}
              className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-y-auto max-h-[90vh]">
              <div className="p-6">
                <div className="flex items-center justify-between mb-5">
                  <div>
                    <h3 className="text-lg font-semibold text-[var(--morandi-charcoal)]">上傳新委託物件</h3>
                    <p className="text-xs text-[var(--morandi-charcoal)] opacity-50 mt-0.5">業者委託上架管理</p>
                  </div>
                  <button onClick={() => setShowUploadForm(false)}
                    className="w-8 h-8 rounded-full bg-[var(--morandi-muted)] flex items-center justify-center">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="space-y-5">
                  <div className="space-y-3">
                    {[['物件名稱','例：信義精品套房','title'],['地址','台北市...','address']].map(([label, ph, key]) => (
                      <div key={key}>
                        <label className="text-xs text-[var(--morandi-charcoal)] opacity-55 mb-1 block">{label}</label>
                        <input value={(newPropForm as any)[key]} onChange={e => setNewPropForm(f => ({ ...f, [key]: e.target.value }))} placeholder={ph}
                          className="w-full px-3.5 py-2.5 rounded-xl border border-[var(--morandi-stone)]/50 bg-[var(--morandi-warm-white)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--morandi-mauve)]/30" />
                      </div>
                    ))}
                    <div className="grid grid-cols-3 gap-3">
                      {[['月租金','rent'],['樓層','floor'],['坪數','size']].map(([label, key]) => (
                        <div key={key}>
                          <label className="text-xs text-[var(--morandi-charcoal)] opacity-55 mb-1 block">{label}</label>
                          <input value={(newPropForm as any)[key]} onChange={e => setNewPropForm(f => ({ ...f, [key]: e.target.value }))} placeholder="—"
                            className="w-full px-3 py-2.5 rounded-xl border border-[var(--morandi-stone)]/50 bg-[var(--morandi-warm-white)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--morandi-mauve)]/30" />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Deed verification */}
                  <div>
                    <label className="text-xs font-semibold text-[var(--morandi-charcoal)] opacity-60 mb-2 block">房產驗證</label>
                    <button onClick={() => setDeedUploaded(p => !p)}
                      className="w-full flex flex-col items-center gap-2 py-5 rounded-2xl border-2 border-dashed transition-all"
                      style={{ borderColor: deedUploaded ? 'var(--morandi-mauve)' : 'rgba(212,205,195,0.6)', background: deedUploaded ? 'rgba(175,163,176,0.07)' : 'transparent' }}>
                      {deedUploaded ? <CheckCircle2 className="w-7 h-7 text-[var(--morandi-mauve)]" /> : <Upload className="w-7 h-7 text-[var(--morandi-charcoal)] opacity-25" />}
                      <p className="text-sm text-[var(--morandi-charcoal)] opacity-55">
                        {deedUploaded ? '文件已上傳' : '請上傳房屋所有權狀或謄本照片'}
                      </p>
                    </button>
                    {deedUploaded && (
                      <div className="mt-2 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-50 border border-amber-200 w-fit">
                        <Clock className="w-3.5 h-3.5 text-amber-500" />
                        <span className="text-xs text-amber-600 font-medium">審核中 (Under Review)</span>
                      </div>
                    )}
                  </div>

                  {/* Furniture */}
                  <div>
                    <label className="text-xs font-semibold text-[var(--morandi-charcoal)] opacity-60 mb-2 block">附帶家具與家電</label>
                    <div className="grid grid-cols-2 gap-1.5">
                      {FURNITURE_OPTIONS.map(f => (
                        <label key={f} className="flex items-center gap-2 cursor-pointer p-2 rounded-lg hover:bg-[var(--morandi-muted)] transition-colors">
                          <input type="checkbox" checked={selectedFurniture.includes(f)} onChange={() => toggleArr(selectedFurniture, setSelectedFurniture, f)} className="w-4 h-4 accent-[var(--morandi-mauve)]" />
                          <span className="text-xs text-[var(--morandi-charcoal)] opacity-70">{f}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Advantages */}
                  <div>
                    <label className="text-xs font-semibold text-[var(--morandi-charcoal)] opacity-60 mb-2 flex items-center gap-1">
                      <Star className="w-3.5 h-3.5" /> 房屋優勢
                    </label>
                    <div className="grid grid-cols-2 gap-1.5">
                      {ADVANTAGE_OPTIONS.map(a => (
                        <label key={a} className="flex items-center gap-2 cursor-pointer p-2 rounded-lg hover:bg-[var(--morandi-muted)] transition-colors">
                          <input type="checkbox" checked={selectedAdvantages.includes(a)} onChange={() => toggleArr(selectedAdvantages, setSelectedAdvantages, a)} className="w-4 h-4 accent-[var(--morandi-slate)]" />
                          <span className="text-xs text-[var(--morandi-charcoal)] opacity-70">{a}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <button onClick={() => setShowUploadForm(false)}
                    className="w-full py-3.5 rounded-xl text-white text-sm font-semibold transition-all hover:shadow-lg"
                    style={{ background: 'linear-gradient(135deg, var(--morandi-mauve), var(--morandi-slate))' }}>
                    送出審核
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
