import { useState } from 'react';
import { AnimatePresence } from 'motion/react';
import {
  Search, MapPin, BadgeCheck, Star, X, TrendingUp, ShoppingBag, Utensils,
  Hospital, GraduationCap, MessageSquare, ThumbsUp, CheckCircle2, Clock, Sofa
} from 'lucide-react';
import { Property, allDistricts } from '../../mockData';
import { Switch } from '../components/ui/switch';
import { Progress } from '../components/ui/progress';
import RoommateQuestionnaire from './RoommateQuestionnaire';

const PROPERTY_TYPES = ['全部', '整層住家', '獨立套房', '分租套房', '優質雅房'];
const LIME = '#a3e635';

interface RenterMapViewProps {
  properties: Property[];
  mrtStations: Array<{ id: number; name: string; lat: number; lng: number; line: string }>;
}

const FURNITURE_FILTERS = ['有洗衣機', '有衣櫃', '有冷氣', '有冰箱'];
const FURNITURE_MAP: Record<string, string> = {
  '有洗衣機': '洗衣機', '有衣櫃': '衣櫃', '有冷氣': '冷氣', '有冰箱': '冰箱'
};

// Map coordinate helpers — NTUT centered at ~25.0432, 121.5340
// SVG viewport: 800 x 580, NTUT maps to (400, 290)
const LNG_CENTER = 121.534;
const LAT_CENTER = 25.043;
const LNG_SCALE = 3200; // px per degree lng
const LAT_SCALE = 3500; // px per degree lat (inverted)

function toSvg(lat: number, lng: number): [number, number] {
  const x = 400 + (lng - LNG_CENTER) * LNG_SCALE;
  const y = 290 - (lat - LAT_CENTER) * LAT_SCALE;
  return [x, y];
}

const LINE_COLORS: Record<string, string> = {
  '板南線': '#006DB7',
  '松山新店線': '#008659',
  '淡水信義線': '#CC0000',
  '中和新蘆線': '#F5A623',
  '文湖線': '#C48B3D',
};

// MRT station data with true coords for NTUT grid
const MRT_STATIONS = [
  // Blue 板南線
  { name: '台北車站', lat: 25.0478, lng: 121.5170, line: '板南線' },
  { name: '善導寺',   lat: 25.0449, lng: 121.5276, line: '板南線' },
  { name: '忠孝新生', lat: 25.0424, lng: 121.5319, line: '板南線' },
  { name: '忠孝復興', lat: 25.0414, lng: 121.5439, line: '板南線' },
  { name: '忠孝敦化', lat: 25.0412, lng: 121.5510, line: '板南線' },
  // Green 松山新店線
  { name: '中山',     lat: 25.0527, lng: 121.5202, line: '松山新店線' },
  { name: '松江南京', lat: 25.0516, lng: 121.5301, line: '松山新店線' },
  { name: '南京復興', lat: 25.0514, lng: 121.5437, line: '松山新店線' },
  // Red 淡水信義線
  { name: '中正紀念堂', lat: 25.0318, lng: 121.5198, line: '淡水信義線' },
  { name: '東門',       lat: 25.0335, lng: 121.5298, line: '淡水信義線' },
  { name: '大安森林公園', lat: 25.0330, lng: 121.5360, line: '淡水信義線' },
  { name: '大安',       lat: 25.0333, lng: 121.5434, line: '淡水信義線' },
  // Yellow 中和新蘆線
  { name: '忠孝新生(Y)', lat: 25.0436, lng: 121.5296, line: '中和新蘆線' },
  { name: '東門(Y)',     lat: 25.0340, lng: 121.5295, line: '中和新蘆線' },
  // Brown 文湖線
  { name: '南京復興(B)', lat: 25.0500, lng: 121.5445, line: '文湖線' },
  { name: '忠孝復興(B)', lat: 25.0420, lng: 121.5445, line: '文湖線' },
  { name: '大安(B)',     lat: 25.0340, lng: 121.5440, line: '文湖線' },
];

const LINE_PATHS: Array<{ line: string; stations: string[] }> = [
  { line: '板南線', stations: ['台北車站', '善導寺', '忠孝新生', '忠孝復興', '忠孝敦化'] },
  { line: '松山新店線', stations: ['中山', '松江南京', '南京復興'] },
  { line: '淡水信義線', stations: ['中正紀念堂', '東門', '大安森林公園', '大安'] },
  { line: '中和新蘆線', stations: ['忠孝新生(Y)', '東門(Y)'] },
  { line: '文湖線', stations: ['南京復興(B)', '忠孝復興(B)', '大安(B)'] },
];

export default function RenterMapView({ properties }: RenterMapViewProps) {
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [subsidyOnly, setSubsidyOnly] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 50000]);
  const [selectedDistrict, setSelectedDistrict] = useState<string>('all');
  const [hoveredProperty, setHoveredProperty] = useState<number | null>(null);
  const [activeFurniture, setActiveFurniture] = useState<string[]>([]);
  const [selectedType, setSelectedType] = useState<string>('全部');
  const [showQuestionnaire, setShowQuestionnaire] = useState(false);

  const toggleFurniture = (f: string) =>
    setActiveFurniture(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);

  const filteredProperties = properties.filter(p => {
    if (subsidyOnly && !p.subsidy) return false;
    if (p.price < priceRange[0] || p.price > priceRange[1]) return false;
    if (selectedDistrict !== 'all' && p.district !== selectedDistrict) return false;
    for (const f of activeFurniture) {
      if (!p.furniture?.includes(FURNITURE_MAP[f])) return false;
    }
    if (selectedType !== '全部') {
      const typeMap: Record<string, string[]> = {
        '整層住家': ['整層住家'],
        '獨立套房': ['套房', '電梯大樓'],
        '分租套房': ['套房', '公寓'],
        '優質雅房': ['雅房'],
      };
      const allowed = typeMap[selectedType] ?? [];
      if (!allowed.some(t => p.type?.includes(t) || p.title?.includes(selectedType === '優質雅房' ? '雅房' : selectedType))) return false;
    }
    return true;
  });

  const handleTypeSelect = (t: string) => {
    setSelectedType(t);
    if (t === '優質雅房') setShowQuestionnaire(true);
  };

  const allDistrictsList = [
    ...allDistricts.taipei.map(d => ({ d, city: '台北市' })),
    ...allDistricts.newTaipei.map(d => ({ d, city: '新北市' })),
  ];

  return (
    <div className="h-full flex flex-col lg:flex-row overflow-hidden bg-[var(--morandi-warm-white)]">
      {/* ── Left Sidebar ────────────────────────────────────────────── */}
      <div className="w-full lg:w-96 xl:w-[420px] bg-white border-r border-[var(--morandi-stone)] flex flex-col overflow-hidden shadow-lg">
        <div className="p-5 border-b border-[var(--morandi-stone)] space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--morandi-charcoal)] opacity-35" />
            <input type="text" placeholder="搜尋地點、捷運站、學校..."
              className="w-full pl-10 pr-4 py-3 bg-[var(--morandi-muted)] rounded-xl border-0 focus:ring-2 focus:ring-[var(--morandi-sage)] transition-all text-sm" />
          </div>

          {/* Property Type Segmented Control */}
          <div>
            <label className="text-xs font-semibold text-[var(--morandi-charcoal)] opacity-60 mb-2 block">房屋類型</label>
            <div className="flex flex-wrap gap-1.5">
              {PROPERTY_TYPES.map(t => (
                <button key={t} onClick={() => handleTypeSelect(t)}
                  className="px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-150"
                  style={selectedType === t
                    ? { background: LIME, color: '#000', borderColor: LIME, fontWeight: 700 }
                    : { background: 'transparent', borderColor: 'rgba(212,205,195,0.6)', color: 'rgba(74,74,74,0.65)' }}>
                  {t}
                  {t === '優質雅房' && ' 🏠'}
                </button>
              ))}
            </div>
            {selectedType === '優質雅房' && (
              <button onClick={() => setShowQuestionnaire(true)}
                className="mt-2 w-full text-xs py-2 rounded-lg border-2 border-dashed font-medium transition-all"
                style={{ borderColor: LIME, color: LIME, background: `${LIME}10` }}>
                ✦ 開啟室友條件問卷
              </button>
            )}
          </div>

          {/* Subsidy Toggle */}
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-[var(--morandi-sage)]/10 to-[var(--morandi-slate)]/10 rounded-xl border border-[var(--morandi-sage)]/20">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-[var(--morandi-sage)]" />
              <span className="font-medium text-[var(--morandi-charcoal)] text-sm">只看租補合格物件</span>
            </div>
            <Switch checked={subsidyOnly} onCheckedChange={setSubsidyOnly} />
          </div>

          {/* District Filter — 41 districts */}
          <div>
            <label className="block text-xs font-semibold text-[var(--morandi-charcoal)] opacity-60 mb-1.5">區域</label>
            <select value={selectedDistrict} onChange={e => setSelectedDistrict(e.target.value)}
              className="w-full px-4 py-2.5 bg-[var(--morandi-muted)] rounded-lg border-0 focus:ring-2 focus:ring-[var(--morandi-sage)] transition-all text-sm appearance-none">
              <option value="all">全部區域</option>
              <optgroup label="── 台北市 ──">
                {allDistricts.taipei.map(d => <option key={d} value={d}>{d}</option>)}
              </optgroup>
              <optgroup label="── 新北市 ──">
                {allDistricts.newTaipei.map(d => <option key={d} value={d}>{d}</option>)}
              </optgroup>
            </select>
          </div>

          {/* Price Range */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-[var(--morandi-charcoal)] opacity-60">價格範圍</label>
              <span className="text-xs text-[var(--morandi-charcoal)] opacity-50">
                ${priceRange[0].toLocaleString()} - ${priceRange[1].toLocaleString()}
              </span>
            </div>
            <input type="range" min="0" max="50000" step="1000" value={priceRange[1]}
              onChange={e => setPriceRange([0, parseInt(e.target.value)])}
              className="w-full accent-[var(--morandi-sage)]" />
          </div>

          {/* Furniture Filters */}
          <div>
            <label className="flex items-center gap-1.5 text-xs font-semibold text-[var(--morandi-charcoal)] opacity-60 mb-2">
              <Sofa className="w-3.5 h-3.5" /> 家具篩選
            </label>
            <div className="grid grid-cols-2 gap-2">
              {FURNITURE_FILTERS.map(f => (
                <button key={f} onClick={() => toggleFurniture(f)}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium border transition-all duration-200"
                  style={activeFurniture.includes(f)
                    ? { background: 'rgba(156,175,136,0.15)', borderColor: 'var(--morandi-sage)', color: 'var(--morandi-sage)' }
                    : { background: 'transparent', borderColor: 'rgba(212,205,195,0.5)', color: 'rgba(74,74,74,0.6)' }}>
                  {activeFurniture.includes(f) && <CheckCircle2 className="w-3 h-3 shrink-0" />}
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* Result count */}
          <div className="text-sm text-[var(--morandi-charcoal)] opacity-60 bg-[var(--morandi-muted)] px-3 py-2 rounded-lg">
            找到 <span className="font-semibold text-[var(--morandi-sage)]">{filteredProperties.length}</span> 個符合條件的房源
          </div>
        </div>

        {/* Property List */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-4 space-y-3">
            {filteredProperties.map(property => (
              <div key={property.id}
                className={`bg-white rounded-xl border-2 transition-all duration-300 cursor-pointer hover:shadow-lg ${
                  hoveredProperty === property.id || selectedProperty?.id === property.id
                    ? 'border-[var(--morandi-sage)] shadow-md scale-[1.01]'
                    : 'border-[var(--morandi-stone)] hover:border-[var(--morandi-sage-light)]'
                }`}
                onClick={() => setSelectedProperty(property)}
                onMouseEnter={() => setHoveredProperty(property.id)}
                onMouseLeave={() => setHoveredProperty(null)}
              >
                <div className="flex gap-3 p-3">
                  <div className="relative w-28 h-28 flex-shrink-0 rounded-lg overflow-hidden">
                    <img src={property.images[0]} alt={property.title} className="w-full h-full object-cover hover:scale-110 transition-transform duration-300" />
                    {property.subsidy && (
                      <div className="absolute top-1 left-1 bg-[var(--morandi-sage)] text-white px-2 py-0.5 rounded-md text-xs font-medium shadow">租補</div>
                    )}
                    <div className="absolute bottom-1 right-1 bg-black/60 text-white px-2 py-0.5 rounded-md text-xs font-medium">
                      {property.aiMatch}%
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-[var(--morandi-charcoal)] mb-1 line-clamp-1 text-sm">{property.title}</h3>
                    <div className="flex items-center gap-1 text-xs text-[var(--morandi-charcoal)] opacity-50 mb-1.5">
                      <MapPin className="w-3 h-3" />
                      <span className="line-clamp-1">{property.district}</span>
                    </div>
                    <div className="text-lg font-bold text-[var(--morandi-sage)] mb-1.5">
                      ${property.price.toLocaleString()}<span className="text-xs font-normal text-[var(--morandi-charcoal)] opacity-45">/月</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-[var(--morandi-charcoal)] opacity-50 flex-wrap">
                      <span>{property.type}</span>
                      <span>·</span><span>{property.size} 坪</span>
                      {property.furniture?.length > 0 && (
                        <><span>·</span><span className="text-[var(--morandi-slate)]">{property.furniture.slice(0, 2).join('/')}</span></>
                      )}
                      {property.landlord.verified && (
                        <><span>·</span><BadgeCheck className="w-3 h-3 text-[var(--morandi-sage)]" /></>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Right: NTUT-centered SVG Map ─────────────────────────── */}
      <div className="flex-1 relative bg-[var(--morandi-grey-taupe)] min-h-[400px]">
        <div className="absolute inset-0 overflow-hidden">
          <svg viewBox="0 0 800 580" className="w-full h-full">
            {/* Base fill */}
            <rect width="800" height="580" fill="#EBE6E0" />

            {/* City block grid */}
            {Array.from({ length: 12 }).map((_, i) => (
              <line key={`h${i}`} x1="0" y1={i * 50} x2="800" y2={i * 50} stroke="#DDD8D0" strokeWidth="0.5" />
            ))}
            {Array.from({ length: 18 }).map((_, i) => (
              <line key={`v${i}`} x1={i * 50} y1="0" x2={i * 50} y2="580" stroke="#DDD8D0" strokeWidth="0.5" />
            ))}

            {/* Major roads */}
            <line x1="0" y1="232" x2="800" y2="232" stroke="#CCC8C0" strokeWidth="4" opacity="0.6" />
            <line x1="0" y1="318" x2="800" y2="318" stroke="#CCC8C0" strokeWidth="4" opacity="0.6" />
            <line x1="340" y1="0" x2="340" y2="580" stroke="#CCC8C0" strokeWidth="4" opacity="0.6" />
            <line x1="500" y1="0" x2="500" y2="580" stroke="#CCC8C0" strokeWidth="4" opacity="0.6" />

            {/* Ketagalan / Heping roads labels */}
            <text x="350" y="228" fontSize="8" fill="#AAA" opacity="0.7">和平東路</text>
            <text x="350" y="314" fontSize="8" fill="#AAA" opacity="0.7">忠孝東路</text>
            <text x="342" y="120" fontSize="8" fill="#AAA" opacity="0.7" transform="rotate(90,342,120)">復興南路</text>

            {/* MRT lines */}
            {LINE_PATHS.map(({ line, stations }) => {
              const pts = stations.map(name => {
                const s = MRT_STATIONS.find(m => m.name === name);
                return s ? toSvg(s.lat, s.lng) : null;
              }).filter(Boolean) as [number, number][];
              if (pts.length < 2) return null;
              const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
              return (
                <path key={line} d={d} stroke={LINE_COLORS[line]} strokeWidth="4" fill="none"
                  strokeLinecap="round" opacity="0.85"
                  style={{ filter: `drop-shadow(0 1px 3px ${LINE_COLORS[line]}44)` }} />
              );
            })}

            {/* MRT Stations */}
            {MRT_STATIONS.map(s => {
              const [x, y] = toSvg(s.lat, s.lng);
              const color = LINE_COLORS[s.line] ?? '#888';
              const showLabel = !s.name.includes('(');
              return (
                <g key={s.name}>
                  <circle cx={x} cy={y} r="5" fill="white" stroke={color} strokeWidth="2.5" />
                  {showLabel && (
                    <text x={x} y={y - 9} textAnchor="middle" fontSize="7.5" fill="#555" fontWeight="600"
                      style={{ textShadow: '0 0 4px white' }}>{s.name}</text>
                  )}
                </g>
              );
            })}

            {/* NTUT campus marker */}
            {(() => {
              const [x, y] = toSvg(25.0432, 121.5340);
              return (
                <g>
                  <rect x={x - 22} y={y - 12} width="44" height="18" rx="4" fill="#AFA3B0" opacity="0.9" />
                  <text x={x} y={y + 2} textAnchor="middle" fontSize="8" fill="white" fontWeight="700">北科大</text>
                </g>
              );
            })()}

            {/* Property markers */}
            {filteredProperties.slice(0, 20).map((property, idx) => {
              // Spread properties around their district area with slight offset
              const [bx, by] = toSvg(property.lat, property.lng);
              const ox = (idx % 3 - 1) * 12;
              const oy = (Math.floor(idx / 3) % 3 - 1) * 12;
              const x = Math.max(20, Math.min(780, bx + ox));
              const y = Math.max(20, Math.min(560, by + oy));
              const isActive = hoveredProperty === property.id || selectedProperty?.id === property.id;

              return (
                <g key={property.id} className="cursor-pointer"
                  onMouseEnter={() => setHoveredProperty(property.id)}
                  onMouseLeave={() => setHoveredProperty(null)}
                  onClick={() => setSelectedProperty(property)}>
                  {/* Shadow */}
                  <circle cx={x} cy={y + 2} r={isActive ? 18 : 14} fill="rgba(0,0,0,0.15)" />
                  {/* Bubble */}
                  <circle cx={x} cy={y} r={isActive ? 18 : 14}
                    fill={isActive ? '#9CAF88' : property.type === '雅房' ? '#AFA3B0' : '#98A8B8'}
                    stroke="white" strokeWidth="2.5" />
                  {/* Price label */}
                  <text x={x} y={y + 4} textAnchor="middle" fontSize={isActive ? "8" : "7"} fill="white" fontWeight="700">
                    {property.price >= 10000 ? `${(property.price / 1000).toFixed(0)}K` : `${property.price}`}
                  </text>
                  {/* Subsidy dot */}
                  {property.subsidy && (
                    <circle cx={x + (isActive ? 12 : 9)} cy={y - (isActive ? 12 : 9)} r="4" fill="#9CAF88" stroke="white" strokeWidth="1.5" />
                  )}
                </g>
              );
            })}

            {/* Legend */}
            <g transform="translate(12, 490)">
              <rect width="220" height="80" rx="8" fill="white" opacity="0.88" />
              <text x="10" y="18" fontSize="8" fontWeight="700" fill="#4A4A4A">捷運路線</text>
              {Object.entries(LINE_COLORS).slice(0, 5).map(([name, color], i) => (
                <g key={name} transform={`translate(8, ${26 + i * 11})`}>
                  <rect width="20" height="4" rx="2" fill={color} />
                  <text x="26" y="5" fontSize="7.5" fill="#666">{name}</text>
                </g>
              ))}
            </g>
            <g transform="translate(250, 490)">
              <rect width="160" height="55" rx="8" fill="white" opacity="0.88" />
              <text x="10" y="18" fontSize="8" fontWeight="700" fill="#4A4A4A">標記說明</text>
              <circle cx="18" cy="32" r="8" fill="#98A8B8" />
              <text x="30" y="36" fontSize="7.5" fill="#666">套房</text>
              <circle cx="18" cy="47" r="8" fill="#AFA3B0" />
              <text x="30" y="51" fontSize="7.5" fill="#666">雅房</text>
              <circle cx="90" cy="32" r="5" fill="#9CAF88" />
              <text x="100" y="36" fontSize="7.5" fill="#666">租補</text>
            </g>
          </svg>
        </div>

        {/* Property Detail Popup */}
        {selectedProperty && (
          <div className="absolute bottom-0 left-0 right-0 lg:bottom-auto lg:top-4 lg:right-4 lg:left-auto lg:w-96 bg-white rounded-t-3xl lg:rounded-3xl shadow-2xl overflow-hidden max-h-[80vh] overflow-y-auto">
            <button onClick={() => setSelectedProperty(null)}
              className="absolute top-4 right-4 z-10 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg hover:bg-white transition-colors">
              <X className="w-5 h-5" />
            </button>

            <div className="relative h-56">
              <img src={selectedProperty.images[0]} alt={selectedProperty.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2 flex-wrap">
                {selectedProperty.subsidy && (
                  <div className="bg-[var(--morandi-sage)] text-white px-3 py-1 rounded-full text-sm font-medium shadow-lg flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" />租補合格
                  </div>
                )}
                <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium text-[var(--morandi-charcoal)] shadow-lg">
                  AI {selectedProperty.aiMatch}%
                </div>
                <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium text-[var(--morandi-charcoal)] shadow-lg">
                  {selectedProperty.type}
                </div>
              </div>
            </div>

            <div className="p-5">
              <h2 className="text-xl font-bold text-[var(--morandi-charcoal)] mb-1">{selectedProperty.title}</h2>
              <div className="flex items-center gap-2 text-[var(--morandi-charcoal)] opacity-50 text-sm mb-3">
                <MapPin className="w-4 h-4" /><span>{selectedProperty.address}</span>
              </div>

              <div className="flex items-baseline gap-2 mb-4">
                <div className="text-2xl font-bold text-[var(--morandi-sage)]">${selectedProperty.price.toLocaleString()}</div>
                <div className="text-[var(--morandi-charcoal)] opacity-50 text-sm">/月</div>
                {selectedProperty.subsidy && (
                  <div className="ml-auto text-xs text-[var(--morandi-sage)] bg-[var(--morandi-sage)]/10 px-2.5 py-1 rounded-lg">
                    可省 ${selectedProperty.subsidyAmount}
                  </div>
                )}
              </div>

              {/* Quick stats */}
              <div className="grid grid-cols-3 gap-3 mb-4 p-3 bg-[var(--morandi-muted)] rounded-xl">
                <div className="text-center">
                  <div className="text-xl font-bold text-[var(--morandi-charcoal)]">{selectedProperty.rooms}</div>
                  <div className="text-[10px] text-[var(--morandi-charcoal)] opacity-45">房間</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold text-[var(--morandi-charcoal)]">{selectedProperty.size}</div>
                  <div className="text-[10px] text-[var(--morandi-charcoal)] opacity-45">坪數</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold text-[var(--morandi-charcoal)]">{selectedProperty.floor}</div>
                  <div className="text-[10px] text-[var(--morandi-charcoal)] opacity-45">樓層</div>
                </div>
              </div>

              {/* Furniture */}
              {selectedProperty.furniture?.length > 0 && (
                <div className="mb-4">
                  <p className="text-xs font-semibold text-[var(--morandi-charcoal)] opacity-55 mb-2 flex items-center gap-1">
                    <Sofa className="w-3.5 h-3.5" /> 附帶家具
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedProperty.furniture.map(f => (
                      <span key={f} className="px-2.5 py-1 rounded-full text-xs bg-[rgba(152,168,184,0.12)] text-[var(--morandi-slate)] border border-[rgba(152,168,184,0.3)]">{f}</span>
                    ))}
                  </div>
                </div>
              )}

              {/* Commute */}
              <div className="mb-4 p-3 bg-gradient-to-r from-[var(--morandi-slate)]/10 to-[var(--morandi-sage)]/10 rounded-xl border border-[var(--morandi-slate)]/20">
                <div className="flex items-center gap-2 mb-1">
                  <Clock className="w-4 h-4 text-[var(--morandi-slate)]" />
                  <span className="font-semibold text-[var(--morandi-charcoal)] text-sm">通勤資訊</span>
                </div>
                <p className="text-sm">
                  <span className="text-[var(--morandi-charcoal)] opacity-50">步行至 </span>
                  <span className="font-medium text-[var(--morandi-charcoal)]">{selectedProperty.commute.mrt}</span>
                  <span className="text-[var(--morandi-charcoal)] opacity-50"> 約 </span>
                  <span className="font-semibold text-[var(--morandi-slate)]">{selectedProperty.commute.walkTime} 分鐘</span>
                  <span className="text-[var(--morandi-charcoal)] opacity-40">（{selectedProperty.commute.distance}m）</span>
                </p>
              </div>

              {/* Life Scores */}
              <div className="mb-4">
                <h3 className="font-semibold text-[var(--morandi-charcoal)] mb-3 flex items-center gap-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-[var(--morandi-sage)]" />生活機能評分
                </h3>
                <div className="space-y-2">
                  {[
                    { icon: MapPin, label: '交通', score: selectedProperty.lifeScores.transport, color: '#9CAF88' },
                    { icon: ShoppingBag, label: '購物', score: selectedProperty.lifeScores.shopping, color: '#98A8B8' },
                    { icon: Utensils, label: '餐飲', score: selectedProperty.lifeScores.dining, color: '#AFA3B0' },
                    { icon: Hospital, label: '醫療', score: selectedProperty.lifeScores.medical, color: '#B8C5AA' },
                    { icon: GraduationCap, label: '教育', score: selectedProperty.lifeScores.education, color: '#C4B5C7' },
                  ].map(({ icon: Icon, label, score, color }) => (
                    <div key={label} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5">
                          <Icon className="w-3.5 h-3.5" style={{ color }} />
                          <span className="text-[var(--morandi-charcoal)]">{label}</span>
                        </div>
                        <span className="font-semibold" style={{ color }}>{score}</span>
                      </div>
                      <Progress value={score} className="h-1.5" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Landlord */}
              <div className="mb-4 p-4 bg-white border border-[var(--morandi-stone)]/40 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] rounded-full flex items-center justify-center text-white font-semibold shrink-0">
                    {selectedProperty.landlord.name[0]}
                  </div>
                  <div>
                    <div className="flex items-center gap-1">
                      <span className="font-medium text-[var(--morandi-charcoal)] text-sm">{selectedProperty.landlord.name}</span>
                      {selectedProperty.landlord.verified && <BadgeCheck className="w-4 h-4 text-[var(--morandi-sage)]" />}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-[var(--morandi-charcoal)] opacity-50">
                      <Star className="w-3 h-3 fill-[var(--morandi-mauve)] text-[var(--morandi-mauve)]" />
                      <span>{selectedProperty.landlord.rating}</span>
                      <span>·</span>
                      <span>回覆率 {selectedProperty.landlord.responseRate}%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Reviews */}
              <div className="mb-5">
                <h3 className="font-semibold text-[var(--morandi-charcoal)] mb-2 flex items-center gap-2 text-sm">
                  <MessageSquare className="w-4 h-4 text-[var(--morandi-mauve)]" />
                  匿名評論 ({selectedProperty.reviews.length})
                </h3>
                <div className="space-y-2">
                  {selectedProperty.reviews.map(review => (
                    <div key={review.id} className="p-3 bg-[var(--morandi-muted)] rounded-xl">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs font-medium text-[var(--morandi-charcoal)]">{review.author}</span>
                        <div className="flex items-center gap-0.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'fill-[var(--morandi-mauve)] text-[var(--morandi-mauve)]' : 'text-[var(--morandi-stone)]'}`} />
                          ))}
                        </div>
                      </div>
                      <p className="text-xs text-[var(--morandi-charcoal)] mb-1.5 leading-relaxed">{review.content}</p>
                      <div className="flex items-center justify-between text-[10px] text-[var(--morandi-charcoal)] opacity-40">
                        <span>{review.date}</span>
                        <button className="flex items-center gap-1 hover:text-[var(--morandi-sage)] transition-colors">
                          <ThumbsUp className="w-3 h-3" /><span>有幫助 ({review.helpful})</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <button className="w-full py-3.5 bg-gradient-to-r from-[var(--morandi-sage)] to-[var(--morandi-slate)] text-white rounded-xl hover:shadow-lg transition-all duration-300 hover:scale-[1.02] font-semibold text-sm">
                聯絡房東
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Roommate Questionnaire Modal */}
      <AnimatePresence>
        {showQuestionnaire && (
          <RoommateQuestionnaire onClose={() => setShowQuestionnaire(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}
