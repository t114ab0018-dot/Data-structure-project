import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import {
  Home, Eye, EyeOff, User, Building2, Briefcase, ChevronRight,
  CheckCircle2, Upload, Shield, BadgeCheck, FileText, Camera,
  Phone, Mail, Lock, ArrowLeft, Star, AlertCircle, Sofa
} from 'lucide-react';

type AuthMode = 'login' | 'register' | 'verify-tenant' | 'verify-landlord' | 'success';
type UserRole = 'tenant' | 'landlord' | 'agent' | null;

interface AuthPageProps {
  onAuthSuccess: (role: UserRole, userData: UserData) => void;
  startOnRegister?: boolean;
}

interface UserData {
  name: string;
  email: string;
  role: UserRole;
  verified: boolean;
}

const PW_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;

const steps = {
  tenant: ['基本資料', '身分驗證', '工作資訊', '完成'],
  landlord: ['基本資料', '產權證明', '房東認證', '完成'],
  agent: ['基本資料', '業者資格', '平台協議', '完成'],
};

const HOUSING_TYPES = ['獨立套房 (Studio Suite)', '分租套房 (Private Suite)', '家庭式整層住家 (Entire Apartment)', '優質雅房 (Shared Room)'];
const FURNITURE_OPTIONS = ['衣櫃 (Wardrobe)', '洗衣機 (Washing Machine)', '雙人床 (Double Bed)', '冰箱 (Refrigerator)', '冷氣 (Air Conditioner)', '熱水器 (Water Heater)'];
const STRENGTH_OPTIONS = ['愛乾淨 (Clean & Tidy)', '作息正常 (Regular Routine)', '不菸不酒 (No Smoking/Drinking)', '無寵物 (No Pets)', '準時交租 (Pays Rent on Time)'];

export default function AuthPage({ onAuthSuccess, startOnRegister = false }: AuthPageProps) {
  const [mode, setMode] = useState<AuthMode>(startOnRegister ? 'register' : 'login');
  const [loginRole, setLoginRole] = useState<UserRole>('tenant');
  const [role, setRole] = useState<UserRole>(null);
  const [step, setStep] = useState(0);
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [uploadedDocs, setUploadedDocs] = useState<Record<string, boolean>>({});

  // password strength
  const [pwTouched, setPwTouched] = useState(false);

  // tenant preferences
  const [housingType, setHousingType] = useState('');
  const [selectedFurniture, setSelectedFurniture] = useState<string[]>([]);
  const [selectedStrengths, setSelectedStrengths] = useState<string[]>([]);

  const [form, setForm] = useState({
    name: '', email: '', phone: '', password: '', confirmPw: '',
    idNumber: '', employer: '', jobTitle: '', income: '',
    propertyAddress: '', propertyId: '', isPublicLandlord: false,
    agencyName: '', licenseNumber: '',
  });

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }));

  const toggleDoc = (key: string) => setUploadedDocs(d => ({ ...d, [key]: !d[key] }));
  const toggleChip = (arr: string[], setArr: (v: string[]) => void, val: string) =>
    setArr(arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val]);

  const pwValid = PW_REGEX.test(form.password);
  const pwError = pwTouched && !pwValid;

  const handleLogin = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onAuthSuccess(loginRole, { name: '王小明', email: form.email, role: loginRole, verified: true });
    }, 1200);
  };

  const handleRegister = () => {
    if (!role) return;
    if (!pwValid) {
      toast.error('密碼須符合特殊符號加大小寫英數組合8位以上', { position: 'top-center' });
      setPwTouched(true);
      return;
    }
    setMode(role === 'tenant' ? 'verify-tenant' : 'verify-landlord');
    setStep(1);
  };

  const handleVerifyNext = () => {
    const maxStep = steps[role!]?.length - 1 ?? 3;
    if (step < maxStep) {
      setStep(s => s + 1);
    } else {
      setLoading(true);
      setTimeout(() => { setLoading(false); setMode('success'); }, 1500);
    }
  };

  const handleSuccessContinue = () => {
    onAuthSuccess(role, { name: form.name || '新用戶', email: form.email, role, verified: true });
  };

  const currentStepLabels = role ? steps[role] : [];

  const roleCards = [
    { id: 'tenant' as UserRole, icon: User, label: '租客', desc: '尋找理想居所，享受 AI 智能配對', color: 'var(--morandi-sage)', bg: 'rgba(156,175,136,0.12)' },
    { id: 'landlord' as UserRole, icon: Building2, label: '房東', desc: '輕鬆管理房源，降稅節費一站完成', color: 'var(--morandi-slate)', bg: 'rgba(152,168,184,0.12)' },
    { id: 'agent' as UserRole, icon: Briefcase, label: '業者/仲介', desc: '專業房仲入口，擴大服務觸及', color: 'var(--morandi-mauve)', bg: 'rgba(175,163,176,0.12)' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 bg-[var(--morandi-warm-white)]">
      {/* Background blobs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-[var(--morandi-sage)] opacity-10 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-[var(--morandi-mauve)] opacity-10 blur-3xl" />
      </div>

      <div className="relative w-full max-w-lg">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] flex items-center justify-center shadow-lg">
              <Home className="w-6 h-6 text-white" />
            </div>
            <div className="text-left">
              <span className="text-2xl font-semibold text-[var(--morandi-charcoal)] tracking-tight">棲居</span>
              <span className="text-sm text-[var(--morandi-charcoal)] opacity-40 ml-2">Habitat</span>
            </div>
          </div>
          <p className="text-sm text-[var(--morandi-charcoal)] opacity-50">AI 驅動的智慧租屋平台</p>
        </div>

        <AnimatePresence mode="wait">

          {/* ─── LOGIN ──────────────────────────────────────────── */}
          {mode === 'login' && (
            <motion.div key="login" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-xl border border-[var(--morandi-stone)]/40 p-8">
              <h2 className="mb-1 text-[var(--morandi-charcoal)]">歡迎回來</h2>
              <p className="text-sm text-[var(--morandi-charcoal)] opacity-50 mb-5">登入以繼續使用棲居平台</p>

              {/* Login role selector */}
              <div className="mb-6">
                <p className="text-xs font-medium text-[var(--morandi-charcoal)] opacity-55 mb-2.5">選擇您的身分</p>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'tenant' as UserRole, icon: User, label: '房客', color: '#a3e635', bg: 'rgba(163,230,53,0.10)' },
                    { id: 'landlord' as UserRole, icon: Building2, label: '房東', color: '#98A8B8', bg: 'rgba(152,168,184,0.12)' },
                    { id: 'agent' as UserRole, icon: Briefcase, label: '業者', color: '#AFA3B0', bg: 'rgba(175,163,176,0.12)' },
                  ].map(r => (
                    <button key={r.id} onClick={() => setLoginRole(r.id)}
                      className="flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border-2 transition-all duration-200"
                      style={{
                        borderColor: loginRole === r.id ? r.color : 'rgba(212,205,195,0.4)',
                        background: loginRole === r.id ? r.bg : 'rgba(0,0,0,0.02)',
                      }}>
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: r.bg }}>
                        <r.icon className="w-4 h-4" style={{ color: r.color }} />
                      </div>
                      <span className="text-xs font-medium text-[var(--morandi-charcoal)]"
                        style={{ opacity: loginRole === r.id ? 1 : 0.55 }}>{r.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <InputField icon={Mail} placeholder="電子信箱" type="email" value={form.email} onChange={set('email')} />
                <div className="relative">
                  <InputField icon={Lock} placeholder="密碼" type={showPw ? 'text' : 'password'} value={form.password} onChange={set('password')} />
                  <button className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--morandi-charcoal)] opacity-40 hover:opacity-70 transition-opacity" onClick={() => setShowPw(p => !p)}>
                    {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <div className="flex justify-end mt-2 mb-6">
                <button className="text-xs text-[var(--morandi-slate)] hover:underline">忘記密碼？</button>
              </div>
              <PrimaryButton onClick={handleLogin} loading={loading}>登入</PrimaryButton>
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-[var(--morandi-stone)]/40" /></div>
                <div className="relative flex justify-center"><span className="bg-white px-4 text-xs text-[var(--morandi-charcoal)] opacity-40">或</span></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <SocialButton icon="G" label="Google 登入" />
                <SocialButton icon="L" label="LINE 登入" color="#06C755" />
              </div>
              <p className="text-center text-sm mt-7 text-[var(--morandi-charcoal)] opacity-60">
                還沒有帳號？{' '}
                <button className="text-[var(--morandi-sage)] font-medium hover:underline" onClick={() => setMode('register')}>立即註冊</button>
              </p>
            </motion.div>
          )}

          {/* ─── REGISTER – ROLE + BASIC ────────────────────────── */}
          {mode === 'register' && step === 0 && (
            <motion.div key="register-role" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-xl border border-[var(--morandi-stone)]/40 p-8">
              <BackButton onClick={() => setMode('login')} />
              <h2 className="mb-1 text-[var(--morandi-charcoal)]">建立帳號</h2>
              <p className="text-sm text-[var(--morandi-charcoal)] opacity-50 mb-5">請選擇身分，我們將引導您完成驗證</p>

              {/* Role cards */}
              <div className="space-y-3 mb-5">
                {roleCards.map(r => (
                  <button key={r.id} onClick={() => setRole(r.id)}
                    className="w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all duration-200 text-left"
                    style={{ borderColor: role === r.id ? r.color : 'transparent', background: role === r.id ? r.bg : 'rgba(0,0,0,0.03)' }}>
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ background: r.bg }}>
                      <r.icon className="w-5 h-5" style={{ color: r.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-[var(--morandi-charcoal)] text-sm">{r.label}</p>
                      <p className="text-xs text-[var(--morandi-charcoal)] opacity-50 mt-0.5">{r.desc}</p>
                    </div>
                    {role === r.id && <CheckCircle2 className="w-5 h-5 shrink-0" style={{ color: r.color }} />}
                  </button>
                ))}
              </div>

              {/* Basic fields */}
              <div className="space-y-3 mb-5">
                <InputField icon={User} placeholder="真實姓名" value={form.name} onChange={set('name')} />
                <InputField icon={Mail} placeholder="電子信箱" type="email" value={form.email} onChange={set('email')} />
                <InputField icon={Phone} placeholder="手機號碼" type="tel" value={form.phone} onChange={set('phone')} />

                {/* Password with strength */}
                <div>
                  <div className="relative">
                    <InputField icon={Lock} placeholder="設定密碼" type={showPw ? 'text' : 'password'} value={form.password}
                      onChange={e => { set('password')(e); setPwTouched(true); }} />
                    <button className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--morandi-charcoal)] opacity-40 hover:opacity-70 transition-opacity" onClick={() => setShowPw(p => !p)}>
                      {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {/* helper */}
                  <p className={`text-xs mt-1.5 pl-1 transition-colors ${pwError ? 'text-[#C48B88]' : 'text-[var(--morandi-charcoal)] opacity-45'}`}>
                    密碼須包含特殊符號、大小寫英文與數字組合，且長度達8位以上
                  </p>
                  {/* strength bar */}
                  {form.password && (
                    <div className="flex gap-1 mt-2 pl-1">
                      {[1, 2, 3, 4].map(i => {
                        const score = [
                          /[a-z]/.test(form.password), /[A-Z]/.test(form.password),
                          /\d/.test(form.password), /[^A-Za-z0-9]/.test(form.password)
                        ].filter(Boolean).length;
                        const filled = i <= score;
                        const colors = ['#C48B88', '#C9AB7A', '#9CAF88', '#7A9070'];
                        return (
                          <div key={i} className="flex-1 h-1 rounded-full transition-all duration-300"
                            style={{ background: filled ? colors[Math.min(score - 1, 3)] : 'rgba(0,0,0,0.08)' }} />
                        );
                      })}
                    </div>
                  )}
                </div>
                <InputField icon={Lock} placeholder="確認密碼" type="password" value={form.confirmPw} onChange={set('confirmPw')} />
              </div>

              {/* Tenant-only preferences */}
              {role === 'tenant' && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="space-y-4 mb-5">
                  <div className="border-t border-[var(--morandi-stone)]/30 pt-4">
                    <p className="text-xs font-semibold text-[var(--morandi-charcoal)] opacity-60 mb-3">🏠 租客偏好設定</p>
                  </div>

                  {/* Housing type */}
                  <div>
                    <label className="text-xs text-[var(--morandi-charcoal)] opacity-55 mb-1.5 block">我想找什麼樣的房子</label>
                    <select value={housingType} onChange={e => setHousingType(e.target.value)}
                      className="w-full px-4 py-3.5 rounded-xl border border-[var(--morandi-stone)]/50 bg-[var(--morandi-warm-white)] text-sm text-[var(--morandi-charcoal)] focus:outline-none focus:ring-2 focus:ring-[var(--morandi-sage)]/30 appearance-none">
                      <option value="">請選擇類型</option>
                      {HOUSING_TYPES.map(t => <option key={t}>{t}</option>)}
                    </select>
                  </div>

                  {/* Required furniture */}
                  <div>
                    <label className="text-xs text-[var(--morandi-charcoal)] opacity-55 mb-2 block flex items-center gap-1">
                      <Sofa className="w-3.5 h-3.5" /> 期望家具配置
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {FURNITURE_OPTIONS.map(f => (
                        <label key={f} className="flex items-center gap-2.5 cursor-pointer">
                          <input type="checkbox" checked={selectedFurniture.includes(f)} onChange={() => toggleChip(selectedFurniture, setSelectedFurniture, f)}
                            className="w-4 h-4 rounded accent-[var(--morandi-sage)]" />
                          <span className="text-xs text-[var(--morandi-charcoal)] opacity-70">{f}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Personal strengths */}
                  <div>
                    <label className="text-xs text-[var(--morandi-charcoal)] opacity-55 mb-2 block">自身優勢</label>
                    <div className="flex flex-wrap gap-2">
                      {STRENGTH_OPTIONS.map(s => (
                        <button key={s} onClick={() => toggleChip(selectedStrengths, setSelectedStrengths, s)}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200"
                          style={selectedStrengths.includes(s)
                            ? { background: 'rgba(156,175,136,0.15)', borderColor: 'var(--morandi-sage)', color: 'var(--morandi-sage)' }
                            : { background: 'transparent', borderColor: 'rgba(212,205,195,0.6)', color: 'rgba(74,74,74,0.55)' }}>
                          {selectedStrengths.includes(s) && <CheckCircle2 className="w-3 h-3" />}
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              <PrimaryButton onClick={handleRegister} disabled={!role || !form.name || !form.email}>
                下一步：身分驗證 <ChevronRight className="w-4 h-4 ml-1 inline" />
              </PrimaryButton>
              <p className="text-center text-sm mt-5 text-[var(--morandi-charcoal)] opacity-60">
                已有帳號？{' '}
                <button className="text-[var(--morandi-sage)] font-medium hover:underline" onClick={() => setMode('login')}>立即登入</button>
              </p>
            </motion.div>
          )}

          {/* ─── TENANT VERIFICATION ────────────────────────────── */}
          {mode === 'verify-tenant' && (
            <motion.div key={`verify-tenant-${step}`} initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-xl border border-[var(--morandi-stone)]/40 p-8">
              <BackButton onClick={() => { if (step <= 1) { setMode('register'); setStep(0); } else setStep(s => s - 1); }} />
              <StepIndicator steps={currentStepLabels} current={step} color="var(--morandi-sage)" />

              {step === 1 && (
                <div>
                  <h2 className="mb-1 text-[var(--morandi-charcoal)]">身分驗證</h2>
                  <p className="text-sm text-[var(--morandi-charcoal)] opacity-50 mb-6">請提供身分證明文件，確保平台安全</p>
                  <div className="space-y-4">
                    <InputField icon={Shield} placeholder="身分證字號" value={form.idNumber} onChange={set('idNumber')} />
                    <UploadCard label="身分證正面" desc="JPG / PNG，最大 5MB" icon={Camera} uploaded={!!uploadedDocs['id-front']} onClick={() => toggleDoc('id-front')} />
                    <UploadCard label="身分證背面" desc="JPG / PNG，最大 5MB" icon={Camera} uploaded={!!uploadedDocs['id-back']} onClick={() => toggleDoc('id-back')} />
                    <InfoNote>您的身分資料將以 AES-256 加密儲存，僅用於租屋契約簽署</InfoNote>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div>
                  <h2 className="mb-1 text-[var(--morandi-charcoal)]">工作資訊</h2>
                  <p className="text-sm text-[var(--morandi-charcoal)] opacity-50 mb-6">提供收入證明，提升房東信任度</p>
                  <div className="space-y-4">
                    <InputField icon={Briefcase} placeholder="雇主名稱 / 公司" value={form.employer} onChange={set('employer')} />
                    <InputField icon={User} placeholder="職稱" value={form.jobTitle} onChange={set('jobTitle')} />
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xs text-[var(--morandi-charcoal)] opacity-40">月收入</span>
                      <select value={form.income} onChange={set('income')}
                        className="w-full pl-16 pr-4 py-3.5 rounded-xl border border-[var(--morandi-stone)]/50 bg-[var(--morandi-warm-white)] text-sm text-[var(--morandi-charcoal)] focus:outline-none focus:ring-2 focus:ring-[var(--morandi-sage)]/30 appearance-none">
                        <option value="">請選擇範圍</option>
                        <option>3 萬以下</option><option>3～5 萬</option><option>5～8 萬</option><option>8 萬以上</option>
                      </select>
                    </div>
                    <UploadCard label="薪資轉帳明細 / 勞保證明" desc="最近 3 個月，PDF 或圖片" icon={FileText} uploaded={!!uploadedDocs['income-proof']} onClick={() => toggleDoc('income-proof')} />
                    <InfoNote>收入資料僅供房東審閱，不會公開顯示</InfoNote>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="text-center py-4">
                  <div className="w-20 h-20 mx-auto rounded-full bg-[rgba(156,175,136,0.15)] flex items-center justify-center mb-5">
                    <CheckCircle2 className="w-10 h-10 text-[var(--morandi-sage)]" />
                  </div>
                  <h2 className="mb-2 text-[var(--morandi-charcoal)]">資料已送出</h2>
                  <p className="text-sm text-[var(--morandi-charcoal)] opacity-60 mb-8">我們將在 1 個工作天內完成審核<br />審核通過後會以 Email 及簡訊通知您</p>
                  <div className="text-left space-y-2 mb-8">
                    {['真實姓名驗證', '身分證核對', '工作收入確認', '信用評分生成'].map(item => (
                      <div key={item} className="flex items-center gap-3 text-sm text-[var(--morandi-charcoal)] opacity-70">
                        <CheckCircle2 className="w-4 h-4 text-[var(--morandi-sage)] shrink-0" />{item}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <PrimaryButton onClick={handleVerifyNext} loading={loading && step === 3}>
                {step === 3 ? '完成註冊，進入平台' : '下一步'} <ChevronRight className="w-4 h-4 ml-1 inline" />
              </PrimaryButton>
            </motion.div>
          )}

          {/* ─── LANDLORD / AGENT VERIFICATION ─────────────────── */}
          {mode === 'verify-landlord' && (
            <motion.div key={`verify-landlord-${step}`} initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-xl border border-[var(--morandi-stone)]/40 p-8">
              <BackButton onClick={() => { if (step <= 1) { setMode('register'); setStep(0); } else setStep(s => s - 1); }} />
              <StepIndicator steps={currentStepLabels} current={step} color={role === 'agent' ? 'var(--morandi-mauve)' : 'var(--morandi-slate)'} />

              {role === 'landlord' && step === 1 && (
                <div>
                  <h2 className="mb-1 text-[var(--morandi-charcoal)]">產權證明</h2>
                  <p className="text-sm text-[var(--morandi-charcoal)] opacity-50 mb-6">請提供房屋所有權相關文件</p>
                  <div className="space-y-4">
                    <InputField icon={Building2} placeholder="房屋地址" value={form.propertyAddress} onChange={set('propertyAddress')} />
                    <InputField icon={FileText} placeholder="地政謄本字號（選填）" value={form.propertyId} onChange={set('propertyId')} />
                    <UploadCard label="土地／建物謄本" desc="地政事務所核發，3 個月內" icon={FileText} uploaded={!!uploadedDocs['land-registry']} onClick={() => toggleDoc('land-registry')} />
                    <UploadCard label="房屋稅單或繳費收據" desc="最近年度" icon={FileText} uploaded={!!uploadedDocs['tax-receipt']} onClick={() => toggleDoc('tax-receipt')} />
                    <InfoNote>文件上傳後由平台核實，不用擔心資料安全</InfoNote>
                  </div>
                </div>
              )}

              {role === 'landlord' && step === 2 && (
                <div>
                  <h2 className="mb-1 text-[var(--morandi-charcoal)]">房東認證</h2>
                  <p className="text-sm text-[var(--morandi-charcoal)] opacity-50 mb-5">完成認證即可享有更多信任標章與節稅優惠</p>
                  <div
                    className="rounded-2xl p-5 mb-4 cursor-pointer border-2 transition-all duration-200"
                    style={{ borderColor: form.isPublicLandlord ? 'var(--morandi-sage)' : 'transparent', background: form.isPublicLandlord ? 'rgba(156,175,136,0.1)' : 'rgba(0,0,0,0.03)' }}
                    onClick={() => setForm(f => ({ ...f, isPublicLandlord: !f.isPublicLandlord }))}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[rgba(156,175,136,0.2)] flex items-center justify-center shrink-0 mt-0.5">
                        <Star className="w-5 h-5 text-[var(--morandi-sage)]" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium text-sm text-[var(--morandi-charcoal)]">申請「公益出租人」資格</p>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-[var(--morandi-sage)] text-white">節稅</span>
                        </div>
                        <p className="text-xs text-[var(--morandi-charcoal)] opacity-55 leading-relaxed">
                          將房屋出租給弱勢族群，享有房屋稅、地價稅優惠稅率，並獲得平台金牌公益房東標章
                        </p>
                      </div>
                      {form.isPublicLandlord && <CheckCircle2 className="w-5 h-5 text-[var(--morandi-sage)] shrink-0" />}
                    </div>
                  </div>
                  {form.isPublicLandlord && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="mb-4">
                      <UploadCard label="公益出租人申請書" desc="由各縣市社會局取得" icon={FileText} uploaded={!!uploadedDocs['public-form']} onClick={() => toggleDoc('public-form')} />
                    </motion.div>
                  )}
                  <UploadCard label="身分證正面" desc="房東本人身分驗證" icon={Camera} uploaded={!!uploadedDocs['landlord-id']} onClick={() => toggleDoc('landlord-id')} />
                  <div className="mt-4 p-4 rounded-xl bg-[rgba(152,168,184,0.12)] border border-[rgba(152,168,184,0.3)]">
                    <p className="text-xs text-[var(--morandi-slate)] leading-relaxed">
                      <BadgeCheck className="w-3.5 h-3.5 inline mr-1" />
                      通過認證的房東將獲得藍勾勾驗證標章，大幅提升租客信任度
                    </p>
                  </div>
                </div>
              )}

              {role === 'landlord' && step === 3 && (
                <VerifyCompleteStep role="landlord" checks={['產權文件核實', '房東身分確認', '公益資格審核', '信任標章發放']} />
              )}

              {role === 'agent' && step === 1 && (
                <div>
                  <h2 className="mb-1 text-[var(--morandi-charcoal)]">業者資格</h2>
                  <p className="text-sm text-[var(--morandi-charcoal)] opacity-50 mb-6">請提供不動產經紀業相關資格文件</p>
                  <div className="space-y-4">
                    <InputField icon={Briefcase} placeholder="公司 / 事務所名稱" value={form.agencyName} onChange={set('agencyName')} />
                    <InputField icon={FileText} placeholder="不動產經紀人執照字號" value={form.licenseNumber} onChange={set('licenseNumber')} />
                    <UploadCard label="不動產經紀業許可執照" desc="主管機關核發" icon={FileText} uploaded={!!uploadedDocs['agency-license']} onClick={() => toggleDoc('agency-license')} />
                    <UploadCard label="不動產經紀人證書" desc="個人執照正本" icon={FileText} uploaded={!!uploadedDocs['agent-cert']} onClick={() => toggleDoc('agent-cert')} />
                  </div>
                </div>
              )}

              {role === 'agent' && step === 2 && (
                <div>
                  <h2 className="mb-1 text-[var(--morandi-charcoal)]">平台協議</h2>
                  <p className="text-sm text-[var(--morandi-charcoal)] opacity-50 mb-6">作為業者，請確認遵守平台規範</p>
                  <div className="space-y-3">
                    {['所有刊登房源資訊均為真實且已獲授權', '不得刊登已出租或不存在的房源', '遵守《不動產經紀業管理條例》相關規定', '配合平台不定期進行資格複查'].map((item, i) => (
                      <label key={i} className="flex items-start gap-3 cursor-pointer">
                        <input type="checkbox" className="mt-0.5 accent-[var(--morandi-mauve)] w-4 h-4 shrink-0" />
                        <span className="text-sm text-[var(--morandi-charcoal)] opacity-75 leading-relaxed">{item}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {role === 'agent' && step === 3 && (
                <VerifyCompleteStep role="agent" checks={['業者資格核實', '執照有效性確認', '平台協議存檔', '業者標章發放']} />
              )}

              <PrimaryButton onClick={handleVerifyNext} loading={loading && step === 3} color={role === 'agent' ? 'var(--morandi-mauve)' : 'var(--morandi-slate)'}>
                {step === 3 ? '完成註冊，進入平台' : '下一步'} <ChevronRight className="w-4 h-4 ml-1 inline" />
              </PrimaryButton>
            </motion.div>
          )}

          {/* ─── SUCCESS ─────────────────────────────────────────── */}
          {mode === 'success' && (
            <motion.div key="success" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-xl border border-[var(--morandi-stone)]/40 p-8 text-center">
              <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-[var(--morandi-sage)] to-[var(--morandi-slate)] flex items-center justify-center mb-5 shadow-lg">
                <BadgeCheck className="w-12 h-12 text-white" />
              </div>
              <h2 className="mb-2 text-[var(--morandi-charcoal)]">申請已提交！</h2>
              <p className="text-sm text-[var(--morandi-charcoal)] opacity-60 mb-8 leading-relaxed">
                您的帳號已建立，審核資料已送出<br />通過審核後，您將獲得藍勾勾認證標章<br />我們會在 1 個工作天內聯絡您
              </p>
              <PrimaryButton onClick={handleSuccessContinue}>現在就開始探索棲居平台 →</PrimaryButton>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  );
}

// ── Shared Sub-components ──────────────────────────────────────────────────

function InputField({ icon: Icon, placeholder, type = 'text', value, onChange }: {
  icon: React.ComponentType<{ className?: string }>; placeholder: string; type?: string;
  value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}) {
  return (
    <div className="relative">
      <Icon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--morandi-charcoal)] opacity-35" />
      <input type={type} placeholder={placeholder} value={value} onChange={onChange}
        className="w-full pl-11 pr-4 py-3.5 rounded-xl border border-[var(--morandi-stone)]/50 bg-[var(--morandi-warm-white)] text-sm text-[var(--morandi-charcoal)] placeholder-[var(--morandi-charcoal)]/35 focus:outline-none focus:ring-2 focus:ring-[var(--morandi-sage)]/30 focus:border-[var(--morandi-sage)]/50 transition-all" />
    </div>
  );
}

function PrimaryButton({ children, onClick, loading, disabled, color = 'var(--morandi-sage)' }: {
  children: React.ReactNode; onClick?: () => void; loading?: boolean; disabled?: boolean; color?: string;
}) {
  return (
    <button onClick={onClick} disabled={disabled || loading}
      className="w-full py-3.5 rounded-xl text-white text-sm font-medium transition-all duration-200 flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg active:scale-[0.98]"
      style={{ background: `linear-gradient(135deg, ${color}, color-mix(in srgb, ${color} 70%, #888))` }}>
      {loading ? <div className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : children}
    </button>
  );
}

function SocialButton({ icon, label, color = '#4A4A4A' }: { icon: string; label: string; color?: string }) {
  return (
    <button className="flex items-center justify-center gap-2 py-3 rounded-xl border border-[var(--morandi-stone)]/50 bg-[var(--morandi-warm-white)] text-sm text-[var(--morandi-charcoal)] opacity-70 hover:opacity-100 hover:border-[var(--morandi-stone)] transition-all">
      <span className="font-bold text-sm" style={{ color }}>[{icon}]</span>{label}
    </button>
  );
}

function BackButton({ onClick }: { onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex items-center gap-1.5 text-xs text-[var(--morandi-charcoal)] opacity-50 hover:opacity-80 transition-opacity mb-5">
      <ArrowLeft className="w-3.5 h-3.5" /> 返回
    </button>
  );
}

function StepIndicator({ steps, current, color }: { steps: string[]; current: number; color: string }) {
  return (
    <div className="flex items-center gap-0 mb-6">
      {steps.map((label, i) => (
        <div key={i} className="flex items-center">
          <div className="flex flex-col items-center gap-1">
            <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium transition-all duration-300"
              style={{ background: i <= current ? color : 'rgba(0,0,0,0.08)', color: i <= current ? '#fff' : 'rgba(74,74,74,0.4)' }}>
              {i < current ? <CheckCircle2 className="w-4 h-4" /> : i + 1}
            </div>
            <span className="text-[10px] text-[var(--morandi-charcoal)] opacity-50 w-12 text-center leading-tight">{label}</span>
          </div>
          {i < steps.length - 1 && (
            <div className="w-8 h-0.5 mb-4 mx-1 transition-all duration-300" style={{ background: i < current ? color : 'rgba(0,0,0,0.1)' }} />
          )}
        </div>
      ))}
    </div>
  );
}

function UploadCard({ label, desc, icon: Icon, uploaded, onClick }: {
  label: string; desc: string; icon: React.ComponentType<{ className?: string }>;
  uploaded: boolean; onClick: () => void;
}) {
  return (
    <button onClick={onClick}
      className="w-full flex items-center gap-4 p-4 rounded-xl border-2 border-dashed transition-all duration-200 text-left"
      style={{ borderColor: uploaded ? 'var(--morandi-sage)' : 'rgba(212,205,195,0.6)', background: uploaded ? 'rgba(156,175,136,0.08)' : 'transparent' }}>
      <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0" style={{ background: uploaded ? 'rgba(156,175,136,0.15)' : 'rgba(0,0,0,0.04)' }}>
        {uploaded ? <CheckCircle2 className="w-5 h-5 text-[var(--morandi-sage)]" /> : <Icon className="w-5 h-5 text-[var(--morandi-charcoal)] opacity-35" />}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-[var(--morandi-charcoal)]">{label}</p>
        <p className="text-xs text-[var(--morandi-charcoal)] opacity-45 mt-0.5">{desc}</p>
      </div>
      {!uploaded && <Upload className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-30 shrink-0" />}
    </button>
  );
}

function InfoNote({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 p-3 rounded-xl bg-[rgba(152,168,184,0.1)]">
      <AlertCircle className="w-4 h-4 text-[var(--morandi-slate)] shrink-0 mt-0.5" />
      <p className="text-xs text-[var(--morandi-slate)] leading-relaxed">{children}</p>
    </div>
  );
}

function VerifyCompleteStep({ role, checks }: { role: string; checks: string[] }) {
  const color = role === 'landlord' ? 'var(--morandi-slate)' : 'var(--morandi-mauve)';
  return (
    <div className="text-center py-2">
      <div className="w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-5" style={{ background: `color-mix(in srgb, ${color} 15%, transparent)` }}>
        <CheckCircle2 className="w-10 h-10" style={{ color }} />
      </div>
      <h2 className="mb-2 text-[var(--morandi-charcoal)]">資料已送出</h2>
      <p className="text-sm text-[var(--morandi-charcoal)] opacity-60 mb-7">我們將於 1 個工作天內完成審核<br />通過後您將獲得認證標章</p>
      <div className="text-left space-y-2 mb-7">
        {checks.map(item => (
          <div key={item} className="flex items-center gap-3 text-sm text-[var(--morandi-charcoal)] opacity-70">
            <CheckCircle2 className="w-4 h-4 shrink-0" style={{ color }} />{item}
          </div>
        ))}
      </div>
    </div>
  );
}
