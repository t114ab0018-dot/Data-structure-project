import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText, DollarSign, Wrench, CheckCircle2, Clock, Phone, Upload,
  X, Search, Home, CreditCard, Calendar, ChevronRight, Send, AlertCircle
} from 'lucide-react';
import { myContract, myRentHistory } from '../../mockData';

interface TenantDashboardProps {
  onSwitchToSearch: () => void;
}

const LIME = '#a3e635';

type Modal = 'contract' | 'rent' | 'repair' | null;

interface RepairTicket {
  id: number;
  issue: string;
  status: string;
  date: string;
  isNew?: boolean;
}

const INITIAL_TICKETS: RepairTicket[] = [
  { id: 1, issue: '客廳冷氣不冷', status: '師傅已接單', date: '2026/06/15' },
  { id: 2, issue: '廚房水槽堵塞', status: '已完工', date: '2026/06/01' },
];

export default function TenantDashboard({ onSwitchToSearch }: TenantDashboardProps) {
  const [mode, setMode] = useState<'search' | 'tenant'>('tenant');
  const [openModal, setOpenModal] = useState<Modal>(null);
  const [issueDesc, setIssueDesc] = useState('');
  const [photoUploaded, setPhotoUploaded] = useState(false);
  const [tickets, setTickets] = useState<RepairTicket[]>(INITIAL_TICKETS);
  const [payNowClicked, setPayNowClicked] = useState(false);

  const pendingRent = myRentHistory.find(r => r.status === '待繳納');
  const paidHistory = myRentHistory.filter(r => r.status === '已繳');

  if (mode === 'search') {
    onSwitchToSearch();
    return null;
  }

  const handleSubmitRepair = () => {
    if (!issueDesc.trim()) return;
    const now = new Date();
    const dateStr = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}`;
    const newTicket: RepairTicket = {
      id: Date.now(),
      issue: issueDesc,
      status: '房東審核中',
      date: dateStr,
      isNew: true,
    };
    setTickets(prev => [newTicket, ...prev]);
    setIssueDesc('');
    setPhotoUploaded(false);
    // Remove "new" highlight after 4s
    setTimeout(() => setTickets(prev => prev.map(t => t.id === newTicket.id ? { ...t, isNew: false } : t)), 4000);
  };

  return (
    <div className="min-h-full bg-[var(--morandi-warm-white)] px-4 py-6 sm:px-6">
      <div className="max-w-2xl mx-auto">

        {/* Mode Toggle */}
        <div className="flex items-center justify-center mb-8">
          <div className="inline-flex items-center bg-white rounded-2xl p-1.5 shadow-sm border border-[var(--morandi-stone)]/40">
            <ModeBtn active={mode === 'search'} onClick={() => setMode('search')} icon={Search} label="找房模式" activeColor="var(--morandi-slate)" />
            <ModeBtn active={mode === 'tenant'} onClick={() => setMode('tenant')} icon={Home} label="房客模式" activeColor="var(--morandi-sage)" />
          </div>
        </div>

        {/* Greeting */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-[var(--morandi-charcoal)]">我的租屋管理</h2>
          <p className="text-sm text-[var(--morandi-charcoal)] opacity-50 mt-0.5">點擊卡片開啟詳情</p>
        </div>

        {/* ── 3-card grid ──────────────────────────────────────── */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <GridCard
            icon={FileText} title="查看合約" subtitle="View Contract"
            iconColor="var(--morandi-slate)" iconBg="rgba(152,168,184,0.15)"
            onClick={() => setOpenModal('contract')}
          />
          <GridCard
            icon={DollarSign} title="租金繳交" subtitle="Rent Payment"
            iconColor="var(--morandi-sage)" iconBg="rgba(156,175,136,0.15)"
            badge={pendingRent ? { label: '待繳', color: '#C48B88' } : undefined}
            onClick={() => setOpenModal('rent')}
          />
          <GridCard
            icon={Wrench} title="修繕申請" subtitle="Maintenance"
            iconColor="var(--morandi-mauve)" iconBg="rgba(175,163,176,0.15)"
            badge={{ label: `${tickets.filter(t => t.status !== '已完工').length} 進行`, color: 'var(--morandi-mauve)' }}
            onClick={() => setOpenModal('repair')}
          />
        </div>

        {/* Quick summary strip */}
        <div className="mt-4 p-4 bg-white rounded-2xl border border-[var(--morandi-stone)]/30 shadow-sm">
          <div className="grid grid-cols-3 divide-x divide-[var(--morandi-stone)]/20 text-center">
            <div>
              <p className="text-[10px] text-[var(--morandi-charcoal)] opacity-45 mb-0.5">月租金</p>
              <p className="text-sm font-bold text-[var(--morandi-sage)]">${myContract.monthlyRent.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-[10px] text-[var(--morandi-charcoal)] opacity-45 mb-0.5">合約到期</p>
              <p className="text-sm font-bold text-[var(--morandi-charcoal)]">{myContract.endDate}</p>
            </div>
            <div>
              <p className="text-[10px] text-[var(--morandi-charcoal)] opacity-45 mb-0.5">修繕紀錄</p>
              <p className="text-sm font-bold text-[var(--morandi-charcoal)]">{tickets.length} 筆</p>
            </div>
          </div>
        </div>

        {/* ── Repair tracker preview (always visible) ─────────── */}
        <div className="mt-4 bg-white rounded-2xl border border-[var(--morandi-stone)]/30 shadow-sm overflow-hidden">
          <div className="px-5 py-4 flex items-center justify-between border-b border-[var(--morandi-stone)]/20">
            <p className="text-sm font-semibold text-[var(--morandi-charcoal)]">修繕進度追蹤列表</p>
            <button onClick={() => setOpenModal('repair')}
              className="text-xs text-[var(--morandi-mauve)] hover:underline flex items-center gap-1">
              新增申請 <ChevronRight className="w-3 h-3" />
            </button>
          </div>
          <div className="divide-y divide-[var(--morandi-stone)]/10">
            {tickets.map(ticket => (
              <TicketRow key={ticket.id} ticket={ticket} lime={LIME} />
            ))}
          </div>
        </div>
      </div>

      {/* ── Modals ──────────────────────────────────────────────── */}
      <AnimatePresence>
        {openModal && (
          <motion.div key="backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
            onClick={() => setOpenModal(null)}>
            <motion.div
              initial={{ opacity: 0, y: 60 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 60 }}
              onClick={e => e.stopPropagation()}
              className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden max-h-[85vh] overflow-y-auto"
            >
              <ModalHeader
                title={openModal === 'contract' ? '查看合約' : openModal === 'rent' ? '租金繳交' : '修繕申請'}
                onClose={() => setOpenModal(null)}
              />

              {/* ─── Contract Modal ─── */}
              {openModal === 'contract' && (
                <div className="p-6 space-y-4">
                  <div className="p-4 rounded-2xl bg-[var(--morandi-muted)] space-y-3">
                    <ModalRow icon={Calendar} label="租期" value={`${myContract.startDate} ～ ${myContract.endDate}`} />
                    <ModalRow icon={DollarSign} label="月租金" value={`$${myContract.monthlyRent.toLocaleString()}`} />
                    <ModalRow icon={DollarSign} label="押金" value={`$${myContract.deposit.toLocaleString()}`} />
                    <ModalRow icon={Phone} label="房東電話" value={myContract.landlordPhone} />
                    <ModalRow icon={FileText} label="物件" value={myContract.property} />
                  </div>
                  <div className="text-xs text-[var(--morandi-charcoal)] opacity-45 text-center">{myContract.address}</div>
                  <button className="w-full py-3 rounded-xl border border-[var(--morandi-slate)]/40 text-sm text-[var(--morandi-slate)] flex items-center justify-center gap-2 hover:bg-[var(--morandi-slate)]/5 transition-colors">
                    <FileText className="w-4 h-4" /> 下載電子合約 PDF
                  </button>
                </div>
              )}

              {/* ─── Rent Modal ─── */}
              {openModal === 'rent' && (
                <div className="p-6 space-y-4">
                  {pendingRent && (
                    <div className="rounded-2xl p-4 border" style={{ background: 'rgba(196,139,136,0.07)', borderColor: 'rgba(196,139,136,0.3)' }}>
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="text-xs text-[var(--morandi-charcoal)] opacity-55">本月狀態：待繳納</p>
                          <p className="text-2xl font-bold text-[var(--morandi-charcoal)] mt-1">${pendingRent.amount.toLocaleString()}</p>
                        </div>
                        <AlertCircle className="w-5 h-5 text-[#C48B88] mt-1" />
                      </div>
                      <p className="text-xs text-[var(--morandi-charcoal)] opacity-50">截止日期：{pendingRent.dueDate}</p>
                    </div>
                  )}
                  <button onClick={() => setPayNowClicked(true)}
                    className="w-full py-3.5 rounded-xl text-sm font-semibold text-white flex items-center justify-center gap-2 transition-all hover:shadow-lg"
                    style={{ background: payNowClicked ? 'var(--morandi-sage)' : 'linear-gradient(135deg, var(--morandi-sage), var(--morandi-slate))' }}>
                    {payNowClicked ? <><CheckCircle2 className="w-4 h-4" />已送出繳費請求</> : <><CreditCard className="w-4 h-4" />立即繳費 Online Pay Now</>}
                  </button>
                  <div>
                    <p className="text-xs font-semibold text-[var(--morandi-charcoal)] opacity-50 mb-2">繳款收據紀錄</p>
                    <div className="rounded-xl border border-[var(--morandi-stone)]/30 overflow-hidden">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-[var(--morandi-muted)]">
                            <th className="text-left px-3 py-2 text-xs text-[var(--morandi-charcoal)] opacity-55 font-semibold">月份</th>
                            <th className="text-right px-3 py-2 text-xs text-[var(--morandi-charcoal)] opacity-55 font-semibold">金額</th>
                            <th className="text-right px-3 py-2 text-xs text-[var(--morandi-charcoal)] opacity-55 font-semibold">狀態</th>
                          </tr>
                        </thead>
                        <tbody>
                          {paidHistory.map(r => (
                            <tr key={r.month} className="border-t border-[var(--morandi-stone)]/20">
                              <td className="px-3 py-2.5 text-[var(--morandi-charcoal)]">{r.month}</td>
                              <td className="px-3 py-2.5 text-right text-[var(--morandi-charcoal)]">${r.amount.toLocaleString()}</td>
                              <td className="px-3 py-2.5 text-right">
                                <span className="text-xs px-2 py-0.5 rounded-full bg-[var(--morandi-sage)]/10 text-[var(--morandi-sage)]">已繳</span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* ─── Repair Modal ─── */}
              {openModal === 'repair' && (
                <div className="p-6 space-y-4">
                  {/* Input form */}
                  <div className="space-y-3">
                    <label className="text-xs font-semibold text-[var(--morandi-charcoal)] opacity-55 block">修繕內容描述 Enter Repair Description</label>
                    <textarea
                      value={issueDesc}
                      onChange={e => setIssueDesc(e.target.value)}
                      placeholder="請詳細描述損壞狀況..."
                      rows={3}
                      className="w-full px-4 py-3 rounded-xl border border-[var(--morandi-stone)]/50 bg-[var(--morandi-warm-white)] text-sm text-[var(--morandi-charcoal)] placeholder-[var(--morandi-charcoal)]/30 focus:outline-none focus:ring-2 focus:ring-[var(--morandi-mauve)]/30 resize-none"
                    />
                    <button onClick={() => setPhotoUploaded(p => !p)}
                      className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-dashed transition-all"
                      style={{ borderColor: photoUploaded ? 'var(--morandi-mauve)' : 'rgba(212,205,195,0.5)', background: photoUploaded ? 'rgba(175,163,176,0.07)' : 'transparent' }}>
                      {photoUploaded ? <CheckCircle2 className="w-4 h-4 text-[var(--morandi-mauve)]" /> : <Upload className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-30" />}
                      <span className="text-sm text-[var(--morandi-charcoal)] opacity-55">{photoUploaded ? '照片已上傳' : '上傳損壞照片 Upload Photo'}</span>
                    </button>
                    <button onClick={handleSubmitRepair} disabled={!issueDesc.trim()}
                      className="w-full py-3.5 rounded-xl text-sm font-semibold transition-all hover:shadow-md disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-white"
                      style={{ background: 'linear-gradient(135deg, var(--morandi-mauve), var(--morandi-slate))' }}>
                      <Send className="w-4 h-4" /> 送出修繕申請 Submit Request
                    </button>
                  </div>

                  {/* Ticket tracker */}
                  <div>
                    <p className="text-xs font-semibold text-[var(--morandi-charcoal)] opacity-55 mb-2">修繕進度追蹤列表</p>
                    <div className="rounded-xl border border-[var(--morandi-stone)]/30 overflow-hidden">
                      {tickets.map(ticket => (
                        <TicketRow key={ticket.id} ticket={ticket} lime={LIME} />
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────

function ModeBtn({ active, onClick, icon: Icon, label, activeColor }: {
  active: boolean; onClick: () => void;
  icon: React.ComponentType<{ className?: string }>;
  label: string; activeColor: string;
}) {
  return (
    <button onClick={onClick}
      className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-200"
      style={active ? { background: activeColor, color: '#fff', boxShadow: '0 2px 8px rgba(0,0,0,0.15)' }
                    : { color: 'rgba(74,74,74,0.5)' }}>
      <Icon className="w-4 h-4" />{label}
    </button>
  );
}

function GridCard({ icon: Icon, title, subtitle, iconColor, iconBg, badge, onClick }: {
  icon: React.ComponentType<{ className?: string }>;
  title: string; subtitle: string;
  iconColor: string; iconBg: string;
  badge?: { label: string; color: string };
  onClick: () => void;
}) {
  return (
    <button onClick={onClick}
      className="bg-white rounded-2xl p-5 border border-[var(--morandi-stone)]/30 shadow-sm hover:shadow-md hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 text-left w-full group">
      <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-4" style={{ background: iconBg }}>
        <Icon className="w-5 h-5 group-hover:scale-110 transition-transform" style={{ color: iconColor }} />
      </div>
      {badge && (
        <span className="text-[10px] px-2 py-0.5 rounded-full text-white font-medium mb-2 inline-block" style={{ background: badge.color }}>
          {badge.label}
        </span>
      )}
      <p className="font-semibold text-[var(--morandi-charcoal)] text-sm">{title}</p>
      <p className="text-[11px] text-[var(--morandi-charcoal)] opacity-40 mt-0.5">{subtitle}</p>
      <div className="mt-3 flex items-center gap-1 text-xs opacity-0 group-hover:opacity-60 transition-opacity" style={{ color: iconColor }}>
        點擊開啟 <ChevronRight className="w-3 h-3" />
      </div>
    </button>
  );
}

function ModalHeader({ title, onClose }: { title: string; onClose: () => void }) {
  return (
    <div className="flex items-center justify-between px-6 py-4 border-b border-[var(--morandi-stone)]/20">
      <h3 className="font-semibold text-[var(--morandi-charcoal)]">{title}</h3>
      <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-[var(--morandi-muted)] transition-colors">
        <X className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-60" />
      </button>
    </div>
  );
}

function ModalRow({ icon: Icon, label, value }: {
  icon: React.ComponentType<{ className?: string }>;
  label: string; value: string;
}) {
  return (
    <div className="flex items-center gap-3">
      <Icon className="w-4 h-4 text-[var(--morandi-charcoal)] opacity-30 shrink-0" />
      <span className="text-xs text-[var(--morandi-charcoal)] opacity-50 w-14 shrink-0">{label}</span>
      <span className="text-sm font-medium text-[var(--morandi-charcoal)]">{value}</span>
    </div>
  );
}

function TicketRow({ ticket, lime }: { ticket: RepairTicket; lime: string }) {
  const isDone = ticket.status === '已完工';
  const isNew = ticket.isNew;
  return (
    <div className="flex items-center gap-3 px-4 py-3 border-b border-[var(--morandi-stone)]/10 last:border-0 transition-colors"
      style={isNew ? { background: `${lime}12` } : {}}>
      <div className={`w-2 h-2 rounded-full shrink-0 ${isDone ? '' : ''}`}
        style={{ background: isNew ? lime : isDone ? 'var(--morandi-sage)' : 'var(--morandi-mauve)' }} />
      <div className="flex-1 min-w-0">
        <p className="text-sm text-[var(--morandi-charcoal)] font-medium truncate"
          style={isNew ? { color: '#1a1a1a' } : {}}>
          {ticket.issue}
        </p>
        <p className="text-[10px] opacity-50 text-[var(--morandi-charcoal)]">{ticket.date}</p>
      </div>
      <span className="text-xs px-2.5 py-1 rounded-full font-medium shrink-0"
        style={isNew
          ? { background: lime, color: '#000' }
          : isDone
            ? { background: 'rgba(156,175,136,0.15)', color: 'var(--morandi-sage)' }
            : { background: 'rgba(175,163,176,0.15)', color: 'var(--morandi-mauve)' }}>
        {isNew ? '房東審核中' : ticket.status}
        {isNew && <span className="ml-1 opacity-70 text-[9px]">｜剛剛</span>}
      </span>
    </div>
  );
}
