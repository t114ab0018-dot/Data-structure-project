指令一：未登入導覽列、三角色登入與動態導覽列切換

複製以下內容丟給 Figma AI：
"Design a navigation header and a Login interface for '棲居 (Habitat)'.

Logged-out Header State: Only show three items on the top-right menu: ['首頁 (Home)', '登入 (Login)', '註冊 (Register)'].

Login Page UI: Add a segmented picker or card selection for roles with three options: ['房客 (Tenant)', '房東 (Landlord)', '業者 (Agency)'].

Dynamic Logged-in Header States:

If user logs in as '房客 (Tenant)': The header menu dynamically changes to: ['首頁 (Home)', '找房地圖 (Search Map)', '房客後台 (Tenant Dashboard)', 'User Avatar (頭像)'].

If user logs in as '房東 (Landlord)': The header menu dynamically changes to: ['首頁 (Home)', '房東後台 (Landlord Dashboard)', 'User Avatar (頭像)'].

If user logs in as '業者 (Agency)': The header menu dynamically changes to: ['首頁 (Home)', '業者後台 (Agency Dashboard)', 'User Avatar (頭像)'].
Make the navigation bar modern, dark themed with (#a3e635) accent highlights."

📌 指令二：【雅房專屬】10題室友希望條件問卷與10名以上室友隨機媒合

複製以下內容丟給 Figma AI：
"Design an interactive flow on the Search Map page. In the Property Type filter, if the user selects '雅房 (Shared Room)', pop up an elegant 10-question questionnaire titled '室友希望條件篩選 (Desired Roommate Questionnaire)'.
The 10 questions to render are:

'生活作息': ['早起型 (Early Bird)', '夜貓型 (Night Owl)', '不限制']

'公共衛生習慣': ['每日打掃', '每週打掃', '垃圾不落地']

'訪客限制': ['完全不可帶人', '僅限同性', '提前告知即可']

'寵物接受度': ['不接受寵物', '可接受貓咪', '可接受狗狗', '不限制']

'吸菸習慣': ['絕對禁菸', '陽台可', '無限制']

'烹飪習慣': ['不開伙', '限輕食無油煙', '可大火烹飪']

'公共電費分攤方式': ['按人頭均分', '按房型面積', '依電錶自付']

'共用物品習慣': ['嚴禁未經同意借用', '公共消耗品均分費用', '各自獨立購買']

'冷氣使用時段': ['不限制', '晚上睡覺才開', '省電不常開']

'聲音接受度': ['需絕對安靜', '一般生活音量可接受', '可接受放音樂'].
Below the completed questionnaire, show a submit button. Once clicked, transition to a roommate matching result container displaying exactly 10 matched roommate cards.
Render these 10 roommate cards with avatar, compatibility score (e.g., 98%), and tags:

'陳小華 | 98% 契合度 (工程師 / 作息規律 / 不菸無寵 / 喜歡安靜)'

'林美玲 | 95% 契合度 (設計師 / 貓奴 / 愛乾淨 / 偶爾輕食)'

'張家豪 | 92% 契合度 (大學生 / 陽光開朗 / 不帶異性過夜 / 準時交租)'

'許雅婷 | 90% 契合度 (公務員 / 極度愛乾淨 / 早睡早起 / 禁菸無寵)'

'王志明 | 88% 契合度 (上班族 / 夜貓子 / 偶爾小酌 / 喜歡音樂)'

'劉芳妤 | 87% 契合度 (護理師 / 作息彈性 / 愛貓 / 尊重隱私)'

'賴冠宇 | 85% 契合度 (外送員 / 隨和 / 不開伙 / 自備消耗品)'

'蔡晴雯 | 83% 契合度 (文字工作者 / 靜音型 / 無菸 / 每週大掃除)'

'曾子軒 | 81% 契合度 (軟體研發 / 極簡主義 / 無寵 / 早出晚歸)'

'董佩君 | 80% 契合度 (研究生 / 偶爾有同性訪客 / 開伙輕食 / 自律)'."

📌 指令三：網格化房客後台（點選才展開）與動態修繕新增展示（核心升級！）

複製以下內容丟給 Figma AI：
"Design the 'Tenant Dashboard (房客後台)' with an interactive grid card layout. Show three primary click-to-open card buttons:

'查看合約 (View Contract)' Card: clicking it opens a modal overlay showing lease dates, landlord contacts, and deposit terms.

'租金繳交 (Rent Payment)' Card: clicking it opens a payment popup showing unpaid balance $15,000, due date, payment method, and a past receipts table.

'修繕申請 (Maintenance)' Card: clicking it opens a dynamic repair ticket form with a text input field '修繕內容描述 (Enter Repair Description)' and a photo upload button.

To demonstrate the dynamic update feature, design TWO distinct prototype screens/states for the Repair Form:

State A (Empty / Editing Form): The text area is empty. Below it, the 'Repair Tickets Tracker (修繕進度追蹤列表)' table displays existing history:

'客廳冷氣不冷 | 狀態: 師傅已接單 (2026/06/15)'

'廚房水槽堵塞 | 狀態: 已完工 (2026/06/01)'

State B (Submitted Form - Dynamic Entry added): The user has typed '浴室蓮蓬頭斷裂漏水' and clicked the '送出修繕申請 (Submit Request)' button. The form input resets, and the '浴室蓮蓬頭斷裂漏水' is instantly prepended to the top of the 'Repair Tickets Tracker' table with a newly added badge: '狀態: 房東審核中 | 申請時間: 剛剛 (Just Now)'. Ensure the newly submitted user content is prominently highlighted in lime green (#a3e635) to emphasize that the list dynamically updates."

📌 指令四：房東後台與業者後台（一鍵複製名稱變更）

複製以下內容丟給 Figma AI：
"Design a multi-property listing management layout. Render two identical system instances to showcase permissions:

One named 'Landlord Dashboard (房東管理後台)' for individual multi-property owners.

The other identical in layout but renamed to 'Agency Dashboard (業者管理後台)' tailored for third-party agency operators and property management companies.
Both dashboards must contain: a list of owned rental cards, a floating '+ Upload New Property (上傳新物件)' button, a 'Property Deed Verification (房產驗證)' section with '審核中' status, and a checkboxes panel for advantages ('代收垃圾', '近捷運站', '可養寵物') and included furniture."

📌 指令五：全雙北 41 行政區與北科大捷運核心地圖（含房屋類型篩選與家具篩選）

複製以下內容丟給 Figma AI：
"Create a property search screen with advanced filters and a map view. On top of the search filters, design a prominent segmented control or button group for 'Property Type (房屋類型)' containing buttons: ['全部 (All)', '整層住家 (Entire)', '獨立套房 (Studio)', '分租套房 (Private Suite)', '優質雅房 (Shared Room)'].
Populated the 'Area (區域)' dropdown filter with all these exact districts: [Taipei: 中正區, 大同區, 中山區, 松山區, 大安區, 萬華區, 信義區, 士林區, 北投區, 內湖區, 南港區, 文山區. New Taipei: 板橋區, 三重區, 中和區, 永和區, 新莊區, 新店區, 土城區, 蘆洲區, 樹林區, 汐止區, 三峽區, 淡水區, 鶯歌區, 五股區, 泰山區, 林口區, 深坑區, 石碇區, 坪林區, 三芝區, 石門區, 八里區, 平溪區, 雙溪區, 貢寮區, 金山區, 萬里區, 烏來區, 瑞芳區].
Also add a checklist filter for 'Included Furniture (設備/家具)' with checkboxes: ['洗衣機', '衣櫃', '冷氣', '冰箱'].
Center the map around National Taipei University of Technology (北科大), clearly showing a high-contrast transit grid: Blue Line (台北車站, 善導寺, 忠孝新生, 忠孝復興, 忠孝敦化), Green Line (中山, 松江南京, 南京復興), Red Line (中正紀念堂, 東門, 大安森林公園, 大安), Yellow Line (松江南京, 忠孝新生, 東門), and Brown Line (南京復興, 忠孝復興, 大安)."

📌 指令六：50件以上雙北隨機高保真假房源資料庫

複製以下內容丟給 Figma AI：
"Generate a property feed list component that holds 50+ mock listing cards with realistic data. Divide them logically: 20 Shared Rooms (雅房) and 30 Suites/Apartments (套房與整層住家).
Shared Rooms (1-20):
'1. 大安溫馨雅房 $8,500', '2. 中山捷運雅房 $7,800', '3. 中正北科雅房 $8,000', '4. 松山採光雅房 $9,000', '5. 萬華小資雅房 $7,000', '6. 板橋便捷雅房 $7,500', '7. 三重公寓雅房 $6,800', '8. 中和溫暖雅房 $7,200', '9. 永和頂溪雅房 $7,400', '10. 新莊輔大雅房 $6,900', '11. 士林夜市雅房 $8,200', '12. 北投溫泉雅房 $7,500', '13. 內湖科技雅房 $8,800', '14. 南港經緯雅房 $9,200', '15. 文山政大雅房 $7,300', '16. 蘆洲徐匯雅房 $7,100', '17. 新店公館雅房 $8,000', '18. 汐止樟樹雅房 $6,500', '19. 林口三井雅房 $7,800', '20. 土城海山雅房 $7,200'.
Suites & Apartments (21-50):
'21. 信義奢華套房 $22,000', '22. 大安精品套房 $18,000', '23. 中山現代套房 $16,500', '24. 松山景觀套房 $17,500', '25. 中正新生套房 $16,000', '26. 內湖科技套房 $15,500', '27. 南港軟體套房 $19,000', '28. 板橋新板套房 $14,500', '29. 三重河景套房 $13,000', '30. 中和景安套房 $12,500', '31. 永和頂溪套房 $13,500', '32. 新莊副都心套房 $14,000', '33. 土城海山套房 $11,000', '34. 蘆洲徐匯套房 $11,500', '35. 新店碧潭套房 $13,500', '36. 汐止科學園區套房 $12,000', '37. 樹林車站套房 $10,000', '38. 淡水捷運套房 $9,500', '39. 林口三井套房 $13,000', '40. 五股電梯套房 $11,000', '41. 鶯歌陶瓷套房 $9,000', '42. 深坑老街套房 $10,500', '43. 八里左岸套房 $9,800', '44. 泰山明志套房 $10,000', '45. 大安陽台整層住家 $38,000', '46. 中山精緻兩房整層 $32,000', '47. 信義豪邸整層住家 $65,000', '48. 板橋家庭式整層 $28,000', '49. 三重溫馨整層三房 $26,000', '50. 中和景平雙套房整層 $25,000', '51. 新莊歐洲村整層 $29,000'.
Render each listing card showing title, price, location, property type, and icons representing included furniture (Washer, AC, Bed, Fridge)."